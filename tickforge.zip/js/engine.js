// Tickforge engine — decoupled fixed-step combat loop (GDD §4: "The Tick Standard").
// Combat math runs on 10 ticks/second (100ms) independent of requestAnimationFrame,
// so low-end devices never desync combat outcomes. Every cooldown, GCD, DoT pulse,
// resource tick and proc resolves on integer tick boundaries.
(() => {
  const TICK_MS = 100;
  const GCD_BASE_MS = 1500; // 15 ticks

  class TickEngine {
    constructor(combat, onFrame, onTick) {
      this.combat = combat;
      this.onFrame = onFrame || (() => {});
      this.onTick = onTick || (() => {});
      this.fps = 60;
      this.fxTier = 2; // 2 full, 1 culled, 0 minimal
      this.speed = 1;
      this.paused = false;
      this._acc = 0;
      this._last = performance.now();
      this._frames = 0;
      this._fpsAt = this._last;
      this._running = false;
    }

    setSpeed(mult) {
      this.speed = [1, 2, 5].includes(Number(mult)) ? Number(mult) : 1;
    }

    pause() {
      this.paused = true;
      this._acc = 0;
    }

    resume() {
      this.paused = false;
      this._last = performance.now();
      this._acc = 0;
    }

    togglePause() {
      if (this.paused) this.resume();
      else this.pause();
      return this.paused;
    }

    step() {
      if (!this.combat || this.combat.state?.result) return false;
      this.pause();
      this.combat.tick();
      this.onTick(this.combat);
      return true;
    }

    start() {
      if (this._running) return;
      this._running = true;
      this._last = performance.now();
      const loop = (now) => {
        if (!this._running) return;
        const rawDelta = Math.min(250, Math.max(0, now - this._last));
        this._last = now;

        if (!this.paused && this.combat && !this.combat.state?.result) {
          this._acc += rawDelta * this.speed;
          // Cap catch-up per frame so tab-switching at 5x doesn't freeze UI
          let guard = 0;
          while (this._acc >= TICK_MS && guard < 20) {
            this.combat.tick();
            this.onTick(this.combat);
            this._acc -= TICK_MS;
            guard++;
            if (this.combat.state?.result) {
              this._acc = 0;
              break;
            }
          }
          if (guard >= 20) this._acc = 0;
        }

        // FPS monitor — cull non-essential FX below 30/15 FPS (GDD: FX culling).
        this._frames++;
        if (now - this._fpsAt >= 1000) {
          this.fps = this._frames;
          this._frames = 0;
          this._fpsAt = now;
          this.fxTier = this.fps < 15 ? 0 : this.fps < 30 ? 1 : 2;
          if (this.combat) this.combat.fxTier = this.fxTier;
        }
        this.onFrame(rawDelta);
        requestAnimationFrame(loop);
      };
      requestAnimationFrame(loop);
    }

    stop() { this._running = false; }
  }

  window.Tickforge = Object.assign(window.Tickforge || {}, { TickEngine, TICK_MS, GCD_BASE_MS });
})();
