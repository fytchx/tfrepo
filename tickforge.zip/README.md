# Tickforge

**A mobile-first, portrait-oriented 2D Auto-Combat ARPG & Endless Idle Deckbuilder.**

Tickforge combines the 5-slot hotbar priority and Global Cooldown (GCD) pacing of classic tab-target RPGs with ARPG affix crafting, build-revamping item mutators, smart auto-salvage loot filtering, and a frictionless offline/AFK progression loop—all running on a deterministic **10 Hz (`100ms`) tick engine**.

---

## 1. The Core Game Loop (How It Actually Plays)

No vague "what-ifs"—this is the exact playable loop this repository is built around:

1. **Zero-Friction Start:** Pick 1 of 5 classes (**Templar, Warrior, Elementalist, Nightblade, Monk**) and a starter weapon. Combat starts immediately on Tick 1 in **Zone 1: Gallowsfen — Wave 1** with auto-attacks and unlocked hotbar skills firing automatically.
2. **Endless Wave Farming:** Waves spawn `1–5` enemies across portrait slots (`Slots 0–4`). Beating a wave immediately spawns the next wave, streaming XP, gold, equipment, runes, and crafting materials.
3. **Zero-Softlock Campfire Respawn:** Dying is a normal part of pushing too deep. When HP hits `0`, there is no blocking "Game Over" screen—a `2.0s` (`20-tick`) *"Slain — Recovering at Campfire"* recovery runs, steps back 1 wave (`max(1, wave - 1)`), keeps all earned loot and XP, refills HP/Resource to `100%`, and resumes combat.
4. **Rested XP vs. Active Tuning:**
   * **Rested XP** accumulates while offline or idling (up to `150%` of a level bar) and doubles kill XP (`2.0×`) until spent.
   * **Death Tax:** Every death burns `5%` of max Rested XP and resets your kill streak. An AFK player still makes steady progress over hours, while a player who optimizes their 5-slot hotbar, resistances, and gear stops dying and progresses **3×–5× faster**.
5. **Smart Loot Filter & Salvage Economy:** Unwanted drops are automatically salvaged on drop into **Forged Scrap**, **Arcane Dust**, and **Essence Shards** based on player-configured rarity/tag rules, while rare **Build-Revamping Mutators**, **Runes**, **Trinkets**, and low-drop-rate **Tag Catalysts / Corruption Cores** are highlighted and kept.
6. **Manual Zone Boss Walls:** Wave clears charge a **Zone Boss Readiness Gauge (`0% → 100%`)**. At `100%`, the player manually chooses when to click **"Challenge Zone Boss"**. Beating the Boss unlocks the next Zone (**Gallowsfen → Blighted Fallfields → Emberscar Wastes → Endless Tiers**), which introduces a steep stat jump (`~3.2× HP`, `~2.1× Damage`) that motivates farming and crafting before pushing deeper.

---

## 2. What Is Already Built in This Repository

This repo already contains a substantial working foundation in **pure vanilla HTML, CSS, and JavaScript**:

### Core Engine & Gameplay Modules (`js/`)
* `js/engine.js` (`2.9 KB`) — Fixed-timestep `10 Hz` (`100ms`) deterministic simulation clock and seeded PRNG.
* `js/combat.js` (`81.6 KB`) — Complete 6-stage damage pipeline, unidirectional element conversion (`Physical → Lightning → Fire → Poison/Bleed`), `O(1)` Poison rolling bucket, Burn/Bleed/Aggravate DoTs, 5-layer mitigation (Entropy Dodge, Block, Armor, Resistances, Monk Stagger), Posture Break, and Combat Sandbox simulation.
* `js/campaign.js` (`56.6 KB`) — Live Idle Campaign progression loop, endless waves, Campfire Respawn, Rested XP + Offline AFK simulator (`+1h / +4h / +8h`), Smart Loot Filter, Salvage/Crafting economy, and Manual Zone Boss encounters.
* `js/ui.js` (`152.1 KB`) — Portrait-first mobile UI controller rendering the battlefield portraits, 5-slot hotbar, flanking HP/Resource globes, Sandbox controls, Loot Filter panel, Inventory/Crafting tabs, and live combat telemetry.
* `js/save.js` (`6.0 KB`) — `localStorage` state persistence plus JSON Save/Build export and import.
* `js/data-bundle.js` (`97.0 KB`) — Pre-compiled runtime bundle of all JSON databases.

### Data & Content Databases (`data/` & `decks/`)
* `data/classes.json` (`8.4 KB`) & `data/abilities.json` (`22.2 KB`) — All 5 playable classes, resource rules, and active/passive skill kits.
* `data/equipment.json` (`83.3 KB`) & `data/affixes.json` (`12.0 KB`) — 7 weapon archetypes, armor/rings/trinkets, item affixes, and build-revamping mutators.
* `data/catalysts.json` (`2.4 KB`) — Core Tag Catalysts, Prism/Nullifying Catalysts, and Overclock Corruption rules.
* `data/enemies.json` (`2.9 KB`), `data/schools.json` (`1.1 KB`), `data/zones.json` (`994 B`) — Enemy archetypes, damage channels, and zone scaling configs.
* `decks/tickforge-chapter-1.deck.json` (`7.8 KB`) — Chapter 1 starter encounter/deck definitions.

### Custom SVG Art Assets (`assets/`)
* `assets/enemies/` (`24 SVGs`) & `assets/enemies/frames/` (`12 SVGs`) — Enemy icons, character portraits across all damage schools, and Hearthstone-style oval portrait frames.
* `assets/fx/` (`25 SVGs`) — Projectile, impact, burst, chain, and aura spell overlays across Physical, Fire, Lightning, Bleed, and Poison.
* `assets/icons/` (`77 SVGs`) — Skill keycap icons plus 7 gear slot icons. Note: the game now has 5 schools, but icon/enemy sets for the older Frost and Disease schools are still here. Audit before deleting (see Milestone 1).

### Tooling & Server (`tools/`, `server.js`, `CHANGELOG.md`)
* `server.js` / `package.json` — Tiny Express dev server. Not required to play: `index.html` also works from `file://` because `js/data-bundle.js` mirrors the JSON.
* `tools/smoke-test.cjs` — Automated headless smoke test for engine verification.
* `tools/generate-data.mjs`, `tools/generate-assets.mjs`, `tools/compendium-data.mjs` — Data and SVG generation scripts.
* `CHANGELOG.md` (`19.0 KB`) & `PLAN.md` (`5.1 KB`) — History of recent implementations and architectural notes.

---

## 3. Running the Project Locally

~~~bash
# Easiest: just open index.html in a browser (works from file://)

# Or serve it
npm install
npm start            # http://localhost:3000

# Checks
npm run lint         # syntax check all JS
npm test             # headless smoke test, all 5 classes
node tools/generate-data.mjs   # regenerate js/data-bundle.js after editing data/*.json
~~~

Open it in a mobile-sized viewport (`390×844` or `412×915`).

---

## 4. Technical Non-Negotiables (Rules for Developers & AI)

1. **Keep It Pure Vanilla HTML / CSS / JS:** Do **not** migrate this repository to React, TypeScript, Vite, Webpack, or Tailwind. Everything runs directly in the browser using `index.html`, `css/*.css`, and `js/*.js`.
2. **Respect the `10 Hz` (`100ms`) Tick Engine:** Never tie combat math to `requestAnimationFrame` FPS. All cooldowns, DoTs, regen, and AI decisions run on discrete `100ms` ticks with sub-tick `fractionalCarry` Haste accumulation.
3. **Preserve Dual-Mode Playability:** Keep both **Live Idle Campaign Mode** (the actual endless game loop) and **Combat Sandbox Mode** (`1–5` custom enemies, `1 / 5 / 25 / 100 / 1,000` Base HP presets, `x1–x10` multipliers, `Normal/Elite/Boss` ranks, custom spell/item creator, editable stats with **Reset Stats**) functional and synced to the same combat engine.
4. **Data-Driven Content:** Add new spells, items, enemies, and zones via `data/*.json` (and regenerate `js/data-bundle.js` via `tools/generate-data.mjs` if bundled) rather than hardcoding stats inside `ui.js`.

---

## 5. Actionable Game Plan (Turning This Into a Finished Playable Game)

Instead of adding more speculative systems, execute these **4 focused milestones in order**:

### Milestone 1: Audit, Bugfix & End-to-End Verification (Playability First)
* **Goal:** Make sure every existing button, tab, fight, drop, and save file works without console errors or dead clicks.
* **Tasks:**
  1. Run `node tools/smoke-test.cjs` and test a full browser playthrough of both **Idle Campaign Mode** and **Combat Sandbox Mode**.
  2. Verify all SVG paths in `assets/enemies/`, `assets/icons/`, and `assets/fx/` resolve cleanly in `ui.js` (no broken image icons).
  3. Test the full death-and-recovery cycle (`Campfire Respawn` → wave step-back → Rested XP deduction → auto-resume) and `localStorage` Save/Load/Reset (`js/save.js`).
  4. Verify the **Smart Loot Filter** accurately keeps Rare+ / Mutator / Socketed items and auto-salvages rejected drops into Forged Scrap / Arcane Dust.

### Milestone 2: Nail the "First 10 Minutes" Pacing & Game Feel
* **Goal:** Make the game immediately fun and readable within 60 seconds of picking a class and weapon.
* **Tasks:**
  1. **Tune Zone 1 (*Gallowsfen*) Curve:** Calibrate Waves `1–10` so a fresh Level 1 character smoothly clears Waves `1–3`, hits a natural difficulty wall around Waves `4–6` (experiencing their first Campfire Respawn), equips 1–2 early drops, and feels a noticeable power spike.
  2. **Boss Readiness & *Warden Malakor*:** Ensure reaching `100%` Boss Readiness clearly highlights the **"Challenge Zone Boss"** button, displays telegraphed boss windup bars, and gives a clear **Post-Fight Death Tip** (e.g., *"Need more Armor or an Interrupt in Slot 1"*) if the player loses.
  3. **Combat Juice & Clarity:** Polish radial cooldown sweeps on the 5 hotbar keycaps, floating damage/crit/heal numbers, Posture Break "STAGGERED!" visual cues, and a clean one-click **Equip & Compare** flow for dropped gear.

### Milestone 3: Make Crafting, Runes & Build Mutators Deeply Rewarding
* **Goal:** Give players exciting reasons to spend their salvaged materials and rare Catalyst drops to break through the Zone 2 (*Blighted Fallfields*) and Zone 3 (*Emberscar Wastes*) stat walls.
* **Tasks:**
  1. **Workbench / Forge UI Polish:** Allow players to spend **Forged Scrap** to upgrade item base tiers, **Arcane Dust** to reroll affixes, **Essence Shards** to add/socket Runes, and **Tag Catalysts** to boost matching tag affixes up to `+20%` (`+30%` with **Overclock Corruption Cores**).
  2. **High-Impact Build Mutators:** Ensure at least 8–10 distinct `ruleMutators` drop on Rare/Epic/Legendary gear (e.g., *Cleave adjacent enemies*, *Convert 50% Physical to Fire + Ignite*, *Bleeds tick 35% faster and refund resource*, *Every 4th cast triggers a free Spell Echo*) and visibly change combat behavior.

### Milestone 4: Balance Sweep, Shareable Builds & Mobile Polish
* **Goal:** Lock in class parity and package the game for daily playtesting.
* **Tasks:**
  1. Run automated headless simulations across all 5 classes using the Sandbox bot presets (`Optimal`, `Casual`, `Sloppy`) to verify that all 5 classes can clear Zones 1–3 within ±15% progression speed.
  2. Add **One-Click Build Share Codes** (compact Base64 export/import for build + hotbar + loot filter).
  3. Finalize mobile portrait layout polish (`360px–430px` widths), offline progress summary modals, and PWA manifest readiness (`manifest.json`).

---

---

## 6. Repo Map

~~~
index.html        single page shell
css/              variables (--tf-* tokens), layout, effects
js/               engine, combat, campaign, save, ui, data-bundle (generated)
data/             JSON source of truth (generate-data.mjs builds data-bundle.js)
assets/           SVGs with GS- prefixes (enemies, frames, fx, icons)
decks/            chapter 1 encounter definitions
tools/            generators + smoke test
docs/reference/   AI Studio combat screen mockup (visual target, not code)
docs/archive/     original spec, old plan, old UI kit. Historical, do not build from these
AI_BRIEF.md       paste this at the start of an AI chat
~~~

**Current status:** Milestone 1 (audit and bugfix) is the active one. Lint and the smoke test pass; no one has done a full manual browser playthrough yet.
