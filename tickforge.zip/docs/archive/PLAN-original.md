# Tickforge — Full Build Plan

## Goal and users
A complete, immediately playable browser build of **Tickforge**, a seasonal 2D portrait
idle-MMOARPG ("WoW-Stone" hybrid). Single player, mobile-first 9:16 portrait. "Working" =
open `index.html` (or the preview) and combat, progression, loot, gear, forging and saving
all function with zero placeholders.

## Scope
- In scope: decoupled 20-tick engine, GCD + auto-caster, FX culling, campaign waves
  (Blighted Fallfields), loot/gold/material economy, localStorage saves, Battle / Deck /
  Gear / Forge views, full data library (7 schools, 70 abilities, bestiary, 6 gear slots,
  affixes), SVG/asset library with strict `GS-` prefixes, `manifest.json`, packaged
  `tickforge-full-build.zip`.
- Out of scope (later): Leaderboard view, networked seasons, accounts, audio.

## Architecture
- **Stack:** Vanilla HTML/CSS/JS (ES classes, no build step) — the existing repo is a
  no-tooling static site and the build must run from `file://` as well as a server.
- **Data loading:** `data/*.json` are the source of truth (for tooling/review);
  `js/data-bundle.js` mirrors them as `window.TFDATA` so the game works over `file://`
  (fetch of local JSON is blocked there). Both are generated together by
  `tools/generate-data.mjs`.
- **`js/engine.js`:** fixed 100 ms accumulator loop (10 ticks/s, per GDD revision) driving
  combat math, buffs, cooldowns, Holy Power; rendering stays in `requestAnimationFrame`.
  Tracks frame delta and exposes an FX budget tier (full / culled / minimal below 30 / 15 FPS).
- **`js/combat.js`:** deterministic combat state — GCD (1500 ms base, 15 ticks), cooldown spirals
  Holy Power generators/spenders, school status ailments + combo reaction multipliers
  (from `schools.json`), DoTs, enemy AI, wave/stage progression, loot and economy.
- **`js/ui.js`:** renders the four views, hotbar with cooldown sweeps + GCD bar, oval enemy
  portraits, pooled floating combat text, screen shakes, projectile FX (CSS custom
  properties position them), save/load via `localStorage` key `tickforge.save.v1`.
- **Data model:** player profile {level, xp, hp, gold, materials, loadout[4], gear{6},
  bag, zone/stage, unlockedAbilities}; abilities reference `schools.json` ids and `GS-FX-`
  keys; affixes reference gear slots; enemies reference school ids and portrait paths.
- **Hosting:** static — preview server or double-click `index.html`.

## Design brief
For commuters who loved WoW hotbar rotations and Hearthstone boards; each screen's one job
is legible, satisfying combat at a glance. Mood: dark, ornate, arcane. Direction: dark-fantasy
product-led, using the established `--tf-*` tokens (`#0b0e16` core, `#1a2234` cards,
`#bba4ff` accent) and the UI-kit type/radius conventions. Memorable thing: spell projectiles
flying from the hotbar into ornate oval enemy frames with combo-colored bursts.

## Risks and assumptions
- `file://` CORS → data bundled as JS alongside JSON (assumption accepted above).
- 70 abilities generated from per-school stat templates with unique names/formulas —
  complete, not placeholder; balance is first-pass.
- Local save only; versioned key with migration on load.

## Phases

## Phase 1: Data & asset library
Generate `data/*.json` (schools, 70 abilities, enemies, equipment, affixes),
`assets/enemies/GS-ENM-*.svg`, `assets/icons/GS-ICO-*.svg`,
`assets/enemies/frames/GS-UI-FRM-Oval-1..12.svg`, and `css/effects.css` with
5+ `GS-FX-` classes per school. Acceptance: all files valid, cross-referenced ids resolve.
**Status: DONE (2026-11-22).** Revised canon after later GDD rounds: 5 schools × 5-slot
ability grid (29 abilities), 10 enemies, 3 zones, 213 equipment items (Master Item
Compendium), 61 affixes, 10 catalysts; FX = 5 schools × 5 types = 25 `GS-FX-*.svg`.
Verified: `node tools/generate-data.mjs` clean; all school refs and FX assets resolve.

## Phase 2: Playable core engine
`js/engine.js` + `js/combat.js`: tick loop, GCD, auto-rotation, damage/DoT/combo math,
waves, loot. Acceptance: combat resolves continuously with resource generation/spending.
**Status: DONE (2026-11-22).** Verified: `node --check` clean on all 5 modules;
`node tools/smoke-test.cjs` — SMOKE TEST PASSED (victory, 49 casts, hooked kit OK).

## Phase 3: Full UI & views
`index.html`, `css/`, `js/ui.js`: header, board, hotbar, Battle/Deck/Gear/Forge tabs,
pooled FCT, shakes, projectiles, responsive 9:16 shell. Acceptance: playable in browser at
360/768/1280 px; every tab interactive.
**Status: DONE (2026-11-22).** Verified in built-in browser at 390px and 1280px:
0 page errors, 0 console errors, no horizontal overflow; Deck/Gear tabs exercised.

## Phase 4: Persistence, manifest & packaging
localStorage save/load, `manifest.json`, `dist/tickforge-full-build.zip`. Acceptance:
create progress → reload → restored; zip opens and plays.
**Status: DONE (2026-11-22).** Verified: equip → page reload → "Equipped" state restored
from localStorage; `dist/tickforge-full-build.zip` = 163 files (~300 KB) incl. all data/
assets/js/css. Known gap: `data/catalysts.json` has no crafting UI yet.
