// Tickforge combat — deterministic battle state driven by the tick engine.
// All math reads window.TFDATA. Combat outcomes depend only on tick count and
// seeded RNG state, never on frame rate.
(() => {
  const { GCD_BASE_MS } = window.Tickforge;

  const RANK_MODS = {
    Normal: { hpMult: 1.0, dmgMult: 1.0, dr: 0.0, frame: "assets/enemies/frames/GS-UI-FRM-Oval-1.svg" },
    Elite:  { hpMult: 2.5, dmgMult: 1.5, dr: 0.15, frame: "assets/enemies/frames/GS-UI-FRM-Oval-4.svg" },
    Boss:   { hpMult: 6.0, dmgMult: 2.2, dr: 0.30, frame: "assets/enemies/frames/GS-UI-FRM-Oval-12.svg" },
  };

  const COMBO_NAMES = {
    "fire+poison": "Combustion",
    "poison+fire": "Blightfire",
    "lightning+fire": "Overload",
    "fire+lightning": "Thermal Arc",
    "physical+lightning": "Shattershock",
    "lightning+physical": "Conductive Strike",
    "physical+bleed": "Deep Wound",
    "bleed+physical": "Hemorrhage",
    "poison+bleed": "Septic Rupture",
    "bleed+poison": "Venomous Tear",
  };

  function computeEncounterEnemy(def, slotCfg, slotIndex = 0) {
    const rankName = RANK_MODS[slotCfg.rank] ? slotCfg.rank : "Normal";
    const r = RANK_MODS[rankName];
    const baseHp = Math.max(1, Number(slotCfg.baseHp) || def.hp || 100);
    const mult = Math.max(1, Number(slotCfg.multiplier) || 1);
    const maxHp = Math.max(1, Math.round(baseHp * mult * r.hpMult));
    const attack = Math.max(1, Math.round((def.attack || 2) * mult * r.dmgMult));
    return {
      ...def,
      uid: slotIndex,
      slotIndex,
      rank: rankName,
      frame: r.frame,
      baseHp,
      multiplier: mult,
      maxHp,
      hp: maxHp,
      attack,
      mitigation: r.dr,
      attackIntervalTicks: (def.attackIntervalMs || 2100) / 100,
      attackTimer: ((def.attackIntervalMs || 2100) / 100) * (0.4 + slotIndex * 0.12),
      ailments: {},
      lastHitCrit: false,
      dead: false,
      comboCdTicks: 0,
      slowTicks: 0,
      slowPct: 0,
    };
  }

  // Parses compendium item hook descriptions + named hooks into deterministic engine modifiers
  function parseItemModifiers(equippedDefs) {
    const mods = {
      physConvert: null,          // { to: "school_fire", percent: 1.0 }
      schoolBonus: {},            // school_id -> +decimal increased
      flatSchoolDmg: {},          // school_id -> +flat
      critMulti: 0,
      armorPen: 0,
      maxHpPct: 0,
      hastePct: 0,
      meleeMore: 0,
      executeThreshold: 0,
      executeMore: 0,
      vsUndeadBeast: 0,
      dotSpeedPct: 0,
      burnMult: 0,
      fireCritBonus: 0,
      bleedCritBonus: 0,
      bleedCritTickBoost: false,
      judgmentEcho: false,
      judgmentCdMinusTicks: 0,
      spenderCleavePct: 0,
      splashFirePct: 0,
      arcEvery4th: false,
      critBleedPct: 0,
      critIgniteAll: false,
      critRadiantNova: false,
      spendHealPct: 0,
      hitSlowPct: 0,
      refreshPoisonOnHit: false,
      ragePerSwing: 0,
      healOnKill: 0,
      dualPolarity: false,
      lightningBossDouble: false,
      shockedCritDmg: 0,
      // Campaign Build-Revamping Mutators
      cleaveAdjacent: false,
      physToFireBurn: false,
      physToLigShock: false,
      bleedRefundRes: false,
      bleedSpeedPct: 0,
      echoEvery4th: false,
      critChainArc: false,
      leechPct: 0,
      cdrOnKillTicks: 0,
      poisonExplodeOnDeath: false,
      thornsRetaliate: false,
      activeDescriptions: [],
    };

    for (const def of equippedDefs) {
      if (!def) continue;
      for (const m of def.ruleMutators || []) {
        if (!m) continue;
        if (m.description) mods.activeDescriptions.push({ item: def.name, kind: `Mutator · ${m.name}`, description: m.description });
        if (m.id === "cleave_adjacent") mods.cleaveAdjacent = true;
        if (m.id === "phys_to_fire") mods.physToFireBurn = true;
        if (m.id === "phys_to_lightning") mods.physToLigShock = true;
        if (m.id === "bleed_refund") { mods.bleedRefundRes = true; mods.bleedSpeedPct += 0.30; }
        if (m.id === "spell_echo_4th") mods.echoEvery4th = true;
        if (m.id === "crit_lightning_arc") mods.critChainArc = true;
        if (m.id === "vampiric_leech") mods.leechPct += 0.04;
        if (m.id === "kill_haste_cdr") mods.cdrOnKillTicks += 6;
        if (m.id === "plague_eruption") mods.poisonExplodeOnDeath = true;
        if (m.id === "bastion_thorns") mods.thornsRetaliate = true;
      }
      for (const h of def.hooks || []) {
        if (String(h.kind || "").startsWith("mut:")) continue;
        const desc = h.description || "";
        const low = desc.toLowerCase();
        if (desc) mods.activeDescriptions.push({ item: def.name, kind: h.kind, description: desc });

        if (h.kind === "flail" && low.includes("lightning")) {
          mods.physConvert = { to: "school_lightning", percent: low.includes("50%") ? 0.5 : 1.0 };
        }
        // Conversion patterns: "100% Phys → Fire" or "50% Phys → Lightning"
        const convMatch = desc.match(/(\d+)%\s*Phys\s*(?:→|->)\s*(Fire|Lightning|Poison|Bleed)/i);
        if (convMatch) {
          mods.physConvert = {
            to: `school_${convMatch[2].toLowerCase()}`,
            percent: Math.min(1, Number(convMatch[1]) / 100),
          };
        }
        // School % increased: "+40% Lightning Dmg", "+35% Poison Dmg", "+30% Bleed Dmg", "+45% Melee Physical Dmg"
        for (const sc of ["Physical", "Fire", "Lightning", "Poison", "Bleed"]) {
          const re = new RegExp(`\\+(\\d+)%\\s*(?:Melee\\s+)?${sc}\\s*Dmg`, "i");
          const m = desc.match(re);
          if (m) {
            const sid = `school_${sc.toLowerCase()}`;
            mods.schoolBonus[sid] = (mods.schoolBonus[sid] || 0) + Number(m[1]) / 100;
          }
        }
        // Flat school damage: "+65 Flat Fire Dmg", "+20 Flat Phys"
        const flatMatch = desc.match(/\+(\d+)\s*Flat\s*(Phys|Physical|Fire|Lightning|Poison|Bleed)/i);
        if (flatMatch) {
          const sName = flatMatch[2].toLowerCase().startsWith("phys") ? "physical" : flatMatch[2].toLowerCase();
          const sid = `school_${sName}`;
          mods.flatSchoolDmg[sid] = (mods.flatSchoolDmg[sid] || 0) + Number(flatMatch[1]);
        }

        // Crit Multiplier & Crit Chance
        const cmMatch = desc.match(/\+(\d+)%\s*Crit Multi/i);
        if (cmMatch) mods.critMulti += Number(cmMatch[1]) / 100;
        if (low.includes("fire spells have +12% base critical")) mods.fireCritBonus += 0.12;
        if (low.includes("crit chance vs bleeding")) mods.bleedCritBonus += 0.15;

        // Armor Penetration
        const apMatch = desc.match(/\+(\d+)%\s*Armor Penetration/i);
        if (apMatch) mods.armorPen += Number(apMatch[1]) / 100;

        // Max HP % & Attack Speed adjustments
        const hpMatch = desc.match(/\+(\d+)%\s*Max HP/i);
        if (hpMatch) mods.maxHpPct += Number(hpMatch[1]) / 100;
        if (low.includes("−15% attack speed") || low.includes("-15% attack speed")) mods.hastePct -= 0.15;
        const asMatch = desc.match(/\+(\d+)%\s*(?:Attack Speed|Cast Speed|Haste)/i);
        if (asMatch) mods.hastePct += Number(asMatch[1]) / 100;
        const moreMelee = desc.match(/\+(\d+)%\s*More Melee/i);
        if (moreMelee) mods.meleeMore += Number(moreMelee[1]) / 100;

        // Specific legendary & unique behaviors
        if (low.includes("judgment echoes 0.5s later")) mods.judgmentEcho = true;
        if (low.includes("reduces judgment base cd by 8 ticks")) mods.judgmentCdMinusTicks += 8;
        if (low.includes("melee spenders cleave adjacent")) mods.spenderCleavePct = Math.max(mods.spenderCleavePct, 0.75);
        if (low.includes("splash 40% fire dmg")) mods.splashFirePct = Math.max(mods.splashFirePct, 0.4);
        if (low.includes("every 4th hit arcs to 3 targets")) mods.arcEvery4th = true;
        if (low.includes("critical strikes inflict bleed")) mods.critBleedPct = Math.max(mods.critBleedPct, 0.6);
        if (low.includes("crits ignite all 5 enemy")) mods.critIgniteAll = true;
        if (low.includes("crits trigger radiant nova")) mods.critRadiantNova = true;
        if (low.includes("heals player for 12% max hp")) mods.spendHealPct = Math.max(mods.spendHealPct, 0.12);
        if (low.includes("slow target attack speed by 20%")) mods.hitSlowPct = Math.max(mods.hitSlowPct, 0.2);
        if (low.includes("refresh active poison durations")) mods.refreshPoisonOnHit = true;
        if (low.includes("generates +4 rage per melee")) mods.ragePerSwing += 4;
        if (low.includes("+3 rage generated on hit")) mods.ragePerSwing += 3;
        if (low.includes("+2 hp gained on kill")) mods.healOnKill += 2;
        if (low.includes("alternates +40% fire and +40% lightning")) mods.dualPolarity = true;
        if (low.includes("lightning spells trigger twice against single-target")) mods.lightningBossDouble = true;
        if (low.includes("shocked enemies take +15% crit dmg")) mods.shockedCritDmg += 0.15;
        if (low.includes("below 30% hp")) { mods.executeThreshold = 0.30; mods.executeMore = 1.0; }
        if (low.includes("vs undead and beasts")) mods.vsUndeadBeast += 0.35;
        if (low.includes("burning dot multiplier")) mods.burnMult += 0.30;
        if (low.includes("dot tick speed")) mods.dotSpeedPct += 0.20;
        if (low.includes("bleeds to tick 50% faster")) mods.bleedCritTickBoost = true;
      }
    }
    return mods;
  }

  // Deterministic RNG (mulberry32): same seed ⇒ same fight.
  function mulberry32(seed) {
    let a = seed >>> 0;
    return () => {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  class Combat {
    constructor(data, profile, events, opts = {}) {
      this.data = data;
      this.profile = profile;
      this.events = events;   // { fct, feed, fx, pulse, death, waveEnd, playerDown }
      this.silent = !!opts.silent;
      this.fxTier = this.silent ? 0 : 2;
      this.rnd = mulberry32(profile.seed ?? 20261122);
      this.cls = data.classes?.find(c => c.id === (profile.classId || "templar")) || data.classes?.[0];
      this.botMode = profile.botMode || "optimal";

      const allAbilities = [...(data.abilities || []), ...(profile.customSpells || [])];
      this.hotbarSlots = [0, 1, 2, 3, 4].map(i => {
        const id = (profile.loadout || [])[i];
        if (!id) return null;
        const def = allAbilities.find(a => a.id === id);
        if (!def) {
          if (profile.sandboxEncounter || profile.campaignMode) return null;
          throw new Error(`Loadout references unknown ability: ${id}`);
        }
        return { ...def, slotIndex: i, cooldownRemaining: 0 };
      });
      this.equippedAbilities = this.hotbarSlots.filter(Boolean);

      this.hooks = this.computeHooks();
      this.itemMods = this.computeItemMods();
      this.playerStats = this.computeStats();
      this.holyPowerMax = this.hooks.has("censerOfZeal") ? 10 : 5;
      this.startStage();
    }

    logFeed(msg, cls) {
      if (!this.silent) this.events.feed?.(msg, cls);
    }

    allEquipmentDefs() {
      return [...(this.data.equipment || []), ...(this.profile.customItems || []), ...(this.profile.campaignItems || [])];
    }

    equippedDefs() {
      const allGear = this.allEquipmentDefs();
      return Object.values(this.profile.equipped || {})
        .filter(Boolean)
        .map(id => (typeof id === "object" ? id : allGear.find(e => e.id === id)))
        .filter(Boolean);
    }

    computeItemMods() {
      return parseItemModifiers(this.equippedDefs());
    }

    computeBaseStats() {
      const lvl = this.profile.level || 1;
      const basePower = 14 + lvl * 3.5;
      const stats = {
        maxHp: 380 + lvl * 40,
        attackDamage: basePower,
        spellPower: basePower,
        attackPower: basePower,
        critChance: 0.08,
        critMulti: 0.35,
        haste: 0,
        armor: 0,
        block: 0,
        fireRes: 0,
        lightningRes: 0,
        poisonRes: 0,
        increasedDamage: 0,
        increased: {},
        resourceRegen: this.cls?.resource?.regenPerSec || 0,
      };
      const schoolPctMap = {
        fireDmgPct: "school_fire",
        lightningDmgPct: "school_lightning",
        poisonDmgPct: "school_poison",
        bleedDmgPct: "school_bleed",
        physDmgPct: "school_physical",
      };
      const applyStatMap = (map, mult = 1) => {
        if (!map) return;
        for (const [k, raw] of Object.entries(map)) {
          const v = (Number(raw) || 0) * mult;
          if (!v) continue;
          if (k === "attackPower") {
            stats.attackDamage += v;
            stats.spellPower += v;
          } else if (k === "flatDamage" || k === "attackDamage") {
            stats.attackDamage += v;
          } else if (k === "spellPower") {
            stats.spellPower += v;
          } else if (k === "attackSpeed" || k === "haste") {
            stats.haste += v;
          } else if (k === "str") {
            stats.attackDamage += v * 2;
            stats.maxHp += v * 5;
            if (this.cls?.id === "templar") stats.spellPower += v;
          } else if (k === "agi") {
            stats.attackDamage += v * 1;
            stats.critChance += v * 0.005;
            stats.haste += v * 0.005;
          } else if (k === "int") {
            stats.spellPower += v * 2;
            stats.resourceRegen += v * 0.2;
          } else if (schoolPctMap[k]) {
            const sid = schoolPctMap[k];
            stats.increased[sid] = (stats.increased[sid] || 0) + v;
          } else {
            stats[k] = (stats[k] || 0) + v;
          }
        }
      };

      const applyItemDef = (def) => {
        if (!def) return;
        const upMult = 1 + (def.upgradeLevel || 0) * 0.12;
        applyStatMap(def.stats, upMult);
        for (const a of def.affixes || []) {
          const catBoost = 1 + ((def.catalystBoosts?.[a.tag] || 0) / 100);
          applyStatMap({ [a.stat]: a.value }, upMult * catBoost);
        }
        for (const rune of def.socketedRunes || []) {
          applyItemDef(rune);
        }
      };

      for (const def of this.equippedDefs()) applyItemDef(def);

      for (const ab of this.equippedAbilities || []) {
        if (ab.statBonus) applyStatMap(ab.statBonus, 1);
      }

      for (const [k, v] of Object.entries(this.profile.bonuses || {})) {
        if (k === "attackPower") { stats.attackDamage += v; stats.spellPower += v; }
        else stats[k] = (stats[k] || 0) + v;
      }
      for (const node of this.cls?.tree || []) {
        const rank = this.profile.skillNodes?.[node.id] || 0;
        if (rank) {
          const val = node.value * rank;
          if (node.stat === "attackPower") { stats.attackDamage += val; stats.spellPower += val; }
          else stats[node.stat] = (stats[node.stat] || 0) + val;
        }
      }

      const im = this.itemMods;
      if (im) {
        if (im.maxHpPct) stats.maxHp = Math.round(stats.maxHp * (1 + im.maxHpPct));
        stats.haste = Math.max(0, stats.haste + im.hastePct);
        stats.critMulti += im.critMulti;
      }

      stats.fireRes = Math.min(0.75, Math.max(0, stats.fireRes || 0));
      stats.lightningRes = Math.min(0.75, Math.max(0, stats.lightningRes || 0));
      stats.poisonRes = Math.min(0.75, Math.max(0, stats.poisonRes || 0));
      stats.block = Math.min(0.65, Math.max(0, stats.block || 0));
      stats.attackPower = stats.attackDamage;
      return stats;
    }

    computeStats() {
      const stats = this.computeBaseStats();
      const ov = this.profile.statOverrides;
      if (ov && typeof ov === "object") {
        if (ov.maxHp != null && !Number.isNaN(Number(ov.maxHp))) stats.maxHp = Math.max(1, Number(ov.maxHp));
        if (ov.attackDamage != null && !Number.isNaN(Number(ov.attackDamage))) stats.attackDamage = Math.max(0, Number(ov.attackDamage));
        if (ov.spellPower != null && !Number.isNaN(Number(ov.spellPower))) stats.spellPower = Math.max(0, Number(ov.spellPower));
        if (ov.haste != null && !Number.isNaN(Number(ov.haste))) stats.haste = Math.max(0, Math.min(0.85, Number(ov.haste)));
        if (ov.critChance != null && !Number.isNaN(Number(ov.critChance))) stats.critChance = Math.max(0, Math.min(1, Number(ov.critChance)));
        if (ov.armor != null && !Number.isNaN(Number(ov.armor))) stats.armor = Math.max(0, Number(ov.armor));
        if (ov.resourceRegen != null && !Number.isNaN(Number(ov.resourceRegen))) stats.resourceRegen = Math.max(0, Number(ov.resourceRegen));
      }
      stats.attackPower = stats.attackDamage;
      return stats;
    }

    computeHooks() {
      const set = new Set();
      for (const def of this.equippedDefs()) {
        for (const h of def?.hooks || []) set.add(h.kind);
      }
      return set;
    }

    hasHook(kind) { return this.hooks.has(kind); }

    get zone() { return this.data.zones[this.profile.zoneIndex] || this.data.zones[0]; }
    get exorcismCost() { return this.hooks.has("exoCost3") ? 3 : 5; }

    startStage() {
      const { data, profile } = this;
      const zone = this.zone;
      const rnd = this.rnd;
      const enemies = [];
      let boardSlots = [null, null, null, null, null];

      if (profile.prebuiltWave && Array.isArray(profile.prebuiltWave.enemies)) {
        for (const en of profile.prebuiltWave.enemies) enemies.push(en);
        boardSlots = profile.prebuiltWave.boardSlots || boardSlots;
      } else if (Array.isArray(profile.sandboxEncounter)) {
        profile.sandboxEncounter.forEach((slotCfg, idx) => {
          if (!slotCfg || !slotCfg.enemyId) return;
          const def = data.enemies.find(e => e.id === slotCfg.enemyId) || data.enemies[0];
          const en = computeEncounterEnemy(def, slotCfg, idx);
          enemies.push(en);
          boardSlots[idx] = en;
        });
      } else {
        const pool = zone.enemyPool.map(id => {
          const def = data.enemies.find(e => e.id === id);
          if (!def) throw new Error(`Unknown enemy id in zone pool: ${id}`);
          return def;
        });
        const isBossStage = zone.bossId && profile.stage >= zone.stages - 1;
        const waveSize = isBossStage ? 1 : Math.min(5, 2 + Math.floor(profile.stage / 3));
        const scale = 1 + profile.stage * 0.11 + profile.zoneIndex * 0.35;
        if (isBossStage) {
          const def = data.enemies.find(e => e.id === zone.bossId);
          if (!def) throw new Error(`Unknown boss id in zone: ${zone.bossId}`);
          const en = {
            ...def, uid: 0, slotIndex: 0, rank: "Boss", frame: RANK_MODS.Boss.frame,
            maxHp: def.hp, hp: def.hp,
            attack: def.attack, attackTimer: def.attackIntervalMs / 100 + rnd() * 8,
            attackIntervalTicks: def.attackIntervalMs / 100,
            ailments: {}, lastHitCrit: false, dead: false, comboCdTicks: 0, slowTicks: 0, slowPct: 0,
          };
          enemies.push(en);
          boardSlots[0] = en;
        } else {
          for (let i = 0; i < waveSize; i++) {
            const def = pool[Math.floor(rnd() * pool.length)];
            const en = {
              ...def, uid: i, slotIndex: i, rank: "Normal", frame: RANK_MODS.Normal.frame,
              maxHp: Math.round(def.hp * scale), hp: Math.round(def.hp * scale),
              attack: Math.round(def.attack * scale),
              attackTimer: def.attackIntervalMs / 100 + rnd() * 8,
              attackIntervalTicks: def.attackIntervalMs / 100,
              ailments: {}, lastHitCrit: false, dead: false, comboCdTicks: 0, slowTicks: 0, slowPct: 0,
            };
            enemies.push(en);
            boardSlots[i] = en;
          }
        }
      }

      const rType = this.cls?.resource?.type || "holy_power";
      const rMax = this.resourceMax();
      const startResource = ((Array.isArray(profile.sandboxEncounter) || profile.campaignMode) && (rType === "mana" || rType === "energy")) ? rMax : 0;

      const weap = this.equippedDefs().find(d => d.slot === "weapon");
      const baseSwingInterval = Math.max(8, weap?.swingTicks || 18);

      this.state = {
        enemies,
        initialEnemies: [...enemies],
        boardSlots,
        waveSize: enemies.length,
        playerHp: this.playerStats.maxHp,
        resource: startResource,
        resourceMax: rMax,
        resourceType: rType,
        absorb: 0, stagger: 0, staggerTicks: 0,
        armorBuffRemaining: 0, dodgeRemaining: 0, hasteBuffRemaining: 0,
        gcdRemaining: 0, elapsedMs: 0, ttkMs: null,
        rebukeRemaining: 0, freezeRemaining: 0, highJudgeReady: false,
        bleedSpeedBoostTicks: 0,
        polarityIndex: 0,
        hitCounter: 0,
        castCounter: 0,
        weaponSwingCount: 0,
        weaponSwingTimer: 1,
        weaponSwingInterval: baseSwingInterval,
        pendingEchoes: [],
        lastFatalCause: null,
        botHesitationTicks: 0, botSwitchTicks: 0, lockedTargetSlot: null,
        dpsLog: [], result: null, waveActive: enemies.length > 0,
        timeline: [],
        _maWindow: [],
        _secBucket: { direct: 0, dot: 0, proc: 0, taken: 0 },
        _lastBucketTick: 0,
        stats: {
          damage: 0, damageTaken: 0, casts: 0, totalHits: 0, crits: 0, comboCount: 0,
          dotTicks: 0, dotActiveTicks: 0, kills: 0, killTimesMs: [], lastKillElapsedMs: 0,
          byAbility: {},
          bySourceType: { direct: 0, dot: 0, proc: 0 },
        },
      };
      this.currentTick = 0;

      if (enemies.length > 0) {
        if (this.botMode !== "sloppy") {
          this.autoRotate();
          this.reactives();
        }
        if (this.state.result && !this.silent) this.recordTimelineBucket();
        if (profile.campaignMode) {
          const label = profile.isBossFight ? `ZONE BOSS: ${enemies[0].name}` : `Wave ${profile.campaignWave || 1} — ${enemies.length} ${enemies.length === 1 ? "enemy" : "enemies"}`;
          this.logFeed(`${label} engaged.`, "system");
        } else {
          this.logFeed(`Encounter ready — ${enemies.length} ${enemies.length === 1 ? "enemy" : "enemies"} on the field (${this.botMode} bot).`, "system");
        }
      } else {
        this.logFeed("Board empty — add at least 1 enemy in Encounter to begin.", "system");
      }
    }

    resourceMax() {
      const type = this.cls?.resource?.type;
      if (type === "holy_power") return this.holyPowerMax;
      if (type === "mana") return 100 + (this.profile.level || 1) * 5;
      return 100;
    }

    haste() {
      const bonus = this.state?.hasteBuffRemaining > 0 ? 0.25 : 0;
      return Math.min(0.85, Math.max(0, (this.playerStats?.haste || 0) + bonus));
    }

    tick() {
      const s = this.state;
      if (s.result || !s.enemies.length) return;
      this.currentTick++;
      s.elapsedMs = this.currentTick * 100;
      this.tickTimers();     // Step 1
      this.tickRegen();      // Step 2
      if (!s.result) this.tickEchoes();     // Delayed echoes
      if (!s.result && s.enemies.some(e => !e.dead && Object.values(e.ailments || {}).some(a => a.remaining > 0))) {
        s.stats.dotActiveTicks++;
      }
      if (!s.result) this.tickDots();       // Step 3
      if (!s.result) this.tickEnemies();    // Step 4
      if (!s.result && this.profile.enableWeaponAutoAttack) this.tickWeaponAuto(); // Weapon auto-attack
      if (!s.result) this.autoRotate();     // Step 5
      if (!s.result) this.reactives();      // Step 6
      this.cleanup();        // Step 7
      if (!this.silent && (this.currentTick % 10 === 0 || s.result)) {
        this.recordTimelineBucket();
      }
    }

    tickWeaponAuto() {
      const s = this.state;
      const alive = s.enemies.filter(e => !e.dead);
      if (!alive.length) return;
      const weap = this.equippedDefs().find(d => d.slot === "weapon");
      const baseInterval = Math.max(8, weap?.swingTicks || 18);
      s.weaponSwingInterval = baseInterval;
      s.weaponSwingTimer -= (1 + this.haste());
      if (s.weaponSwingTimer > 0) return;
      s.weaponSwingTimer += baseInterval;
      s.weaponSwingCount++;

      const target = this.pickPrimaryTarget(alive);
      const physSchool = this.data.schools.find(x => x.id === "school_physical") || this.data.schools[0];
      const baseDmg = this.playerStats.attackDamage * 0.65;
      const dealt = this.damageEnemy(target, baseDmg, physSchool, {
        fx: "GS-FX-PHY-IMP",
        abilityId: "weapon:auto",
        abilityName: weap?.name || "Weapon Strike",
      });
      if (dealt) {
        const rType = this.cls?.resource?.type;
        if (rType === "holy_power") {
          if (s.weaponSwingCount % 2 === 0) s.resource = Math.min(s.resourceMax, s.resource + 1);
        } else if (rType === "rage") {
          s.resource = Math.min(s.resourceMax, s.resource + 6);
        } else if (rType === "flow") {
          s.resource = Math.min(s.resourceMax, s.resource + 4);
        } else if (rType === "energy") {
          s.resource = Math.min(s.resourceMax, s.resource + 4);
        } else if (rType === "mana") {
          s.resource = Math.min(s.resourceMax, s.resource + 2);
        }
      }
    }

    recordTimelineBucket() {
      const s = this.state;
      const b = s._secBucket || { direct: 0, dot: 0, proc: 0, taken: 0 };
      const ticksSpan = Math.max(1, this.currentTick - (s._lastBucketTick || 0));
      const spanSec = ticksSpan / 10;
      const rawTotal = Math.round((b.direct + b.dot + b.proc) / spanSec);

      // 3-second (30-tick) moving average filter over combat telemetry
      const win = s._maWindow || [];
      const cutoff = this.currentTick <= 30 ? -1 : this.currentTick - 30;
      while (win.length && win[0].t <= cutoff) win.shift();

      let sumDir = 0, sumDot = 0, sumProc = 0, sumTaken = 0;
      for (const entry of win) {
        if (entry.k === "direct") sumDir += entry.d;
        else if (entry.k === "dot") sumDot += entry.d;
        else if (entry.k === "proc") sumProc += entry.d;
        else if (entry.k === "taken") sumTaken += entry.d;
      }

      const windowSec = Math.min(3.0, Math.max(0.1, this.currentTick / 10));
      const directDps = Math.round(sumDir / windowSec);
      const dotDps = Math.round(sumDot / windowSec);
      const procDps = Math.round(sumProc / windowSec);
      const totalDps = directDps + dotDps + procDps;
      const elapsedSec = Math.max(0.1, s.elapsedMs / 1000);
      const cumDps = Math.round(s.stats.damage / elapsedSec);

      s.timeline.push({
        sec: Number((s.elapsedMs / 1000).toFixed(1)),
        direct: directDps,
        dot: dotDps,
        proc: procDps,
        total: totalDps,
        rawTotal,
        taken: Math.round(sumTaken / windowSec),
        cumDps,
      });
      s._secBucket = { direct: 0, dot: 0, proc: 0, taken: 0 };
      s._lastBucketTick = this.currentTick;
    }

    tickTimers() {
      const s = this.state;
      if (s.gcdRemaining > 0) s.gcdRemaining -= 100;
      for (const a of this.equippedAbilities) {
        if (a.cooldownRemaining > 0) a.cooldownRemaining -= 100;
      }
      if (s.rebukeRemaining > 0) s.rebukeRemaining -= 100;
      if (s.freezeRemaining > 0) s.freezeRemaining -= 100;
      if (s.armorBuffRemaining > 0) s.armorBuffRemaining -= 100;
      if (s.dodgeRemaining > 0) s.dodgeRemaining -= 100;
      if (s.hasteBuffRemaining > 0) s.hasteBuffRemaining -= 100;
      if (s.bleedSpeedBoostTicks > 0) s.bleedSpeedBoostTicks--;
      if (s.botHesitationTicks > 0) s.botHesitationTicks--;
      if (s.botSwitchTicks > 0) s.botSwitchTicks--;
      for (const en of s.enemies) {
        if (en.vulnTicks > 0 && --en.vulnTicks <= 0) en.vulnerable = 0;
        if (en.comboCdTicks > 0) en.comboCdTicks--;
        if (en.slowTicks > 0 && --en.slowTicks <= 0) en.slowPct = 0;
      }
    }

    tickEchoes() {
      const s = this.state;
      if (!s.pendingEchoes.length) return;
      const ready = [];
      const keep = [];
      for (const echo of s.pendingEchoes) {
        echo.ticks--;
        if (echo.ticks <= 0) ready.push(echo);
        else keep.push(echo);
      }
      s.pendingEchoes = keep;
      for (const echo of ready) {
        const target = !echo.target.dead ? echo.target : s.enemies.find(e => !e.dead);
        if (!target) continue;
        const dmg = this.damageEnemy(target, echo.damage, echo.school, {
          isProc: true,
          fx: echo.fx,
          abilityId: echo.abilityId,
          abilityName: echo.abilityName,
        });
        if (dmg) {
          this.events.feed(`[${(s.elapsedMs / 1000).toFixed(1)}s] Bell-Hammer Echo strikes ${target.name} for ${fmt(dmg)}.`, "hook");
        }
      }
    }

    tickRegen() {
      const s = this.state;
      const perSec = this.playerStats?.resourceRegen ?? (this.cls?.resource?.regenPerSec || 0);
      if (perSec > 0) s.resource = Math.min(s.resourceMax, s.resource + perSec / 10);
      if (s.stagger > 0 && --s.staggerTicks <= 0) {
        const pulse = s.stagger / 8;
        s.stagger = Math.max(0, s.stagger - pulse);
        s.staggerTicks = 5;
        if (pulse > 0) {
          const takenAmt = Math.round(pulse);
          s.playerHp = Math.max(0, Math.round(s.playerHp - pulse));
          s.stats.damageTaken += takenAmt;
          if (s._secBucket) s._secBucket.taken += takenAmt;
          if (s._maWindow) s._maWindow.push({ t: this.currentTick, k: "taken", d: takenAmt });
          this.events.fct({ target: null, text: `-${takenAmt}`, crit: false, color: "#c8a44a" });
          if (s.playerHp <= 0 && !s.result) { s.result = "defeat"; s.ttkMs = s.elapsedMs; this.events.playerDown(); }
        }
      }
    }

    tickDots() {
      const s = this.state;
      for (const en of s.enemies) {
        for (const [schoolId, ail] of Object.entries(en.ailments)) {
          if (en.dead) break;
          const school = this.data.schools.find(x => x.id === schoolId);
          ail.remaining -= 1;
          ail.tickAccum += 1;
          const interval = this.dotInterval(ail.baseInterval || 10, schoolId);
          if (ail.tickAccum >= interval) {
            ail.tickAccum -= interval;
            let dotAmt = ail.dps;
            if (schoolId === "school_fire" && this.itemMods?.burnMult) {
              dotAmt *= 1 + this.itemMods.burnMult;
            }
            this.damageEnemy(en, dotAmt, school, {
              dot: true,
              abilityId: ail.abilityId || `dot:${schoolId}`,
              abilityName: ail.abilityName || `${school?.name || "DoT"} Tick`,
              fx: `GS-FX-${schoolId.replace("school_", "").slice(0, 3).toUpperCase()}-AUR`,
            });
            if (schoolId === "school_poison" && this.cls?.resource?.type === "mana") {
              s.resource = Math.min(s.resourceMax, s.resource + s.resourceMax * 0.01);
            }
            if (schoolId === "school_bleed" && this.itemMods?.bleedRefundRes) {
              s.resource = Math.min(s.resourceMax, s.resource + 2);
            }
          }
          if (ail.remaining <= 0) delete en.ailments[schoolId];
        }
      }
    }

    tickEnemies() {
      const s = this.state;
      for (const en of s.enemies) {
        if (en.dead) continue;
        // Support Warder ally heal/shield
        if (en.isWarder) {
          en.wardCooldownTicks = (en.wardCooldownTicks || 50) - 1;
          if (en.wardCooldownTicks <= 0) {
            en.wardCooldownTicks = 55;
            const alive = s.enemies.filter(e => !e.dead);
            const need = alive.reduce((a, b) => (a.hp / a.maxHp <= b.hp / b.maxHp ? a : b));
            const healAmt = Math.max(3, Math.round(need.maxHp * 0.10));
            need.hp = Math.min(need.maxHp, need.hp + healAmt);
            need.wardHp = Math.round((need.wardHp || 0) + healAmt * 0.5);
            if (!this.silent) {
              this.events.fct({ target: need, text: `+${fmt(healAmt)} Ward`, crit: false, color: "#6fe3c2" });
              this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${en.name} wards ${need.name} (+${fmt(healAmt)} HP).`, "system");
            }
          }
        }

        // Campaign Zone Boss mechanics: Enrage at 60s + Posture Stagger + Telegraphed Heavy Cast
        if (en.isCampaignBoss) {
          if (!en.enraged && en.enrageTicks > 0) {
            en.enrageTicks--;
            if (en.enrageTicks <= 0) {
              en.enraged = true;
              en.attack = Math.round(en.attack * 2.5);
              en.attackIntervalTicks = Math.max(8, Math.round(en.attackIntervalTicks * 0.67));
              this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${en.name} ENRAGES (+150% DMG, +50% Speed)!`, "system");
            }
          }
          if (en.staggerTicks > 0) {
            en.staggerTicks--;
            continue;
          }
          if (en.telegraphTicks > 0) {
            en.telegraphTicks--;
            if (en.telegraphTicks <= 0) {
              const heavyDmg = en.attack * 2.4 * (0.95 + this.rnd() * 0.1);
              this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${en.name} unleashes ${en.telegraphName}!`, "system");
              if (!this.silent) this.events.enemySwing?.({ enemy: en });
              this.damagePlayer(heavyDmg, en, { isTelegraph: true, castName: en.telegraphName, schoolId: en.school });
              en.telegraphCooldownTicks = 90;
            }
            continue;
          } else {
            en.telegraphCooldownTicks = (en.telegraphCooldownTicks || 85) - 1;
            if (en.telegraphCooldownTicks <= 0) {
              en.telegraphTicks = en.telegraphMaxTicks || 28;
              this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] WARNING: ${en.name} is casting ${en.telegraphName} (2.8s) — Interrupt or Break Posture!`, "hook");
            }
          }
        }

        const frozen = s.freezeRemaining > 0 && this.hasHook("temporal");
        const slowed = s.rebukeRemaining > 0;
        let speedMult = frozen ? 0 : slowed ? 0.5 : 1;
        if (en.slowTicks > 0 && en.slowPct > 0) speedMult *= (1 - en.slowPct);
        en.attackTimer -= speedMult;
        if (en.attackTimer <= 0) {
          en.attackTimer += en.attackIntervalTicks;
          let dmg = en.attack * (0.9 + this.rnd() * 0.2);
          if (this.hasHook("judgmentReset") && this.rnd() < 0.15) dmg *= 0.85;
          if (!this.silent) this.events.enemySwing?.({ enemy: en });
          this.damagePlayer(dmg, en, { schoolId: en.school });
        }
      }
    }

    damagePlayer(amount, source, opts = {}) {
      const s = this.state;
      let dmg = amount;
      const blockChance = (this.playerStats?.block || 0) + (this.hasHook("judgmentReset") ? 0.15 : 0);
      if (blockChance > 0 && this.rnd() < Math.min(0.65, blockChance)) {
        if (this.hasHook("judgmentReset")) dmg *= 0.25;
        else dmg *= 0.55;
        this.logFeed("Shield Block softens the blow!", "hook");
        if (this.itemMods?.thornsRetaliate && source && !source.dead) {
          const phys = this.data.schools[0];
          const thornsDmg = Math.max(2, Math.round((this.playerStats.armor || 0) * 0.5 + this.playerStats.attackDamage * 0.35));
          this.damageEnemy(source, thornsDmg, phys, { isProc: true, abilityId: "mut:thorns", abilityName: "Bastion Thorns" });
        }
      }
      // Elemental Resistance reduction
      const srcSchool = opts.schoolId || source?.school || "school_physical";
      let res = 0;
      if (srcSchool === "school_fire") res = this.playerStats?.fireRes || 0;
      else if (srcSchool === "school_lightning") res = this.playerStats?.lightningRes || 0;
      else if (srcSchool === "school_poison") res = this.playerStats?.poisonRes || 0;
      if (res > 0) dmg *= (1 - res);

      const armor = this.playerStats?.armor || 0;
      if (armor > 0) dmg *= (1 - armor / (armor + 100));
      if (s.armorBuffRemaining > 0) dmg *= 0.75;
      if (s.dodgeRemaining > 0 && this.rnd() < 0.25) {
        if (!this.silent) this.events.fct({ target: null, text: "DODGE", crit: false, color: "#8fd45f" });
        return;
      }
      if (s.absorb > 0) {
        const soaked = Math.min(s.absorb, dmg);
        s.absorb -= soaked;
        dmg -= soaked;
        if (soaked > 0 && !this.silent) this.events.fct({ target: null, text: `-${Math.round(soaked)}`, crit: false, color: "#3f6fd8" });
      }
      if (dmg <= 0) return;
      if (this.cls?.id === "monk" && dmg > 0) {
        const pool = Math.round(dmg * 0.4);
        s.stagger = Math.round((s.stagger || 0) + pool);
        if (!s.staggerTicks) s.staggerTicks = 5;
        dmg -= pool;
      }
      if (dmg > 0) {
        const takenAmt = Math.round(dmg);
        s.playerHp = Math.max(0, Math.round(s.playerHp - dmg));
        s.stats.damageTaken += takenAmt;
        if (!this.silent && s._secBucket) s._secBucket.taken += takenAmt;
        if (!this.silent && s._maWindow) s._maWindow.push({ t: this.currentTick, k: "taken", d: takenAmt });
        if (!this.silent) this.events.fct({ target: null, text: `-${takenAmt}`, crit: false, color: "#ef6f7d" });
      }
      if (this.itemMods?.thornsRetaliate && source && !source.dead && !opts.noThorns) {
        const phys = this.data.schools[0];
        const thornsDmg = Math.max(2, Math.round((this.playerStats.armor || 0) * 0.5 + this.playerStats.attackDamage * 0.35));
        this.damageEnemy(source, thornsDmg, phys, { isProc: true, abilityId: "mut:thorns", abilityName: "Bastion Thorns" });
      }
      if (this.cls?.id === "warrior") s.resource = Math.min(s.resourceMax, s.resource + 5);
      if (this.hasHook("judgmentReset") && this.rnd() < 0.3) {
        const j = this.equippedAbilities.find(a => a.name === "Judgment");
        if (j) { j.cooldownRemaining = 0; this.logFeed("Aegis resets Judgment!", "hook"); }
      }
      if (s.playerHp <= 0 && !s.result) {
        s.lastFatalCause = {
          sourceName: source?.name || "Enemy Attack",
          school: srcSchool,
          wasEnraged: !!source?.enraged,
          isTelegraph: !!opts.isTelegraph,
          castName: opts.castName || null,
          resPct: res,
        };
        s.result = "defeat";
        s.ttkMs = s.elapsedMs;
        this.events.playerDown();
      }
    }

    evaluateComboReaction(en, incomingSchool) {
      if (!en || !incomingSchool?.comboReactionMultipliers) return null;
      const inKey = incomingSchool.id.replace("school_", "");
      const activeKeys = new Set(Object.keys(en.ailments || {}).map(sid => sid.replace("school_", "")));
      if (en.vulnTicks > 0) activeKeys.add("lightning");

      let best = null;
      for (const act of activeKeys) {
        if (act === inKey) continue;
        const mult = incomingSchool.comboReactionMultipliers[act] || 1;
        if (mult > 1 && (!best || mult > best.mult)) {
          const comboName = COMBO_NAMES[`${inKey}+${act}`] || `${incomingSchool.name} Combo`;
          best = { mult, name: comboName, withSchool: act };
        }
      }
      return best;
    }

    damageEnemy(en, amount, school, opts = {}) {
      if (!en || en.dead) return 0;
      const s = this.state;
      const st = this.playerStats;
      const im = this.itemMods;

      // Stage 1 — Base + flat item school bonuses
      let dmg = amount * (0.92 + this.rnd() * 0.16);
      if (!opts.dot && im?.flatSchoolDmg?.[school?.id]) {
        dmg += im.flatSchoolDmg[school.id];
      }

      // Stage 2 — Conversion (school or item hook or mutator)
      let conv = school?.convert || (school?.id === "school_physical" ? im?.physConvert : null);
      if (!conv && school?.id === "school_physical" && im?.physToFireBurn) conv = { to: "school_fire", percent: 0.25 };
      else if (!conv && school?.id === "school_physical" && im?.physToLigShock) conv = { to: "school_lightning", percent: 0.25 };
      if (conv && conv.percent > 0) {
        const target = this.data.schools.find(x => x.id === conv.to);
        dmg = dmg * (1 - conv.percent) + dmg * conv.percent * (1 + (target?.scaleBonus || 0));
        school = target || school;
      }

      // Stage 3 — Additive (%increased)
      let increased = (school?.increased || 0) + (st.increased?.[school?.id] || 0) + (st.increasedDamage || 0);
      if (im?.schoolBonus?.[school?.id]) increased += im.schoolBonus[school.id];
      if (im?.dualPolarity) {
        if (s.polarityIndex === 0 && school?.id === "school_fire") increased += 0.4;
        if (s.polarityIndex === 1 && school?.id === "school_lightning") increased += 0.4;
      }
      dmg *= 1 + increased;

      // Stage 4 — Multiplicative (%more + execute + undead/beast + school combos)
      for (const m of (school?.more || [])) dmg *= 1 + m;
      if (!opts.dot && im?.meleeMore && school?.id === "school_physical") dmg *= 1 + im.meleeMore;
      if (!opts.dot && im?.executeThreshold && en.hp / en.maxHp < im.executeThreshold) dmg *= 1 + im.executeMore;
      if (!opts.dot && im?.vsUndeadBeast && (en.creatureType === "undead" || en.creatureType === "beast")) {
        dmg *= 1 + im.vsUndeadBeast;
      }

      let comboHit = null;
      if (!opts.dot && !opts.isProc && en.comboCdTicks <= 0) {
        comboHit = this.evaluateComboReaction(en, school);
        if (comboHit) {
          dmg *= comboHit.mult;
          en.comboCdTicks = 5;
          s.stats.comboCount++;
        }
      }

      // Stage 5 — Crit roll
      let critChance = st.critChance;
      if (school?.id === "school_fire" && im?.fireCritBonus) critChance += im.fireCritBonus;
      if (im?.bleedCritBonus && en.ailments?.school_bleed) critChance += im.bleedCritBonus;
      const crit = opts.forcedCrit || (!opts.dot && this.rnd() < critChance);
      if (crit) {
        let multi = 1.5 + (st.critMulti || 0.35);
        if (im?.shockedCritDmg && en.vulnTicks > 0) multi += im.shockedCritDmg;
        dmg *= multi;
      }
      this.lastHitCrit = !!crit && !opts.dot;

      // Stage 6 — Enemy Armor DR / Elem Resist + Vulnerability + Stagger
      const isPhys = school?.id === "school_physical" || school?.id === "school_bleed";
      const effectiveMit = isPhys
        ? Math.max(0, (en.mitigation || 0) * (1 - (im?.armorPen || 0)))
        : Math.max(0, (en.elemResist || 0));
      const staggerBonus = (en.staggerTicks > 0) ? 0.25 : 0;
      dmg *= (1 - effectiveMit) * (1 + (en.vulnerable || 0) + staggerBonus);
      dmg = Math.max(1, Math.round(dmg));

      // Absorb ward on Support Warder targets before HP
      if (en.wardHp > 0) {
        const soaked = Math.min(en.wardHp, dmg);
        en.wardHp -= soaked;
        en.hp -= (dmg - soaked);
      } else {
        en.hp -= dmg;
      }
      s.stats.damage += dmg;
      s.stats.totalHits++;
      if (opts.dot) s.stats.dotTicks++;
      if (!this.silent) s.dpsLog.push({ t: s.elapsedMs, d: dmg });
      if (crit) s.stats.crits++;

      const srcType = opts.dot ? "dot" : opts.isProc ? "proc" : "direct";
      s.stats.bySourceType[srcType] = (s.stats.bySourceType[srcType] || 0) + dmg;
      if (!this.silent && s._secBucket) s._secBucket[srcType] = (s._secBucket[srcType] || 0) + dmg;
      if (!this.silent && s._maWindow) s._maWindow.push({ t: this.currentTick, k: srcType, d: dmg });

      if (!this.silent) {
        const abId = opts.abilityId || "other";
        const abName = opts.abilityName || abId;
        if (!s.stats.byAbility[abId]) {
          s.stats.byAbility[abId] = {
            id: abId, name: abName, color: school?.color || "#e9e2cf",
            damage: 0, casts: 0, hits: 0, crits: 0,
          };
        }
        s.stats.byAbility[abId].damage += dmg;
        s.stats.byAbility[abId].hits++;
        if (crit) s.stats.byAbility[abId].crits++;
      }

      const index = s.enemies.indexOf(en);
      if (!opts.dot && !opts.isProc) s.lastTargetSlot = en.slotIndex;
      if (!this.silent && this.fxTier >= 0) {
        const txt = comboHit ? `${fmt(dmg)} ${comboHit.name}!` : (crit ? `${fmt(dmg)}!` : fmt(dmg));
        this.events.fct({ target: en, index, text: txt, crit: crit || !!comboHit, color: school?.color || "#fff" });
        if (this.fxTier >= 1 || crit) this.events.fx(opts.fx || "GS-FX-PHY-IMP", { target: en, color: school?.color || "#fff", crit });
      }
      if (comboHit) {
        this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${comboHit.name}! (${comboHit.mult.toFixed(2)}× reaction on ${en.name})`, "hook");
      }

      // Boss Posture damage on direct non-DoT hits
      if (en.isCampaignBoss && !en.dead && !opts.dot && en.staggerTicks <= 0) {
        const pMult = opts.postureMult || 1.0;
        en.posture = Math.max(0, (en.posture ?? 100) - 8 * pMult);
        if (en.posture <= 0) {
          en.staggerTicks = 25; // 2.5s Stagger
          en.posture = en.maxPosture || 100;
          if (en.telegraphTicks > 0) {
            en.telegraphTicks = 0;
            en.telegraphCooldownTicks = 95;
            this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] POSTURE BROKEN! Interrupted ${en.telegraphName}!`, "hook");
          } else {
            this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${en.name} STAGGERED (+25% dmg taken for 2.5s)!`, "hook");
          }
          if (!this.silent) {
            this.events.fct({ target: en, index, text: "STAGGER!", crit: true, color: "#f4d98b" });
            this.events.death?.(en);
          }
        }
      }

      // On-hit & On-crit item hooks + Campaign Mutators (only from non-dot, non-proc hits)
      if (!opts.dot && !opts.isProc) {
        if (im?.leechPct > 0 && s.playerHp < st.maxHp) {
          const leech = Math.max(1, Math.round(dmg * im.leechPct));
          s.playerHp = Math.min(st.maxHp, s.playerHp + leech);
        }
        if (im?.physToFireBurn && !en.dead && this.rnd() < 0.45) {
          en.ailments.school_fire = {
            dps: Math.max(1, dmg * 0.22), remaining: 30, tickAccum: 0, baseInterval: 10,
            abilityId: "mut:cinderbrand", abilityName: "Cinderbrand Burn",
          };
        }
        if (im?.physToLigShock && !en.dead && this.rnd() < 0.30) {
          en.vulnerable = (en.vulnerable || 0) + 0.25;
          en.vulnTicks = Math.max(en.vulnTicks || 0, 30);
        }
        if (im?.cleaveAdjacent && !opts.isCleave) {
          const adj = s.enemies.filter(e => !e.dead && e !== en).slice(0, 2);
          for (const other of adj) {
            this.damageEnemy(other, amount * 0.65, school, {
              isProc: true, isCleave: true, fx: opts.fx || "GS-FX-PHY-CHN",
              abilityId: "mut:cleave", abilityName: "Sweeping Cleave",
            });
          }
        }
        if (crit && im?.critChainArc) {
          const ligSchool = this.data.schools.find(x => x.id === "school_lightning");
          const arcTargets = s.enemies.filter(e => !e.dead).slice(0, 2);
          for (const t of arcTargets) {
            this.damageEnemy(t, st.spellPower * 0.45, ligSchool, {
              isProc: true, fx: "GS-FX-LIG-CHN", abilityId: "mut:critArc", abilityName: "Arcing Precision",
            });
          }
        }
        this.resolveHitItemHooks(en, dmg, school, crit);
      }

      if (en.hp <= 0) this.onEnemyDeath(en);
      return dmg;
    }

    resolveHitItemHooks(en, dmg, school, crit) {
      const s = this.state;
      const im = this.itemMods;
      if (!im) return;
      s.hitCounter++;

      if (im.hitSlowPct && !en.dead) {
        en.slowPct = im.hitSlowPct;
        en.slowTicks = 10;
      }
      if (im.refreshPoisonOnHit && en.ailments?.school_poison) {
        en.ailments.school_poison.remaining = Math.max(en.ailments.school_poison.remaining, 50);
      }
      if (im.ragePerSwing && this.cls?.resource?.type === "rage") {
        s.resource = Math.min(s.resourceMax, s.resource + im.ragePerSwing);
      }
      if (im.splashFirePct > 0) {
        const fireSchool = this.data.schools.find(x => x.id === "school_fire");
        const neighbors = s.enemies.filter(e => !e.dead && e !== en && Math.abs(e.slotIndex - en.slotIndex) <= 1);
        for (const nb of neighbors) {
          this.damageEnemy(nb, dmg * im.splashFirePct, fireSchool, {
            isProc: true, fx: "GS-FX-FIR-IMP",
            abilityId: "hook:fireSplash", abilityName: "Censer Fire Splash",
          });
        }
      }
      if (im.arcEvery4th && s.hitCounter % 4 === 0) {
        const ligSchool = this.data.schools.find(x => x.id === "school_lightning");
        const targets = s.enemies.filter(e => !e.dead).slice(0, 3);
        for (const t of targets) {
          this.damageEnemy(t, this.playerStats.spellPower * 0.75, ligSchool, {
            isProc: true, fx: "GS-FX-LIG-CHN",
            abilityId: "hook:thunderArc", abilityName: "Thunderclap Arc",
          });
        }
        this.events.feed(`[${(s.elapsedMs / 1000).toFixed(1)}s] Thunderclap Mallet arcs across ${targets.length} targets!`, "hook");
      }
      if (crit) {
        if (im.bleedCritTickBoost) s.bleedSpeedBoostTicks = 15;
        if (im.critBleedPct && !en.dead) {
          en.ailments.school_bleed = {
            dps: Math.max(1, dmg * im.critBleedPct / 4),
            remaining: 40, tickAccum: 0, baseInterval: 10,
            abilityId: "hook:critBleed", abilityName: "Blood-Drenched Bleed",
          };
        }
        if (im.critIgniteAll) {
          const fireSchool = this.data.schools.find(x => x.id === "school_fire");
          for (const t of s.enemies.filter(e => !e.dead)) {
            t.ailments.school_fire = {
              dps: Math.max(1, dmg * 0.15),
              remaining: 40, tickAccum: 0, baseInterval: 10,
              abilityId: "hook:sunforgeIgnite", abilityName: "Sunforged Ignite",
            };
          }
          this.events.feed(`[${(s.elapsedMs / 1000).toFixed(1)}s] Sunforged Sledge ignites all enemies!`, "hook");
        }
        if (im.critRadiantNova) {
          const fireSchool = this.data.schools.find(x => x.id === "school_fire");
          for (const t of s.enemies.filter(e => !e.dead)) {
            this.damageEnemy(t, this.playerStats.spellPower * 0.6, fireSchool, {
              isProc: true, fx: "GS-FX-FIR-BST",
              abilityId: "hook:radiantNova", abilityName: "Dawnbreaker Nova",
            });
          }
        }
      }
    }

    resolveSpellProc(ability, triggerType, primaryTarget) {
      const proc = ability.proc;
      if (!proc || proc.trigger !== triggerType) return;
      const chance = Math.min(1, Math.max(0, Number(proc.chance ?? 1)));
      if (this.rnd() >= chance) return;

      const s = this.state;
      const alive = s.enemies.filter(e => !e.dead);
      const target = (primaryTarget && !primaryTarget.dead) ? primaryTarget : alive[0];
      const procSchool = this.data.schools.find(x => x.id === (proc.school || ability.school)) || this.data.schools[0];

      if (proc.effect === "bonus_hit" && target) {
        const isMagic = ["school_fire", "school_lightning", "school_poison"].includes(procSchool.id);
        const stat = isMagic ? this.playerStats.spellPower : this.playerStats.attackDamage;
        const pct = Math.max(0.1, Number(proc.value || 50) / 100);
        const dealt = this.damageEnemy(target, stat * pct, procSchool, {
          isProc: true,
          fx: this.kitFx({ fx: "CHN" }, procSchool),
          abilityId: `${ability.id}:proc`,
          abilityName: `${ability.name} (Proc)`,
        });
        if (dealt) this.events.feed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${ability.name} proc strikes ${target.name} for ${fmt(dealt)}.`, "hook");
      } else if (proc.effect === "apply_shock" && target) {
        target.vulnerable = (target.vulnerable || 0) + 0.3;
        target.vulnTicks = 30;
        this.events.feed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${ability.name} proc Shocks ${target.name} (+30% vuln).`, "hook");
      } else if (proc.effect === "restore_res") {
        const gain = Math.max(1, Number(proc.value || 10));
        s.resource = Math.min(s.resourceMax, s.resource + gain);
        this.events.feed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${ability.name} proc restores +${gain} ${this.cls?.resource?.label || "Resource"}.`, "resource");
      } else if (proc.effect === "heal_pct") {
        const heal = Math.max(1, Math.round(this.playerStats.maxHp * (Number(proc.value || 5) / 100)));
        s.playerHp = Math.min(this.playerStats.maxHp, s.playerHp + heal);
        this.events.fct({ target: null, text: `+${fmt(heal)}`, crit: false, color: "#8fd45f" });
        this.events.feed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${ability.name} proc heals +${heal} HP.`, "hook");
      }
    }

    onEnemyDeath(en) {
      if (en.dead) return;
      en.dead = true; en.hp = 0;
      const s = this.state;
      s.stats.kills++;
      const killDeltaMs = Math.max(100, s.elapsedMs - (s.stats.lastKillElapsedMs || 0));
      s.stats.lastKillElapsedMs = s.elapsedMs;
      s.stats.killTimesMs.push(killDeltaMs);
      if (this.itemMods?.healOnKill) {
        s.playerHp = Math.min(this.playerStats.maxHp, s.playerHp + this.itemMods.healOnKill);
      }
      if (this.itemMods?.cdrOnKillTicks > 0) {
        const ms = this.itemMods.cdrOnKillTicks * 100;
        for (const ab of this.equippedAbilities) {
          if (ab.cooldownRemaining > 0) ab.cooldownRemaining = Math.max(0, ab.cooldownRemaining - ms);
        }
      }
      if (this.itemMods?.poisonExplodeOnDeath && en.ailments?.school_poison) {
        const poiSchool = this.data.schools.find(x => x.id === "school_poison");
        const alive = s.enemies.filter(e => !e.dead && e !== en);
        for (const t of alive) {
          this.damageEnemy(t, this.playerStats.spellPower * 1.2, poiSchool, {
            isProc: true, fx: "GS-FX-POI-BST", abilityId: "mut:plagueRupture", abilityName: "Blight Rupture",
          });
        }
      }
      if (this.botMode === "casual" && s.lockedTargetSlot === en.slotIndex) {
        s.lockedTargetSlot = null;
        s.botSwitchTicks = 4;
      }
      if (!Array.isArray(this.profile.sandboxEncounter) && !this.profile.campaignMode) {
        const zone = this.zone;
        const gold = Math.round(zone.baseRewardGold * (0.6 + this.rnd() * 0.9));
        this.profile.gold = (this.profile.gold || 0) + gold;
        this.logFeed(`${en.name} dies. +${gold} gold.`, "loot");
        if (!this.silent) this.events.loot?.({ text: `+${gold} gold`, kind: "gold", color: "#e7c35c", elapsedMs: s.elapsedMs });
        this.rollLoot(en);
      } else if (Array.isArray(this.profile.sandboxEncounter)) {
        this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${en.name} (Slot ${en.slotIndex}) defeated!`, "loot");
      }
      if (!this.silent) this.events.death(en);
      if (s.enemies.every(e => e.dead)) this.endWave();
    }

    rollLoot(en) {
      const zone = this.zone;
      if (en.boss) { this.rollBossLoot(en); return; }
      if (this.rnd() >= (zone.dropChance ?? 0.22)) return;
      if (!Array.isArray(this.profile.bag)) this.profile.bag = [];
      const pool = this.data.equipment.filter(e => e.id.startsWith("GS-EQP-C"));
      const weights = { Common: 38, Magic: 30, Rare: 18, Epic: 9, Legendary: 3.5, Unique: 1.5 };
      const bag = [];
      let total = 0;
      for (const it of pool) { const w = weights[it.rarity] || 10; bag.push([w, it]); total += w; }
      let roll = this.rnd() * total, drop = bag[0][1];
      for (const [w, it] of bag) { roll -= w; if (roll <= 0) { drop = it; break; } }
      const counts = { 2: 1, 3: 2, 4: 3, 5: 4 };
      const n = counts[drop.tier] || 0;
      const eligible = this.data.affixes.filter(a => a.stat);
      const affixes = [];
      for (let i = 0; i < n && eligible.length; i++) {
        const a = eligible[Math.floor(this.rnd() * eligible.length)];
        if (!affixes.includes(a)) affixes.push(a);
      }
      const dropped = { ...drop, stats: { ...drop.stats }, affixes: affixes.map(a => ({ stat: a.stat, value: a.value, name: a.name })) };
      dropped.id = `${drop.id}~${Math.floor(this.rnd() * 1e9).toString(36)}`;
      dropped.name = affixes.length ? `${affixes.map(a => a.name).slice(-1)[0]} ${drop.name}` : drop.name;
      this.profile.bag.push(dropped.id);
      this.data.equipment.push(dropped);
      this.events.feed(`${dropped.name} drops!`, "loot");
      if (!this.silent) this.events.loot?.({ text: dropped.name, kind: "item", rarity: dropped.rarity, elapsedMs: this.state.elapsedMs });
    }

    rollBossLoot(en) {
      const pool = this.data.equipment.filter(e => ["Rare", "Epic", "Legendary", "Unique"].includes(e.rarity));
      const drop = pool[Math.floor(this.rnd() * pool.length)];
      const affixCount = { 3: 2, 4: 3, 5: 4 }[drop.tier] || 2;
      const eligible = this.data.affixes.filter(a => a.stat);
      const affixes = [];
      for (let i = 0; i < affixCount && eligible.length; i++) {
        const a = eligible[Math.floor(this.rnd() * eligible.length)];
        if (!affixes.includes(a)) affixes.push(a);
      }
      const dropped = { ...drop, stats: { ...drop.stats }, affixes: affixes.map(a => ({ stat: a.stat, value: a.value, name: a.name })) };
      dropped.id = `${drop.id}~${Math.floor(this.rnd() * 1e9).toString(36)}`;
      dropped.name = `${affixes.map(a => a.name).slice(-1)[0] || ""} ${drop.name}`.trim();
      if (!Array.isArray(this.profile.bag)) this.profile.bag = [];
      this.profile.bag.push(dropped.id);
      this.data.equipment.push(dropped);
      this.events.feed(`${en.name} is slain! ${dropped.name} drops!`, "loot");
      if (!this.silent) this.events.loot?.({ text: dropped.name, kind: "item", rarity: dropped.rarity, elapsedMs: this.state.elapsedMs });
    }

    endWave() {
      const s = this.state;
      s.waveActive = false;
      s.result = "victory";
      s.ttkMs = s.elapsedMs;
      if (!Array.isArray(this.profile.sandboxEncounter) && !this.profile.campaignMode) {
        const bossCleared = this.profile.stage >= this.zone.stages - 1;
        if (bossCleared) this.profile.stage = 0;
        this.profile.shards = (this.profile.shards || 0) + this.zone.baseRewardShards;
      }
      if (!this.profile.campaignMode) {
        this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] Victory! Encounter cleared in ${(s.elapsedMs / 1000).toFixed(1)}s.`, "loot");
      }
      this.events.waveEnd("victory");
    }

    dps() {
      const s = this.state;
      if (!s || !s.stats.damage) return 0;
      if (s.result && s.elapsedMs > 0) {
        return Math.round(s.stats.damage / (s.elapsedMs / 1000));
      }
      const cutoff = s.elapsedMs - 3000;
      while (s.dpsLog.length && s.dpsLog[0].t < cutoff) s.dpsLog.shift();
      if (!s.dpsLog.length) return 0;
      const span = Math.max(500, s.elapsedMs - s.dpsLog[0].t);
      return Math.round(s.dpsLog.reduce((a, e) => a + e.d, 0) / (span / 1000));
    }

    dotInterval(base = 10, schoolId = null) {
      let interval = base / (1 + this.haste() + (this.itemMods?.dotSpeedPct || 0));
      if (schoolId === "school_bleed" && this.cls?.id === "nightblade") interval /= 1.2;
      if (schoolId === "school_bleed" && this.itemMods?.bleedSpeedPct) interval /= (1 + this.itemMods.bleedSpeedPct);
      if (schoolId === "school_bleed" && this.state?.bleedSpeedBoostTicks > 0) interval /= 1.5;
      return Math.max(1, Math.round(interval));
    }

    autoRotate() {
      const s = this.state;
      if (s.botHesitationTicks > 0 || s.botSwitchTicks > 0) return;

      let candidates = this.equippedAbilities;
      if (this.botMode === "sloppy" && candidates.length > 1) {
        candidates = candidates.slice();
        for (let i = candidates.length - 1; i > 0; i--) {
          const j = Math.floor(this.rnd() * (i + 1));
          [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
        }
      }

      for (const ability of candidates) {
        if (ability.autoCast) continue;
        if (ability.cooldownRemaining > 0) continue;
        if (s.gcdRemaining > 0 && ability.gcd !== false) continue;
        if (this.cast(ability)) {
          if (this.botMode === "casual") s.botHesitationTicks = 1;
          else if (this.botMode === "sloppy") s.botHesitationTicks = 2 + Math.floor(this.rnd() * 4);
          return;
        }
      }
    }

    spendCost(ability) {
      if (!ability.autoCast) return ability.resourceCost || 0;
      return this.cls?.resource?.type === "holy_power" && ability.name === "Exorcism"
        ? this.exorcismCost
        : (ability.resourceCost || 0);
    }

    reactives() {
      const s = this.state;
      if (this.botMode === "sloppy" && s.botHesitationTicks > 0) return;
      const spenders = this.equippedAbilities.filter(a => a.autoCast);
      if (!spenders.length || spenders.every(x => x.cooldownRemaining > 0)) {
        s.resource = Math.min(s.resource, s.resourceMax);
        return;
      }
      for (const spender of spenders) {
        if (spender.cooldownRemaining > 0) continue;
        if (s.resource < this.spendCost(spender)) continue;
        if (this.cls?.resource?.type === "holy_power" && spender.name === "Exorcism" && this.hasHook("censerOfZeal") && s.rebukeRemaining <= 0) continue;
        if (this.cast(spender)) break;
      }
      s.resource = Math.min(s.resource, s.resourceMax);
    }

    cleanup() {
      const s = this.state;
      if (s.enemies.some(e => e.dead)) {
        s.enemies = s.enemies.filter(e => !e.dead);
        s.enemies.forEach((e, i) => { e.uid = i; });
      }
    }

    pickPrimaryTarget(alive) {
      const s = this.state;
      if (this.botMode === "sloppy") {
        return alive[Math.floor(this.rnd() * alive.length)];
      }
      if (this.botMode === "casual") {
        let locked = alive.find(e => e.slotIndex === s.lockedTargetSlot);
        if (!locked) {
          locked = alive[0];
          s.lockedTargetSlot = locked.slotIndex;
        }
        return locked;
      }
      return alive.reduce((a, b) => (a.hp <= b.hp ? a : b));
    }

    cast(ability) {
      const s = this.state;
      const im = this.itemMods;
      const alive = s.enemies.filter(e => !e.dead);
      if (!alive.length) return false;

      if (this.cls?.resource?.type === "holy_power" && this.hasHook("hourglass") && ability.name === "Exorcism") {
        s.resource = Math.min(s.resourceMax, s.resource + 5);
        this.events.feed("Hourglass of Inversion: Exorcism generates 5 Holy Power.", "hook");
      } else {
        const templar = this.cls?.resource?.type === "holy_power";
        const spend = templar && this.hasHook("hourglass") && ability.name !== "Exorcism" && ability.name !== "Rebuke"
          ? Math.min(s.resource, 2) : 0;
        const cost = this.spendCost(ability);
        if (cost && s.resource < cost) return false;
        s.resource -= cost + spend;
        if (cost >= 5 && im?.spendHealPct) {
          const heal = Math.round(this.playerStats.maxHp * im.spendHealPct);
          s.playerHp = Math.min(this.playerStats.maxHp, s.playerHp + heal);
          this.events.fct({ target: null, text: `+${fmt(heal)}`, crit: false, color: "#8fd45f" });
        }
        const gain = this.gainHolyPower(ability.resourceGain || 0, ability);
        if (gain) this.events.feed(`+${gain} ${this.cls?.resource?.label || "Resource"}`, "resource");
      }

      const h = Math.min(0.85, this.haste());
      let baseCdMs = ability.cooldownMs || 0;
      if (ability.name === "Judgment" && im?.judgmentCdMinusTicks) {
        baseCdMs = Math.max(0, baseCdMs - im.judgmentCdMinusTicks * 100);
      }
      const cdTicks = baseCdMs / 100 * (1 - h);
      const whole = Math.ceil(cdTicks);
      ability.cooldownRemaining = whole * 100;
      ability.fractionalCarry = cdTicks - whole;
      if (ability.gcd !== false) s.gcdRemaining = GCD_BASE_MS * (1 - h);
      s.stats.casts++;
      if (!s.stats.byAbility[ability.id]) {
        const sc = this.data.schools.find(x => x.id === ability.school);
        s.stats.byAbility[ability.id] = {
          id: ability.id, name: ability.name, color: sc?.color || "#e9e2cf",
          damage: 0, casts: 0, hits: 0, crits: 0,
        };
      }
      s.stats.byAbility[ability.id].casts++;
      this.events.pulse(ability.id);

      const school = this.data.schools.find(x => x.id === ability.school) || this.data.schools[0];
      let targets = alive;
      if (ability.targetType === "single") {
        targets = [this.pickPrimaryTarget(alive)];
      } else if (ability.targetType === "cleave") {
        const primary = this.pickPrimaryTarget(alive);
        const others = alive.filter(e => e !== primary)
          .sort((a, b) => Math.abs(a.slotIndex - primary.slotIndex) - Math.abs(b.slotIndex - primary.slotIndex));
        targets = [primary, ...others.slice(0, 2)];
      } else if (ability.targetType === "snipe") {
        targets = [alive.reduce((a, b) => (a.maxHp >= b.maxHp ? a : b))];
      }

      if (ability.name === "Rebuke") {
        s.rebukeRemaining = 500;
        if (this.hasHook("temporal")) { s.freezeRemaining = 1500; this.logFeed("Temporal Binding freezes the field!", "hook"); }
        for (const boss of alive.filter(e => e.isCampaignBoss && e.telegraphTicks > 0)) {
          boss.telegraphTicks = 0;
          boss.telegraphCooldownTicks = 95;
          this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] Rebuke INTERRUPTS ${boss.telegraphName}!`, "hook");
          if (!this.silent) this.events.fct({ target: boss, text: "INTERRUPTED!", crit: true, color: "#6fe3c2" });
        }
        if (!this.silent) this.events.fx(`GS-FX-${school.id.replace("school_", "").slice(0, 3).toUpperCase()}-AUR`, { target: null });
        this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] Rebuke! Enemy assault slows.`, "cast");
        this.resolveSpellProc(ability, "onCast", alive[0]);
        return true;
      }

      if (ability.name === "Judgment" && this.hasHook("heretic")) {
        s.playerHp = Math.max(1, Math.round(s.playerHp * 0.95));
        ability.cooldownRemaining = 0;
        this.logFeed("Rune of the Heretic: no cooldown, 5% life paid.", "hook");
      }
      if (ability.name === "Judgment" && this.hasHook("flail")) targets = alive;

      if (ability.targetType === "self") {
        if (ability.name === "Iron Warcry") s.armorBuffRemaining = 4000;
        if (ability.name === "Shadow Veil") {
          s.dodgeRemaining = 3000; s.hasteBuffRemaining = 3000;
          for (const boss of alive.filter(e => e.isCampaignBoss && e.telegraphTicks > 0)) {
            boss.telegraphTicks = 0;
            boss.telegraphCooldownTicks = 95;
            this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] Shadow Veil INTERRUPTS ${boss.telegraphName}!`, "hook");
          }
        }
        if (ability.name === "Aegis Ward") s.absorb = Math.round(this.playerStats.spellPower * 2.0);
        if (ability.name === "Purifying Brew") s.stagger = Math.round((s.stagger || 0) * 0.4);
        if (!this.silent) this.events.fx(this.kitFx(ability, school), { target: null });
        this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${ability.name}!`, "cast");
        this.resolveSpellProc(ability, "onCast", alive[0]);
        return true;
      }

      if (ability.name === "Tempest Kick") {
        for (const boss of alive.filter(e => e.isCampaignBoss && e.telegraphTicks > 0)) {
          boss.telegraphTicks = 0;
          boss.telegraphCooldownTicks = 95;
          this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] Tempest Kick INTERRUPTS ${boss.telegraphName}!`, "hook");
          if (!this.silent) this.events.fct({ target: boss, text: "INTERRUPTED!", crit: true, color: "#6fe3c2" });
        }
      }

      // Resolve onCast proc before hits
      this.resolveSpellProc(ability, "onCast", targets[0]);

      const effSchool = (school.id === "school_physical" && im?.physConvert?.percent >= 0.5)
        ? (this.data.schools.find(x => x.id === im.physConvert.to) || school)
        : school;
      this.events.projectile?.({
        ability,
        school: effSchool,
        slotIndex: ability.slotIndex ?? 0,
        targetSlots: targets.filter(e => !e.dead).map(e => e.slotIndex),
        fxKey: this.kitFx({ ...ability, fx: "PRJ" }, effSchool),
      });

      s.castCounter = (s.castCounter || 0) + 1;
      const echoTriggered = !!(im?.echoEvery4th && (s.castCounter % 4 === 0));
      const repeatCount = ((im?.lightningBossDouble && school.id === "school_lightning" && alive.length === 1 && alive[0].rank === "Boss") ? 2 : 1) + (echoTriggered ? 1 : 0);
      const postureMult = (ability.name === "Skullsplitter" ? 2.0 : ability.name === "Jabbing Palm" ? 1.5 : 1.0);

      if (echoTriggered && !this.silent && targets.length) {
        const aliveTargets = targets.filter(e => !e.dead);
        if (aliveTargets.length) {
          this.events.projectile?.({
            ability,
            school: effSchool,
            slotIndex: ability.slotIndex ?? 0,
            targetSlots: aliveTargets.map(e => e.slotIndex),
            fxKey: "GS-FX-LIG-PRJ",
          });
          this.events.fct({
            target: aliveTargets[0],
            index: s.enemies.indexOf(aliveTargets[0]),
            text: "ECHO!",
            crit: true,
            color: "#6fe3c2",
          });
        }
        this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] Chrono Reverberation echoes ${ability.name}!`, "hook");
      }

      for (let rep = 0; rep < repeatCount; rep++) {
        const isEchoRep = echoTriggered && rep === repeatCount - 1;
        for (const en of targets) {
          if (en.dead) continue;
          let dmg = this.baseDamage(ability, school) * (isEchoRep ? 0.75 : 1.0);
          const schoolId = school.id.replace("school_", "").slice(0, 3).toUpperCase();
          if (ability.name === "Holy Strike") {
            if (this.hasHook("greathammer")) dmg *= 1.3;
            if (this.hasHook("bleedingLight")) {
              en.ailments.school_bleed = {
                dps: dmg * 0.25, remaining: 40, tickAccum: 0, baseInterval: 10,
                abilityId: ability.id, abilityName: `${ability.name} (Bleed)`,
              };
              this.logFeed("Bleeding Light opens a wound.", "hook");
            }
          }
          if (ability.name === "Judgment" && this.hasHook("flail")) dmg *= 0.6;
          if (ability.name === "Judgment" && im?.judgmentEcho && rep === 0) {
            s.pendingEchoes.push({
              ticks: 5, target: en, damage: dmg * 0.6, school,
              fx: `GS-FX-${schoolId}-PRJ`,
              abilityId: "hook:bellEcho", abilityName: "Judgment (Echo)",
            });
          }

          if (ability.name === "Exorcism") {
            const undeadLike = en.creatureType === "undead" || en.creatureType === "demon" ||
              (this.hasHook("executioner") && en.hp / en.maxHp < 0.35);
            if (this.hasHook("blackSun")) {
              for (const other of alive) if (other !== en && !other.dead) {
                other.ailments.school_poison = {
                  dps: dmg * 0.15, remaining: 50, tickAccum: 0, baseInterval: 10,
                  abilityId: ability.id, abilityName: `${ability.name} (Plague)`,
                };
              }
              this.logFeed("Black Sun plague spreads!", "hook");
            }
            const consumed = this.consumeBleeds(en);
            const dealt = this.damageEnemy(en, dmg + consumed, school, {
              forcedCrit: undeadLike, fx: `GS-FX-${schoolId}-BST`, postureMult,
              abilityId: ability.id, abilityName: ability.name, isProc: isEchoRep,
            });
            this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${ability.name} hits ${en.name} for ${fmt(dealt)}.`, "cast");
            if (dealt && !isEchoRep) {
              this.resolveSpellProc(ability, "onHit", en);
              if (this.lastHitCrit) this.resolveSpellProc(ability, "onCrit", en);
            }
            continue;
          }

          const hit = this.damageEnemy(en, dmg, school, {
            fx: this.kitFx(ability, school), postureMult,
            abilityId: isEchoRep ? `${ability.id}:echo` : ability.id,
            abilityName: isEchoRep ? `${ability.name} (Echo)` : ability.name,
            isProc: isEchoRep,
          });
          if (hit && targets[0] === en && rep === 0) {
            this.logFeed(`[${(s.elapsedMs / 1000).toFixed(1)}s] ${ability.name} → ${en.name}${targets.length > 1 ? ` (+${targets.length - 1})` : ""} (${fmt(hit)}).`, "cast");
          }
          if (hit && ability.role === "finisher" && im?.spenderCleavePct > 0) {
            const adj = alive.filter(e => !e.dead && e !== en && Math.abs(e.slotIndex - en.slotIndex) <= 1);
            for (const other of adj) {
              this.damageEnemy(other, dmg * im.spenderCleavePct, school, {
                isProc: true, fx: this.kitFx(ability, school),
                abilityId: "hook:earthshatter", abilityName: "Earthshatter Cleave",
              });
            }
          }
          if (hit && !isEchoRep) {
            this.resolveSpellProc(ability, "onHit", en);
            if (this.lastHitCrit) this.resolveSpellProc(ability, "onCrit", en);
          }
          if (hit && this.cls?.id === "monk" && ability.refundFlowOnCrit && this.lastHitCrit) {
            s.resource = Math.min(s.resourceMax, s.resource + ability.refundFlowOnCrit);
          }
          if (hit && ability.applies?.shock) {
            en.vulnerable = (en.vulnerable || 0) + ability.applies.shock.vuln;
            en.vulnTicks = ability.applies.shock.duration || 30;
          }
          if (hit && ability.spreadsBleed) {
            const src = en.ailments.school_bleed;
            for (const other of alive) if (other !== en && !other.dead && (src || ability.name === "Whirlwind Cleave")) {
              other.ailments.school_bleed = {
                dps: dmg * (src ? src.dps / Math.max(1, dmg) : ability.spreadsBleed.dpsPct),
                remaining: ability.spreadsBleed.duration || 40, tickAccum: 0,
                baseInterval: ability.spreadsBleed.interval,
                abilityId: ability.id, abilityName: `${ability.name} (Bleed)`,
              };
            }
          }
          if (hit && ability.applies?.dot) {
            const dotSchoolId = typeof ability.applies.dot === "string" ? ability.applies.dot : school.id;
            const t = this.cls?.id === "warrior" && ability.name === "Bloodletting Strike" ? 0.5 : (ability.applies.dpsPct || 0.35);
            en.ailments[dotSchoolId] = {
              dps: Math.max(1, dmg * t),
              remaining: ability.applies.duration || 40,
              tickAccum: 0,
              baseInterval: ability.applies.interval || 10,
              abilityId: ability.id,
              abilityName: `${ability.name} (DoT)`,
            };
          }
          if (hit && this.cls?.id === "warrior" && this.lastHitCrit) {
            s.resource = Math.min(s.resourceMax, s.resource + 5);
          }
          if (ability.name === "Judgment" && hit && this.rnd() < this.playerStats.critChance && this.hasHook("highJudge")) {
            s.highJudgeReady = true;
            this.logFeed("Signet of the High Judge: next Holy Strike surges.", "hook");
          }
        }
      }

      if (im?.dualPolarity) s.polarityIndex = 1 - s.polarityIndex;
      return true;
    }

    baseDamage(ability, school) {
      const s = this.state;
      const isMagic = ["school_fire", "school_lightning", "school_poison"].includes(school?.id || ability.school);
      const scalingStat = isMagic ? this.playerStats.spellPower : this.playerStats.attackDamage;

      if (ability.customBaseDamage != null) {
        const ratio = Number(ability.power ?? 0);
        return Math.max(1, Number(ability.customBaseDamage) + scalingStat * ratio);
      }

      const map = {
        generator: 0.55, strike: 0.72, dot: 0.42, cleave: 0.5, finisher: 1.5, utility: 0.2,
      };
      let mult = map[ability.role] || 0.5;
      if (ability.power) mult = ability.power;
      let dmg = scalingStat * mult;
      if (ability.name === "Exorcism") dmg = scalingStat * (1.5 + 0.4 * Math.min(this.state.resource, this.state.resourceMax));
      if (ability.name === "Judgment" && this.hasHook("hourglass") && s.resource > 0) {
        const dump = Math.min(s.resource, 2);
        s.resource -= dump;
        dmg *= 1 + 0.35 * dump;
      }
      return dmg;
    }

    kitFx(ability, school) {
      const id = school.id.replace("school_", "").slice(0, 3).toUpperCase();
      return `GS-FX-${id}-${ability.fx || "IMP"}`;
    }

    consumeBleeds(en) {
      if (!this.hasHook("bleedingLight")) return 0;
      const ail = en.ailments.school_bleed;
      if (!ail) return 0;
      delete en.ailments.school_bleed;
      return ail.dps * (ail.remaining / 10) * 2.5;
    }

    gainHolyPower(n, source) {
      const s = this.state;
      if (!n) return 0;
      let gain = n;
      if (source?.name === "Holy Strike" && this.hasHook("greathammer")) gain = 2;
      if (source?.name === "Holy Strike" && this.hasHook("scepter") && this.rnd() < 0.6) gain = 2;
      else if (source?.name === "Holy Strike" && this.rnd() < 0.35) gain = 2;
      if (s.highJudgeReady && source?.name === "Holy Strike") { gain = 2; s.highJudgeReady = false; }
      const before = s.resource;
      s.resource = Math.min(s.resourceMax + (this.cls?.resource?.type === "holy_power" ? 2 : 0), s.resource + gain);
      if (s.resource > before && this.hasHook("staticFaith")) {
        const alive = s.enemies.filter(e => !e.dead);
        if (alive.length) {
          const t = alive[Math.floor(this.rnd() * alive.length)];
          const school = this.data.schools.find(x => x.id === "school_lightning");
          this.damageEnemy(t, this.playerStats.spellPower * 0.25, school, {
            isProc: true, fx: "GS-FX-LIG-CHN", abilityId: "hook:staticFaith", abilityName: "Static Faith",
          });
          this.events.feed("Coil of Static Faith discharges!", "hook");
        }
      }
      return s.resource - before;
    }
  }

  function seededRng(seed) {
    let a = (Number(seed) || 20261122) >>> 0;
    return () => {
      a |= 0;
      a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function percentile(sortedAsc, p) {
    if (!sortedAsc.length) return 0;
    const idx = Math.min(sortedAsc.length - 1, Math.max(0, Math.floor((sortedAsc.length - 1) * p)));
    return sortedAsc[idx];
  }

  function runMonteCarlo(data, profileOrFactory, runs = 50, baseSeed = null) {
    const count = Math.max(1, Math.min(250, Math.round(Number(runs) || 50)));
    const isFactory = typeof profileOrFactory === "function";
    const seedStart = baseSeed != null ? Number(baseSeed) : ((!isFactory && profileOrFactory?.seed) ?? 20261122);
    const noop = { fct() {}, feed() {}, fx() {}, projectile() {}, enemySwing() {}, pulse() {}, death() {}, waveEnd() {}, playerDown() {} };

    const dpsList = [];
    const ttkList = [];
    let wins = 0;
    let defeats = 0;
    let timeouts = 0;
    let enragedRuns = 0;
    let winHpPctSum = 0;
    let totalDamage = 0;
    let totalDirect = 0;
    let totalDot = 0;
    let totalProc = 0;
    let totalCasts = 0;
    let totalCrits = 0;
    let totalCombos = 0;
    let totalTaken = 0;

    for (let i = 0; i < count; i++) {
      const runSeed = (seedStart + i * 7919) >>> 0;
      const simRnd = seededRng(runSeed);
      const rawProfile = isFactory ? profileOrFactory(i, simRnd) : profileOrFactory;
      const simProfile = { ...rawProfile, seed: runSeed };
      const c = new Combat(data, simProfile, noop, { silent: true });
      for (let t = 0; t < 6000 && !c.state.result; t++) c.tick();
      if (!c.state.result) {
        c.state.result = "timeout";
        c.state.ttkMs = c.state.elapsedMs;
        timeouts++;
      } else if (c.state.result === "victory") {
        wins++;
        winHpPctSum += Math.max(0, Math.min(100, (c.state.playerHp / Math.max(1, c.playerStats.maxHp)) * 100));
      } else {
        defeats++;
      }

      const st = c.state;
      const roster = st.initialEnemies || st.enemies || [];
      if (roster.some(e => e.enraged)) enragedRuns++;

      const elapsedSec = Math.max(0.1, (st.ttkMs ?? st.elapsedMs) / 1000);
      const runDps = Math.round(st.stats.damage / elapsedSec);
      dpsList.push(runDps);
      ttkList.push(Number(elapsedSec.toFixed(2)));
      totalDamage += st.stats.damage;
      totalDirect += st.stats.bySourceType.direct || 0;
      totalDot += st.stats.bySourceType.dot || 0;
      totalProc += st.stats.bySourceType.proc || 0;
      totalCasts += st.stats.casts;
      totalCrits += st.stats.crits;
      totalCombos += st.stats.comboCount || 0;
      totalTaken += st.stats.damageTaken || 0;
    }

    const sortedDps = [...dpsList].sort((a, b) => a - b);
    const sortedTtk = [...ttkList].sort((a, b) => a - b);

    const minDps = sortedDps[0] ?? 0;
    const maxDps = sortedDps[sortedDps.length - 1] ?? 0;
    const avgDps = Math.round(dpsList.reduce((a, b) => a + b, 0) / count);
    const p10Dps = Math.round(percentile(sortedDps, 0.10));
    const p50Dps = Math.round(percentile(sortedDps, 0.50));
    const p90Dps = Math.round(percentile(sortedDps, 0.90));

    const minTtkSec = Number((sortedTtk[0] ?? 0).toFixed(2));
    const maxTtkSec = Number((sortedTtk[sortedTtk.length - 1] ?? 0).toFixed(2));
    const avgTtkSec = Number((ttkList.reduce((a, b) => a + b, 0) / count).toFixed(2));
    const p50TtkSec = Number(percentile(sortedTtk, 0.50).toFixed(2));
    const p90TtkSec = Number(percentile(sortedTtk, 0.90).toFixed(2));

    const winRatePct = Math.round((wins / count) * 1000) / 10;
    const enrageRatePct = Math.round((enragedRuns / count) * 1000) / 10;
    const avgHpRemainingPct = wins > 0 ? Math.round((winHpPctSum / wins) * 10) / 10 : 0;
    const avgCritPct = totalCasts > 0 ? Math.round((totalCrits / totalCasts) * 1000) / 10 : 0;
    const dmgSum = Math.max(1, totalDamage);

    return {
      runs: count,
      wins,
      defeats,
      timeouts,
      winRatePct,
      enrageRatePct,
      avgHpRemainingPct,
      minDps,
      p10Dps,
      p50Dps,
      avgDps,
      p90Dps,
      maxDps,
      minTtkSec,
      p50TtkSec,
      avgTtkSec,
      p90TtkSec,
      maxTtkSec,
      avgCritPct,
      avgCombos: Number((totalCombos / count).toFixed(1)),
      avgDamageTaken: Math.round(totalTaken / count),
      sourceMix: {
        directPct: Math.round((totalDirect / dmgSum) * 1000) / 10,
        dotPct: Math.round((totalDot / dmgSum) * 1000) / 10,
        procPct: Math.round((totalProc / dmgSum) * 1000) / 10,
      },
      dpsList,
    };
  }

  function fmt(n) {
    if (n >= 1e9) return (n / 1e9).toFixed(1) + "B";
    if (n >= 1e6) return (n / 1e6).toFixed(1) + "M";
    if (n >= 1e3) return (n / 1e3).toFixed(1) + "K";
    return `${Math.round(n)}`;
  }

  window.Tickforge = Object.assign(window.Tickforge || {}, {
    Combat,
    fmt,
    RANK_MODS,
    computeEncounterEnemy,
    parseItemModifiers,
    runMonteCarlo,
  });
})();
