// Headless combat smoke test: 60 simulated seconds, then assert outcomes.
// Covers all five classes (Templar/Warrior/Elementalist/Nightblade/Monk) plus
// the Templar gear-hook path (Censer of Zeal raises the Holy Power cap to 10).
global.window = {};
require("../js/data-bundle.js");
require("../js/engine.js");
require("../js/combat.js");
const D = global.window.TFDATA;
const { Combat } = global.window.Tickforge;

const events = { fct(){}, feed(){}, fx(){}, pulse(){}, death(){}, waveEnd(){}, playerDown(){} };
let defeat = null;
events.playerDown = () => { defeat = true; };
let wins = 0;
events.waveEnd = () => wins++;

// Every class must clear its opening wave within 90 simulated seconds.
for (const cls of D.classes) {
  const profile = { level: 8, xp: 0, gold: 0, shards: 0, classId: cls.id,
    loadout: cls.loadout, equipped: {}, zoneIndex: 0, stage: 3, seed: 42 };
  const c = new Combat(D, profile, events);
  for (let i = 0; i < 900 && !c.state.result; i++) c.tick();
  console.log(cls.id, "→", c.state.result, "| casts:", c.state.stats.casts,
    "| damage:", c.state.stats.damage, "| resource:", c.state.resourceType,
    `${Math.round(c.state.resource)}/${c.state.resourceMax}`);
  if (c.state.result !== "victory" || c.state.stats.casts < 10) {
    console.error(`SMOKE TEST FAILED — ${cls.id} did not clear`);
    process.exit(1);
  }
}

// Templar hook smoke: greathammer + censer change numbers.
const profile = { level: 8, xp: 0, gold: 0, shards: 0, classId: "templar",
  loadout: ["GS-ABL-TEM-01", "GS-ABL-TEM-02", "GS-ABL-TEM-03", "GS-ABL-TEM-04"],
  equipped: { weapon: "GS-EQP-WEP-GHM", trinket: "GS-EQP-TRI-COZ" }, zoneIndex: 0, stage: 3, seed: 42 };
let c = new Combat(D, profile, events);
if (c.state.resourceMax !== 10) { console.error("Censer of Zeal did not raise cap"); process.exit(1); }
const hs = c.equippedAbilities.find(a => a.name === "Holy Strike");
c.gainHolyPower(1, hs);
c.cast(hs);
console.log("hooked kit OK — greathammer + censer of zeal active, holyPower:", Math.round(c.state.resource));
console.log("SMOKE TEST PASSED");
