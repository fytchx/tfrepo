# Tickforge Changelog

All phased sandbox updates, combat engine additions, UI enhancements, and verification checks are recorded here per phase so every change can be audited or isolated cleanly.

---

## Repo consolidation

Merged three upload zips into one repo. Base is the newest build (Tickforge-Official-main). Dropped the stale `dist/` zip and `bun.lock`, moved the AI Studio mockup to `docs/reference/`, archived the original spec, old plan and old UI kit under `docs/archive/`, fixed stale counts in `manifest.json`, and replaced the stub README with the real one. No game code changed.

---

## Phase 7 — Campaign Monte Carlo Predictor, What-If Gear Analyzer & Combat Juice

**Status:** Complete  
**Scope:** Upgraded the Monte Carlo simulation engine for both Sandbox and Idle Campaign Mode, added a dedicated **Monte Carlo** Campaign tab with Boss Readiness prediction & paired bag-item comparison, and added tactile synergy feedback & hotbar priority controls.

### 1. Upgraded Monte Carlo Simulation Engine (`js/combat.js`)
- **`runMonteCarlo(data, profileOrFactory, runs, baseSeed)`**:
  - Now accepts either a static Sandbox profile or a per-run factory function `(runIdx, rnd) => simProfile` so randomized waves and Boss states initialize freshly without shared mutation across runs.
  - Passes `{ silent: true }` to `Combat` for fast headless multi-run throughput.
  - Inspects `initialEnemies` / remaining HP at fight end to report **`enrageRatePct`**, **`avgHpRemainingPct`**, and percentile distributions (**`p10Dps`**, **`p50Dps`**, **`p90Dps`**, **`p50TtkSec`**, **`p90TtkSec`**) while preserving all existing return fields.

### 2. Campaign Boss Readiness & Paired What-If Gear Predictor (`js/campaign.js`)
- **`runCampaignMonteCarlo(data, campaign, { target, runs, baseSeed, overrideItem })`**:
  - Simulates `wave` (Current Wave), `boss` (Zone Boss), or `next_zone` (Next Zone Wave 1).
  - Computes win %, enrage %, survival %, DPS percentiles, projected **XP/hr & Gold/hr** (factoring the `2.0s` campfire penalty on defeats), and an actionable **Readiness Verdict** (`SAFE CLEAR`, `CONTESTED`, `HIGH RISK`, `STAT WALL`) with tactical advice.
- **`compareCampaignCandidate(data, campaign, candidateItem, opts)`**:
  - Runs paired deterministic RNG seeds comparing **Equipped Build (A)** vs. **Bag Candidate Item (B)** without mutating live progression.

### 3. Campaign UI, HUD Quick-Check & Combat Synergy Juice (`index.html`, `css/layout.css`, `js/ui.js`, `js/combat.js`)
- Added **Monte Carlo** tab (`campaign_mc`) and **`Sim Boss`** quick-check button beside **`Challenge Zone Boss`** in `#campaignHudCard`.
- Added **1-click Hotbar Priority Shift (`◄ Shift Left` / `Shift Right ►`)** buttons in both Campaign and Sandbox hotbars, and upgraded Sandbox **Theorycraft** KPIs to show `p50` median DPS & `p10–p90` spread.
- Added **`ECHO!`** (`Chrono Reverberation`) lightning projectile + floating combat text + feed entry on every 4th cast and tactile screen-shake on Boss Posture breaks.

---

## Phase 6 — Live Idle Campaign Mode (5 Connected Progression Systems)

**Status:** Complete  
**Scope:** Added full **Idle Campaign Mode** toggle alongside Sandbox Mode while keeping every Sandbox/Sim tool and `tools/smoke-test.cjs` baseline intact.

### 1. Instant Start & Endless Wave Loop (`js/campaign.js`, `js/combat.js`, `js/ui.js`)
- Added **Mode Switcher Bar** (`Sandbox Mode` ↔ `Idle Campaign Mode`) cleanly isolating Campaign progression (`profile.campaign`) from Sandbox `statOverrides`, `sandboxEncounter`, and `loadout`.
- **Character Onboarding**: Select any of the 5 Classes (`Templar`, `Warrior`, `Elementalist`, `Nightblade`, `Monk`) + 7 Starter Weapon Archetypes (`Greathammer`, `Scepter`, `Flail`, `Longsword`, `Dagger`, `Cleaver`, `Mace`) to immediately start auto-combat in **Zone 1: Gallowsfen — Wave 1** on Tick 1 with weapon auto-attacks (`tickWeaponAuto`) and unlocked skills.
- **Randomized 1–5 Enemy Waves**: Spawns `Normal`, `Armored Vanguard`, `Backline Hexer`, `Support Warder` (heals & wards allies), and occasional `Rare Champion` encounters with Auto-Advance vs Farm Current Wave toggle.
- **Non-Blocking Campfire Respawn**: Hitting `0` HP triggers a `2.0s` (`20-tick` / `2000ms`) *"Slain — Recovering at Campfire"* banner, steps back 1 wave (`max(1, wave - 1)`), preserves all XP/gold/loot, restores HP & Resource to `100%`, tracks `Total Deaths`, and resumes automatically.

### 2. Rested Experience & Offline Progress Simulator (`js/campaign.js`, `js/ui.js`)
- **Overlaid Rested XP Bar**: Caps at `150%` of `xpNext`; grants `2.0×` kill XP while draining the Rested pool. Every death drains `5%` of max Rested XP.
- **Offline Progress Simulator (`simulateOfflineHours`)**: `+1 Hr AFK`, `+4 Hrs AFK`, and `+8 Hrs AFK` fast-forward the real `Combat` engine (`{ silent: true }`) and render an **Offline Summary Card** reporting Time Elapsed, Waves Cleared, Total Deaths, Levels Gained, Rested XP Used, Items Kept, Items Auto-Salvaged, and Rare Catalysts Found.

### 3. Build-Revamping Drops & Two-Tier Crafting (`js/campaign.js`, `js/combat.js`, `js/ui.js`)
- Drops span `Common`, `Uncommon`, `Rare`, `Epic`, `Legendary`, and `Corrupted`, plus Rings, Runes, and Trinkets.
- `Rare+` drops roll **Build-Revamping Mutators (`ruleMutators`)**: `Sweeping Arc`, `Cinderbrand`, `Storm-Tempered`, `Sanguine Cadence`, `Chrono Reverberation`, `Arcing Precision`, `Crimson Leech`, `Executioner's Momentum`, `Blight Rupture`, and `Iron-Spiked Bastion`.
- **Two-Tier Forge Workbench**:
  - **Tier 1 Salvage Materials** (`Forged Scrap`, `Arcane Dust`, `Essence Shards`): upgrade ranks `+1..+10`, add Rune sockets (`0..3`), socket Runes, and reroll affixes.
  - **Tier 2 Ultra-Rare Drops**: `Tag Catalysts` (~2.5%, +20% matching tag stats), `Prism / Nullifying Catalysts` (~0.8%), and `Overclock Corruption Core` (~0.25% wave / ~14% boss, +30% cap + Corrupted implicit).

### 4. Smart Loot Filter & Auto-Salvage Engine (`js/campaign.js`, `js/ui.js`)
- Configurable Minimum Rarity (`Common+` through `Legendary+`), 10 Tag/Stat Whitelist checkboxes (`1` or `2` match rule), and 3 Always Keep Overrides (`Build-Revamping Mutators`, `2+ Rune Sockets`, `Runes / Trinkets`). Non-matching drops auto-salvage into materials on drop.

### 5. Manual Zone Boss Challenge & Next-Zone Stat Wall (`js/campaign.js`, `js/combat.js`, `js/ui.js`)
- Clearing waves charges **Zone Boss Readiness (`0% → 100%`)** to enable manual **"Challenge Zone Boss"**.
- Multi-slot Bosses (`Slots 1–3`) feature a **Posture Bar**, **Telegraphed Heavy Casts** (interruptible via `Rebuke`, `Tempest Kick`, `Shadow Veil`, or Posture break), **60s Enrage**, and contextual **Boss Death Diagnostic Tips**.
- Zone progression: `Zone 1: Gallowsfen` → `Zone 2: Blighted Fallfields` (`3.2× HP`, `2.1× DMG`, `15% DR/Res`) → `Zone 3: Emberscar Wastes` (`10.24× HP`, `4.41× DMG`, `28% DR`, `25% Res`) → `Zone 4+: Abyssal Spire (Endless Scaling Tiers)`.

---

## Phase 5 — 3-Second Moving Average DPS Filter & Chart Polish

**Status:** Complete & Verified  
**Roadmap Reference:** Extension Phase (`dps-chart-wrap` smoothing)

### Mechanics & Telemetry Added (`js/combat.js`)
- **3-Second Rolling Moving Average (`_maWindow`, `recordTimelineBucket`)**:
  - Tracks tick-stamped damage & taken events inside a 30-tick (`3.0s`) sliding window (`_maWindow`), pruning entries older than `currentTick - 30`.
  - Computes smoothed `direct`, `dot`, `proc`, `total`, and `taken` DPS rates over `Math.min(3.0, Math.max(0.1, currentTick / 10))` seconds while preserving `rawTotal` for raw 1-second reference.

### Visual & UI Changes (`index.html`, `js/ui.js`)
- **`.dps-chart-wrap` Clarity & Area Shading (`index.html`, `js/ui.js`)**:
  - Updated chart header label to `Live DPS (3s Avg)` and live SVG readout to show both trailing 3s rate and cumulative fight average (`3s X/s · Avg Y/s`).
  - Added subtle translucent gold area shading (`<polygon>`) beneath the smoothed `Total` polyline.

### Verification Run
- `npm run build` (`node tools/smoke-test.cjs`): Passed.
- `npm run lint` (`node --check` on `server.js` and all `js/*.js`): Passed.
- Phase 5 Moving Average Assertion: Verified `direct + dot + proc === total` across 10s of spiky 2.5s cooldown casts (`raw1s` `0..18` smoothed to `ma3` `3..9`).

---

## Phase 4 — Sandbox Polish, Verification & Final Documentation Pass

**Status:** Complete & Verified  
**Roadmap Reference:** Phase 4 of 4 (`implementation_plan.md`)

### Improvements & Hardening (`index.html`, `css/layout.css`, `js/ui.js`)
- **Keyboard Shortcuts (`bindKeyboardShortcuts`)**:
  - Added global sandbox shortcuts (ignored while typing inside inputs, selects, or textareas): `Space` (Start/Pause/Restart), `ArrowRight` (Step 1 Tick), `R` (Reset Fight), `1`–`5` (select Hotbar Slot), and `Escape` (close modal).
  - Added a subtle shortcut legend inside `.playback-bar`.
- **Responsive Viewport & Mobile Refinements (`css/layout.css`)**:
  - Updated `.GS-UI-NAV.sandbox-tabs` with horizontal scroll safety and `white-space: nowrap` for 5 tabs.
  - Added `@media (max-width: 600px)` rules collapsing `.summary-metrics` to a 2-column grid and compacting globes, portraits, and hotbar keycaps without overflow.
- **Cache Invalidation & Edge-Case Hardening**:
  - Invalidated `mcResult` on live stat edits and `Reset Stats` so Theorycraft comparisons always reflect current stats.
  - Verified 1-HP instant-burst fights, empty 5-slot hotbars, zero-damage overrides, and 5-Boss endurance encounters against `NaN` or infinite-loop regressions.

### Verification Run
- `npm run build` (`node tools/smoke-test.cjs`): Passed.
- `npm run lint` (`node --check` on `server.js` and all `js/*.js`): Passed.
- Edge-case verification suite (`1 HP`, empty hotbar, `0` AD/SP override, `5 Bosses x10`): Passed cleanly.
- Live Express HTTP `200` checks across all modified static assets and `/CHANGELOG.md`: Passed.

---

## Phase 3 — Theorycraft Telemetry, DPS Timeline & Monte Carlo Build Comparison

**Status:** Complete & Verified  
**Roadmap Reference:** Phase 3 of 4 (`implementation_plan.md`)

### Mechanics & Telemetry Added (`js/combat.js`, `js/save.js`)
- **Per-Second Combat Timeline Recorder (`recordTimelineBucket`, `state.timeline`)**:
  - Captures 1.0-second telemetry buckets (`sec`, `direct`, `dot`, `proc`, `total`, `taken`, `cumDps`) across both live playback and `Instant Sim`, including partial-second flushes on early victory/defeat and tick-0 bursts.
  - Added `stats.damageTaken` tracking across enemy swings and Monk Stagger pulses.
- **Deterministic Monte Carlo Analyzer (`runMonteCarlo`)**:
  - Runs `N` (`10`, `25`, `50`, `100`) headless simulations with deterministic stepped seeds (`seed + i * 7919`) and aggregates `winRatePct`, `min/avg/max DPS`, `min/avg/max TTK`, `avgCritPct`, `avgCombos`, `avgDamageTaken`, `sourceMix` (`Direct/DoT/Proc %`), and `dpsList`.
- **Build Snapshot Persistence (`js/save.js`)**:
  - Added `buildSnapshot` to `SaveRepository` defaults so pinned Snapshot A baselines persist across reloads.

### Visual & UI Changes (`index.html`, `css/layout.css`, `js/ui.js`)
- **Live DPS Timeline Inline SVG Chart (`#dpsTimelineSvg`, `renderDpsTimeline`)**:
  - Renders a zero-dependency multi-series SVG chart inside the Combat Summary box plotting `Total` (gold), `Direct` (silver), `DoT` (orange), and `Proc` (cyan) DPS over time with dashed guide gridlines and live Peak/Avg readouts.
- **Theorycraft Workbench Tab (`renderTheorycraftTab`)**:
  - Added **Monte Carlo Sim Analyzer** (`Run 10 / 50 / 100 Sims`) with KPI cards and an 8-bin SVG DPS distribution histogram (`buildHistogramSvg`).
  - Added **Build Snapshot Comparison (A vs. B)** allowing users to pin a baseline build and inspect exact numeric and percentage deltas (`Avg DPS`, `Avg TTK`, `Win Rate`, `Avg Combos`, `Max HP`, `Attack Damage`, `Spell Power`, `Crit %`, `Haste %`, `Armor`).

### Verification Run
- Headless Phase 3 assertions verified 20-second timeline bucket accuracy, `damageTaken` tracking, and exact determinism of `runMonteCarlo(D, profile, 15, 777)` across repeated runs.

---

## Phase 2 — Battlefield Visual Juice (Projectiles, Buff Bars, Enemy Swing Timers)

**Status:** Complete & Verified  
**Roadmap Reference:** Phase 2 of 4 (`implementation_plan.md`)

### Mechanics & Events Added (`js/combat.js`)
- **Spell Projectile Event Bus (`events.projectile`)**: Emits `{ ability, school, slotIndex, targetSlots, fxKey }` whenever an ability strikes single, cleave, snipe, or all-enemy targets, resolving effective converted school colors/sprites (e.g., Physical-to-Fire/Lightning gear conversions).
- **Enemy Swing & Target Tracking (`events.enemySwing`, `state.lastTargetSlot`)**: Emits `enemySwing` on completed enemy attack intervals and records `lastTargetSlot` on direct hits so the battlefield highlights the active primary target.

### Visual & UI Changes (`index.html`, `css/effects.css`, `css/layout.css`, `js/ui.js`)
- **Hotbar-to-Enemy SVG Projectiles (`spawnProjectile`)**: Launches school-matched FX SVG projectiles from the casting hotbar slot (`1–5`) toward each targeted enemy portrait slot (`0–4`) using compositor-only `transform` (`translate3d` + `rotate` + `scale`) and `opacity` Web Animations (`220ms`), plus enemy `hit-flash` and `swing-flash` portrait pulses.
- **Player Active Buffs & Wards Bar (`#playerBuffsBar`, `updateBuffsBar`)**: Added a compact status strip above the hotbar displaying live remaining seconds and shield/pool values for `Armor +25% DR`, `Shadow Veil Dodge`, `Haste +25%`, `Aegis Ward` absorb, Monk `Stagger`, `Rebuke Slow`, `Temporal Freeze`, `High Judge Surge`, `Bleed Rush`, and `Dual Polarity`.
- **Per-Enemy Swing Timer Bars & Ailment Durations (`.swing-bar`, `.dots`)**: Added compositor `scaleX` swing countdown bars beneath each enemy HP bar color-coded for normal (gold), slowed (blue), and frozen (ice cyan) states, along with live remaining-second badges (`FIR 3.2s`, `SHK 2.8s`, `SLW 1.0s`).
- **Reduced Motion Accessibility (`css/effects.css`)**: Added `@media (prefers-reduced-motion: reduce)` guards disabling projectile, shake, and portrait flash animations when reduced motion is enabled.

### Verification Run
- `npm run build` (`node tools/smoke-test.cjs`): Passed (all 5 classes + hooked kit).
- `npm run lint` (`node --check` on `server.js` and all `js/*.js`): Passed.
- Phase 2 Headless Event Assertions: Verified `projectile` emissions (`slotIndex`, `targetSlots`, `fxKey`), `enemySwing` cadence, `lastTargetSlot`, `Rebuke` (`500ms`), and `Iron Warcry` (`armorBuffRemaining`) buff tracking.

---

## Phase 1 — Combat Synergy Engine (Combos, Custom DoTs/Procs, Unique Item Hooks)

**Status:** Complete & Verified  
**Roadmap Reference:** Phase 1 of 4 (`implementation_plan.md`)

### Mechanics Added (`js/combat.js`)
- **School Combo Reaction Multipliers (`evaluateComboReaction`)**:
  - Direct non-DoT, non-proc hits now evaluate `comboReactionMultipliers` from `data/schools.json` against active opposing-school ailments (`Fire`, `Poison`, `Bleed`) and `Shock` (`vulnTicks > 0`) on the target.
  - Emits named reactions (`Combustion`, `Blightfire`, `Overload`, `Thermal Arc`, `Shattershock`, `Conductive Strike`, `Deep Wound`, `Hemorrhage`, `Septic Rupture`, `Venomous Tear`) with a 5-tick (`0.5s`) per-enemy reaction cooldown (`comboCdTicks`).
- **DoT / Shock / Bleed Duration Unit Alignment**:
  - Aligned `applies.dot.duration`, `applies.shock.duration`, and `spreadsBleed.duration` directly to the 100ms tick integer scale used in `data/abilities.json` (fixing premature <1 tick truncation so multi-tick DoTs, `Arcane Spark` Shock, `Tempest Kick` Shock, and `Whirlwind Cleave` bleeds persist for their full 3–8s durations).
- **Custom Spell DoT & Proc Trigger Engine (`resolveSpellProc`)**:
  - Added conditional proc execution supporting `onCast`, `onHit`, and `onCrit` triggers with configurable `chance`, `school`, and four effects: `bonus_hit` (`%` Power elemental strike), `apply_shock` (`+30%` vulnerability for 3.0s), `restore_res` (+Flat resource), and `heal_pct` (% Max HP).
- **Unique & Compendium Item Hook Registry (`parseItemModifiers`, `resolveHitItemHooks`)**:
  - Wired deterministic item modifier parsing and hit/crit dispatch covering Physical-to-Elemental conversions, school % increased & flat damage, Armor Penetration, Crit Multiplier, Execute (`<30% HP`), Burning/DoT speed bonuses, `Cathedral Bell-Hammer` delayed echoes (`pendingEchoes`), `Earthshatter` adjacent melee cleave, `Censer` fire splash, `Thunderclap` 4th-hit arc, `Blood-Drenched` crit bleeds, `Sunforged Sledge` crit ignite-all, `Dawnbreaker` radiant nova, `Seraphic Pillar` heal-on-spend, slow on hit, poison refresh, rage on hit, Dual Polarity toggling, and single-target Boss double-lightning.
- **Sandbox Pool Resource Initialization & Telemetry**:
  - Initialized pool-based sandbox classes (`Mana` for Elementalist, `Energy` for Nightblade) to `resourceMax` at encounter start (preserving legacy wave mode behavior for `tools/smoke-test.cjs`).
  - Added `stats.bySourceType` (`direct`, `dot`, `proc`) and `stats.comboCount` tracking.

### UI Changes (`index.html`, `css/layout.css`, `js/ui.js`)
- **Combat Summary Source Breakdown (`#sourceBreakdown`)**: Displays live `Direct · DoT · Proc · Combos` totals directly below the summary metrics row.
- **`+ New Spell` Creator Expansion (`buildNewSpellForm`)**: Added toggleable DoT fields (`DoT % per Tick`, `Duration (sec)`, `Tick Interval (sec)`) and Proc Trigger fields (`Trigger`, `Chance %`, `Effect`, `Effect Value`, `Proc School`), plus DoT/Proc badges in `renderSpellCatalog`.
- **Active Item Hooks Panel (`renderItemsTab`)**: Renders an `Active Item Hooks` summary card listing all parsed legendary/unique hook behaviors currently active on equipped gear.

### Verification Run
- `npm run build` (`node tools/smoke-test.cjs`): Passed (all 5 classes clear opening wave + Templar Greathammer/Censer of Zeal hook check).
- `npm run lint` (`node --check` on `server.js`, `js/engine.js`, `js/save.js`, `js/combat.js`, `js/ui.js`, `js/data-bundle.js`): Passed.
- Phase 1 Headless Combat Assertions:
  - Custom DoT + `onCast` Proc + `Combustion` combo reaction: verified `bySourceType.dot > 0`, `bySourceType.proc > 0`, `comboCount = 3`.
  - `Cathedral Bell-Hammer` + `Signet of the High Judge`: verified 2 active hook descriptions and delayed echo proc damage.
  - `Sunforged Sledge` with forced crits: verified crit ignite propagation across all enemy slots.
  - Elementalist `Pyroblast` + `Arcane Spark`: verified `Overload` (`1.20x`) and `Thermal Arc` (`1.15x`) alternating combo reactions (`comboCount = 5`).

---

## Baseline — Initial Sandbox Slice & AI Studio Migration

- Migrated `fytchx/tickfiend1` to Express on port `3000` (`server.js`, `package.json`, `metadata.json`).
- Built initial 4-feature Combat & Build Sandbox Slice:
  1. 1–5 Enemy Encounter Sandbox (Slots `0–4`, `1/5/25/100/1,000 HP` presets, `x1/x2/x5/x10` multipliers, `Normal`/`Elite`/`Boss` rank formulas).
  2. Character & Loadout Panel (`+ New Spell`, `+ New Item`, 5-slot left-to-right Hotbar, premade libraries).
  3. Live Stat Editor with `Reset Stats` override clearing.
  4. Playback controls (`Start/Pause`, `Step 1 Tick`, `1x/2x/5x`, `Instant Sim`), Bot Modes (`Optimal`, `Casual`, `Sloppy / Random`), Combat Summary + Log, and Export/Import Build JSON.
