# AI Brief: Tickforge

Paste this at the start of any AI chat about this repo, then attach or point to the files.

## What this is
Tickforge: a mobile-first portrait idle auto-combat ARPG. 5 classes, 5-slot hotbar, 10 Hz tick engine, endless waves, loot and crafting, zone boss walls, offline progress. Plain HTML/CSS/JS, no build step.

## Hard rules
1. Vanilla only. No React, TypeScript, Vite, Webpack or Tailwind.
2. Combat runs on 100 ms ticks. Never tie combat math to requestAnimationFrame.
3. Campaign mode and Sandbox mode must both keep working on the same engine.
4. Content lives in `data/*.json`. After editing, run `node tools/generate-data.mjs` to rebuild `js/data-bundle.js`.
5. Do not build from `docs/archive/`. It describes an older design (7 schools, 4 slots, 20 ticks) that is no longer the game.

## Before editing
Read `README.md`, `CHANGELOG.md`, then the relevant file in `js/`. Extend existing functions and state, do not duplicate them.

## Definition of done
`npm run lint` and `npm test` pass, and the change was exercised in a browser at 390 px wide with no console errors.

## Current task
Milestone 1 in README section 5: audit and bugfix. Click every tab and button, fix dead clicks and console errors, confirm save/load and the death and respawn cycle, confirm the loot filter. Do not add new systems until this is done.

## How to reply
Give working code changes, not design essays. List the files you changed.
