// Tickforge Idle Campaign Mode systems:
// Zones & Stat Walls, 7 Starter Weapons, Randomized Wave Archetypes & Multi-Slot Bosses,
// Build-Revamping Mutators, Two-Tier Crafting Materials, Smart Loot Filter & Auto-Salvage,
// Rested XP, and Deterministic Offline Progress Simulator.
(() => {
  const RANK_FRAMES = {
    Normal: "assets/enemies/frames/GS-UI-FRM-Oval-1.svg",
    Elite: "assets/enemies/frames/GS-UI-FRM-Oval-4.svg",
    Boss: "assets/enemies/frames/GS-UI-FRM-Oval-12.svg",
  };

  const RARITIES = ["Common", "Uncommon", "Rare", "Epic", "Legendary", "Corrupted"];
  const RARITY_RANK = { Common: 0, Uncommon: 1, Rare: 2, Epic: 3, Legendary: 4, Corrupted: 5 };
  const RARITY_TIER = { Common: 1, Uncommon: 2, Rare: 3, Epic: 4, Legendary: 5, Corrupted: 5 };
  const RARITY_COLOR = {
    Common: "#9a9a9a",
    Uncommon: "#4fc14f",
    Rare: "#3f8fe8",
    Epic: "#b366ff",
    Legendary: "#f0932a",
    Corrupted: "#ff5a7a",
  };

  const FILTER_TAGS = [
    "STR",
    "AGI",
    "INT",
    "Fire/Burn",
    "Bleed",
    "Poison",
    "Lightning",
    "Physical",
    "Haste/Crit",
    "Resist/Block",
  ];

  const STARTER_WEAPONS = [
    {
      id: "greathammer",
      name: "Vigilant Greathammer",
      archetype: "Greathammer",
      swingTicks: 20,
      tags: ["STR", "Physical"],
      stats: { attackPower: 14, maxHp: 35, critChance: 0.03 },
      description: "Heavy 2H hammer (2.0s swing) scaling STR & Physical strikes.",
    },
    {
      id: "scepter",
      name: "Arcane Scepter",
      archetype: "Scepter",
      swingTicks: 17,
      tags: ["INT", "Lightning", "Haste/Crit"],
      stats: { spellPower: 15, haste: 0.05, int: 4 },
      description: "Swift caster scepter (1.7s swing) boosting Spell Power & Haste.",
    },
    {
      id: "flail",
      name: "Stormbound Flail",
      archetype: "Flail",
      swingTicks: 18,
      tags: ["Lightning", "Physical"],
      stats: { attackPower: 10, spellPower: 8, critChance: 0.03 },
      mutatorIds: ["phys_to_lightning"],
      description: "Spark-forged flail (1.8s swing) converting 25% Phys → Lightning + Shock.",
    },
    {
      id: "sword",
      name: "Serrated Longsword",
      archetype: "Longsword",
      swingTicks: 16,
      tags: ["AGI", "Physical", "Haste/Crit"],
      stats: { attackPower: 12, critChance: 0.05, haste: 0.03 },
      description: "Crisp blade (1.6s swing) built for Crit & Haste tempo.",
    },
    {
      id: "dagger",
      name: "Venomfang Dirk",
      archetype: "Dagger",
      swingTicks: 13,
      tags: ["AGI", "Poison"],
      stats: { attackPower: 9, spellPower: 5, haste: 0.06, critChance: 0.03 },
      description: "Rapid dirk (1.3s swing) favoring Poison & frequent on-hit procs.",
    },
    {
      id: "axe",
      name: "Warforged Cleaver",
      archetype: "Cleaver",
      swingTicks: 18,
      tags: ["STR", "Bleed"],
      stats: { attackPower: 13, critMulti: 0.15, str: 4 },
      description: "Brutal cleaver (1.8s swing) tuned for Bleed & Crit damage.",
    },
    {
      id: "mace",
      name: "Sunforged Mace",
      archetype: "Mace",
      swingTicks: 17,
      tags: ["Fire/Burn", "STR"],
      stats: { attackPower: 11, spellPower: 7, fireRes: 0.08 },
      mutatorIds: ["phys_to_fire"],
      description: "Ember-crowned mace (1.7s swing) converting 25% Phys → Fire + Burn.",
    },
  ];

  const CAMPAIGN_MUTATORS = [
    {
      id: "cleave_adjacent",
      name: "Sweeping Arc",
      tag: "Physical",
      description: "Single-target attacks cleave 2 adjacent enemies for 65% damage.",
    },
    {
      id: "phys_to_fire",
      name: "Cinderbrand",
      tag: "Fire/Burn",
      description: "25% of Physical damage converted to Fire + hits inflict Burn (3s).",
    },
    {
      id: "phys_to_lightning",
      name: "Storm-Tempered",
      tag: "Lightning",
      description: "25% of Physical damage converted to Lightning + 30% chance to Shock.",
    },
    {
      id: "bleed_refund",
      name: "Sanguine Cadence",
      tag: "Bleed",
      description: "Bleed ticks 30% faster and each pulse restores +2 Resource.",
    },
    {
      id: "spell_echo_4th",
      name: "Chrono Reverberation",
      tag: "Haste/Crit",
      description: "Every 4th cast triggers a free spell echo at 75% power.",
    },
    {
      id: "crit_lightning_arc",
      name: "Arcing Precision",
      tag: "Lightning",
      description: "Critical strikes discharge a Lightning arc to 2 enemies for 45% Spell Power.",
    },
    {
      id: "vampiric_leech",
      name: "Crimson Leech",
      tag: "Bleed",
      description: "Weapon & spell hits leech 4% of damage dealt as HP.",
    },
    {
      id: "kill_haste_cdr",
      name: "Executioner's Momentum",
      tag: "Haste/Crit",
      description: "Kills reduce all active ability cooldowns by 0.6s.",
    },
    {
      id: "plague_eruption",
      name: "Blight Rupture",
      tag: "Poison",
      description: "Poisoned enemies erupt on death for 120% Spell Power Poison AoE.",
    },
    {
      id: "bastion_thorns",
      name: "Iron-Spiked Bastion",
      tag: "Resist/Block",
      description: "Blocking or taking a hit retaliates for 50% Armor + 35% ATK Physical dmg.",
    },
  ];

  const MATERIALS_META = {
    // Tier 1: Common Salvage Materials
    forged_scrap: { id: "forged_scrap", name: "Forged Scrap", tier: 1, tag: null, desc: "Used to upgrade item ranks (+1..+10) and add Rune sockets." },
    arcane_dust: { id: "arcane_dust", name: "Arcane Dust", tier: 1, tag: null, desc: "Used to upgrade items and reroll affixes." },
    essence_shards: { id: "essence_shards", name: "Essence Shards", tier: 1, tag: null, desc: "Rare salvage residue for sockets and high-tier affix rerolls." },
    // Tier 2: Ultra-Rare Catalysts
    cat_pyric: { id: "cat_pyric", name: "Pyric Catalyst", tier: 2, kind: "tag", tag: "Fire/Burn", dropPct: 2.5, desc: "Boosts Fire/Burn stats & affixes on an item by +20% (+30% Corrupted)." },
    cat_sanguine: { id: "cat_sanguine", name: "Sanguine Catalyst", tier: 2, kind: "tag", tag: "Bleed", dropPct: 2.5, desc: "Boosts Bleed stats & affixes on an item by +20% (+30% Corrupted)." },
    cat_voltaic: { id: "cat_voltaic", name: "Voltaic Catalyst", tier: 2, kind: "tag", tag: "Lightning", dropPct: 2.5, desc: "Boosts Lightning stats & affixes on an item by +20% (+30% Corrupted)." },
    cat_noxious: { id: "cat_noxious", name: "Noxious Catalyst", tier: 2, kind: "tag", tag: "Poison", dropPct: 2.5, desc: "Boosts Poison stats & affixes on an item by +20% (+30% Corrupted)." },
    cat_chrono: { id: "cat_chrono", name: "Chrono Catalyst", tier: 2, kind: "tag", tag: "Haste/Crit", dropPct: 2.5, desc: "Boosts Haste & Crit affixes on an item by +20% (+30% Corrupted)." },
    cat_aegis: { id: "cat_aegis", name: "Aegis Catalyst", tier: 2, kind: "tag", tag: "Resist/Block", dropPct: 2.5, desc: "Boosts Armor, Resist & Block affixes on an item by +20% (+30% Corrupted)." },
    cat_arcane: { id: "cat_arcane", name: "Arcane Catalyst", tier: 2, kind: "tag", tag: "INT", dropPct: 2.5, desc: "Boosts INT & Spell Power affixes on an item by +20% (+30% Corrupted)." },
    cat_tempering: { id: "cat_tempering", name: "Tempering Catalyst", tier: 2, kind: "tag", tag: "Physical", dropPct: 2.5, desc: "Boosts STR & Physical affixes on an item by +20% (+30% Corrupted)." },
    cat_prism: { id: "cat_prism", name: "Prism Catalyst", tier: 2, kind: "prism", tag: null, dropPct: 0.8, desc: "Upgrades an item's rarity tier (up to Epic) and adds a new affix." },
    cat_nullifying: { id: "cat_nullifying", name: "Nullifying Catalyst", tier: 2, kind: "nullify", tag: null, dropPct: 0.8, desc: "Strips the weakest affix and reforges a high-tier affix." },
    cat_overclock: { id: "cat_overclock", name: "Overclock Corruption Core", tier: 2, kind: "corrupt", tag: null, dropPct: 0.25, desc: "Corrupts an item, raising catalyst caps to +30% and adding a Corrupted implicit." },
  };

  const BASE_ZONES = [
    {
      index: 0,
      id: "GS-ZON-GAL",
      name: "Zone 1: Gallowsfen",
      shortName: "Gallowsfen",
      bg: "#141f2a",
      bgGlow: "#27404d",
      hpMult: 1.0,
      dmgMult: 1.0,
      armorDr: 0.0,
      resPct: 0.0,
      ilvlBase: 1,
      xpBase: 26,
      goldBase: 18,
      enemyPool: ["GS-ENM-PHY-1", "GS-ENM-PHY-2", "GS-ENM-BLE-1", "GS-ENM-LIG-1"],
      bossId: "GS-ENM-BLE-1",
      bossName: "Goremaw, Fen Reaver",
      bossTitle: "Zone 1 Warden",
      bossCastName: "Rending Howl",
      bossSchool: "school_bleed",
    },
    {
      index: 1,
      id: "GS-ZON-BFF",
      name: "Zone 2: Blighted Fallfields",
      shortName: "Blighted Fallfields",
      bg: "#18251b",
      bgGlow: "#2f4a2a",
      hpMult: 3.2,
      dmgMult: 2.1,
      armorDr: 0.15,
      resPct: 0.15,
      ilvlBase: 12,
      xpBase: 68,
      goldBase: 48,
      enemyPool: ["GS-ENM-POI-1", "GS-ENM-POI-2", "GS-ENM-PHY-2", "GS-ENM-LIG-2"],
      bossId: "GS-ENM-BSS-1",
      bossName: "Blightwood Colossus",
      bossTitle: "Zone 2 Warden",
      bossCastName: "Spore Cataclysm",
      bossSchool: "school_poison",
    },
    {
      index: 2,
      id: "GS-ZON-EMB",
      name: "Zone 3: Emberscar Wastes",
      shortName: "Emberscar Wastes",
      bg: "#291712",
      bgGlow: "#55291a",
      hpMult: 10.24,
      dmgMult: 4.41,
      armorDr: 0.28,
      resPct: 0.25,
      ilvlBase: 26,
      xpBase: 175,
      goldBase: 125,
      enemyPool: ["GS-ENM-FIR-1", "GS-ENM-FIR-2", "GS-ENM-LIG-2", "GS-ENM-BLE-2"],
      bossId: "GS-ENM-FIR-1",
      bossName: "Ignis-Vael, Cinder Tyrant",
      bossTitle: "Zone 3 Warden",
      bossCastName: "Solar Annihilation",
      bossSchool: "school_fire",
    },
  ];

  function getCampaignZone(zoneIndex) {
    const zi = Math.max(0, Math.floor(Number(zoneIndex) || 0));
    if (zi < BASE_ZONES.length) return BASE_ZONES[zi];
    const endlessTier = zi - BASE_ZONES.length + 1;
    const bossCycle = [
      { id: "GS-ENM-LIG-2", name: `Tempest Archon T${endlessTier}`, cast: "Volt Annihilation", school: "school_lightning" },
      { id: "GS-ENM-FIR-1", name: `Ember Sovereign T${endlessTier}`, cast: "Infernal Nova", school: "school_fire" },
      { id: "GS-ENM-BSS-1", name: `Abyssal Blightlord T${endlessTier}`, cast: "Plague Surge", school: "school_poison" },
    ][(endlessTier - 1) % 3];
    return {
      index: zi,
      id: `GS-ZON-END-${endlessTier}`,
      name: `Zone ${zi + 1}: Abyssal Spire (Endless Tier ${endlessTier})`,
      shortName: `Endless Tier ${endlessTier}`,
      bg: "#1c1324",
      bgGlow: "#3d2252",
      hpMult: Number((Math.pow(3.2, zi)).toFixed(2)),
      dmgMult: Number((Math.pow(2.1, zi)).toFixed(2)),
      armorDr: Math.min(0.55, 0.28 + endlessTier * 0.05),
      resPct: Math.min(0.50, 0.25 + endlessTier * 0.05),
      ilvlBase: 26 + endlessTier * 14,
      xpBase: Math.round(175 * Math.pow(1.9, endlessTier)),
      goldBase: Math.round(125 * Math.pow(1.85, endlessTier)),
      enemyPool: ["GS-ENM-FIR-1", "GS-ENM-FIR-2", "GS-ENM-LIG-2", "GS-ENM-POI-2", "GS-ENM-BLE-2"],
      bossId: bossCycle.id,
      bossName: bossCycle.name,
      bossTitle: `Endless Tier ${endlessTier} Boss`,
      bossCastName: bossCycle.cast,
      bossSchool: bossCycle.school,
    };
  }

  function mulberry32(seed) {
    let a = seed >>> 0;
    return () => {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  const GEAR_ICONS = {
    weapon: "assets/icons/GS-ICO-GEAR-WEA.svg",
    armor: "assets/icons/GS-ICO-GEAR-SHI.svg",
    shield: "assets/icons/GS-ICO-GEAR-SHI.svg",
    tome: "assets/icons/GS-ICO-GEAR-TOM.svg",
    ring: "assets/icons/GS-ICO-GEAR-RIN.svg",
    rune: "assets/icons/GS-ICO-GEAR-RUN.svg",
    trinket: "assets/icons/GS-ICO-GEAR-TRI.svg",
  };

  const AFFIX_POOL = [
    { name: "Brutal", stat: "attackPower", base: 4, perIlvl: 1.4, tag: "STR" },
    { name: "Swift", stat: "haste", base: 0.015, perIlvl: 0.0022, tag: "Haste/Crit", pct: true },
    { name: "Cruel", stat: "critChance", base: 0.015, perIlvl: 0.002, tag: "Haste/Crit", pct: true },
    { name: "Vital", stat: "maxHp", base: 22, perIlvl: 9.5, tag: "STR" },
    { name: "Arcanist's", stat: "spellPower", base: 4, perIlvl: 1.4, tag: "INT" },
    { name: "Ironclad", stat: "armor", base: 6, perIlvl: 2.2, tag: "Resist/Block" },
    { name: "Pyric", stat: "fireDmgPct", base: 0.06, perIlvl: 0.012, tag: "Fire/Burn", pct: true },
    { name: "Voltaic", stat: "lightningDmgPct", base: 0.06, perIlvl: 0.012, tag: "Lightning", pct: true },
    { name: "Noxious", stat: "poisonDmgPct", base: 0.06, perIlvl: 0.012, tag: "Poison", pct: true },
    { name: "Sanguine", stat: "bleedDmgPct", base: 0.06, perIlvl: 0.012, tag: "Bleed", pct: true },
    { name: "Shattering", stat: "physDmgPct", base: 0.06, perIlvl: 0.012, tag: "Physical", pct: true },
    { name: "Phoenix-Warded", stat: "fireRes", base: 0.05, perIlvl: 0.006, tag: "Resist/Block", pct: true },
    { name: "Storm-Warded", stat: "lightningRes", base: 0.05, perIlvl: 0.006, tag: "Resist/Block", pct: true },
    { name: "Antidote-Laced", stat: "poisonRes", base: 0.05, perIlvl: 0.006, tag: "Resist/Block", pct: true },
    { name: "Bulwark", stat: "block", base: 0.03, perIlvl: 0.003, tag: "Resist/Block", pct: true },
    { name: "Nimble", stat: "agi", base: 3, perIlvl: 1.1, tag: "AGI" },
    { name: "Scholar's", stat: "int", base: 3, perIlvl: 1.1, tag: "INT" },
    { name: "Titan's", stat: "str", base: 3, perIlvl: 1.1, tag: "STR" },
  ];

  const SLOT_BASE_NAMES = {
    weapon: ["Warblade", "Greathammer", "Flail", "Scepter", "Longsword", "Cleaver", "Dirk"],
    armor: ["Hauberk", "Plate Cuirass", "Brigandine", "Vestments", "Mantle"],
    shield: ["Bulwark", "Kite Shield", "Tower Aegis", "Buckler"],
    tome: ["Codex", "Grimoire", "Lexicon", "Psalter"],
    ring: ["Signet", "Band", "Loop", "Seal"],
    rune: ["Sigil", "Glyph", "Etching", "Rune-Stone"],
    trinket: ["Charm", "Censer", "Relic", "Idol"],
  };

  function makeStarterWeaponItem(archetypeId) {
    const arch = STARTER_WEAPONS.find(w => w.id === archetypeId) || STARTER_WEAPONS[0];
    const mutators = (arch.mutatorIds || [])
      .map(id => CAMPAIGN_MUTATORS.find(m => m.id === id))
      .filter(Boolean);
    return {
      id: `CMP-START-${arch.id}`,
      name: arch.name,
      slot: "weapon",
      archetype: arch.archetype,
      swingTicks: arch.swingTicks || 18,
      rarity: mutators.length ? "Uncommon" : "Common",
      tier: mutators.length ? 2 : 1,
      ilvl: 1,
      upgradeLevel: 0,
      icon: GEAR_ICONS.weapon,
      tags: [...arch.tags],
      stats: { ...arch.stats },
      affixes: [],
      sockets: 1,
      socketedRunes: [],
      ruleMutators: mutators.map(m => ({ ...m })),
      hooks: mutators.map(m => ({ kind: `mut:${m.id}`, description: m.description })),
      catalystBoosts: {},
      corrupted: false,
      isStarter: true,
    };
  }

  function computeItemPowerScore(item) {
    if (!item) return 0;
    const mult = 1 + (item.upgradeLevel || 0) * 0.12;
    let score = 0;
    const s = item.stats || {};
    score += (s.attackPower || 0) * 2.2 * mult;
    score += (s.spellPower || 0) * 2.2 * mult;
    score += (s.str || 0) * 4.5 * mult;
    score += (s.agi || 0) * 4.0 * mult;
    score += (s.int || 0) * 4.2 * mult;
    score += (s.maxHp || 0) * 0.35 * mult;
    score += (s.armor || 0) * 1.4 * mult;
    score += (s.critChance || 0) * 380 * mult;
    score += (s.haste || 0) * 420 * mult;
    score += (s.block || 0) * 260 * mult;
    score += ((s.fireRes || 0) + (s.lightningRes || 0) + (s.poisonRes || 0)) * 180 * mult;

    for (const a of item.affixes || []) {
      const cMult = 1 + ((item.catalystBoosts?.[a.tag] || 0) / 100);
      const val = (a.value || 0) * mult * cMult;
      if (["critChance", "haste", "block", "fireRes", "lightningRes", "poisonRes"].includes(a.stat)) score += val * 360;
      else if (a.stat.endsWith("DmgPct")) score += val * 240;
      else if (a.stat === "maxHp") score += val * 0.35;
      else score += val * 2.3;
    }
    for (const r of item.socketedRunes || []) score += computeItemPowerScore(r);
    score += (item.ruleMutators?.length || 0) * 35;
    score += (item.sockets || 0) * 10;
    return Math.round(score);
  }

  function rollCampaignDrop(zoneIndex, wave, isBoss, isChampion, rnd, forceRarity = null) {
    const zone = getCampaignZone(zoneIndex);
    const ilvl = Math.max(1, zone.ilvlBase + Math.floor(wave * 1.4));

    // Slot selection (weapons/armor/shields/tomes + Rings/Runes/Trinkets)
    const slotWeights = [
      ["weapon", 22], ["armor", 18], ["shield", 14], ["tome", 14],
      ["ring", 12], ["rune", 10], ["trinket", 10],
    ];
    let sw = rnd() * 100, slot = "weapon";
    for (const [sl, w] of slotWeights) { sw -= w; if (sw <= 0) { slot = sl; break; } }

    // Rarity roll
    let rarity = forceRarity;
    if (!rarity) {
      const rRoll = rnd() * 100;
      if (isBoss) {
        rarity = rRoll < 12 ? "Corrupted" : rRoll < 38 ? "Legendary" : rRoll < 78 ? "Epic" : "Rare";
      } else if (isChampion) {
        rarity = rRoll < 2 ? "Corrupted" : rRoll < 10 ? "Legendary" : rRoll < 32 ? "Epic" : rRoll < 74 ? "Rare" : "Uncommon";
      } else {
        rarity = rRoll < 0.8 ? "Corrupted" : rRoll < 4.5 ? "Legendary" : rRoll < 14 ? "Epic" : rRoll < 34 ? "Rare" : rRoll < 68 ? "Uncommon" : "Common";
      }
    }

    const rIdx = RARITY_RANK[rarity] ?? 0;
    const rarityMult = [1.0, 1.25, 1.55, 1.9, 2.35, 2.65][rIdx];
    const stats = {};
    const tags = new Set();

    const scale = (1 + (ilvl - 1) * 0.22) * rarityMult;
    if (slot === "weapon") {
      const isCaster = rnd() < 0.38;
      if (isCaster) {
        stats.spellPower = Math.max(4, Math.round(8 * scale));
        stats.attackPower = Math.max(2, Math.round(4 * scale));
        tags.add("INT");
      } else {
        stats.attackPower = Math.max(5, Math.round(10 * scale));
        tags.add("STR");
        tags.add("Physical");
      }
      stats.critChance = Number(Math.min(0.14, 0.015 + rIdx * 0.01 + rnd() * 0.02).toFixed(3));
    } else if (slot === "armor") {
      stats.maxHp = Math.round(45 * scale);
      stats.armor = Math.round(8 * scale);
      tags.add("Resist/Block");
    } else if (slot === "shield") {
      stats.maxHp = Math.round(30 * scale);
      stats.armor = Math.round(10 * scale);
      stats.block = Number(Math.min(0.24, 0.05 + rIdx * 0.02).toFixed(3));
      tags.add("Resist/Block");
    } else if (slot === "tome") {
      stats.spellPower = Math.round(8 * scale);
      stats.int = Math.max(1, Math.round(2 * scale));
      tags.add("INT");
    } else if (slot === "ring") {
      stats.attackPower = Math.round(4 * scale);
      stats.spellPower = Math.round(4 * scale);
      stats.critChance = Number(Math.min(0.10, 0.02 + rIdx * 0.012).toFixed(3));
      tags.add("Haste/Crit");
    } else if (slot === "rune") {
      stats.attackPower = Math.round(4.5 * scale);
      stats.spellPower = Math.round(4.5 * scale);
      stats.haste = Number(Math.min(0.10, 0.015 + rIdx * 0.01).toFixed(3));
      tags.add("Haste/Crit");
    } else if (slot === "trinket") {
      stats.maxHp = Math.round(22 * scale);
      stats.attackPower = Math.round(5 * scale);
      stats.spellPower = Math.round(5 * scale);
    }

    // Roll affixes
    const affixCounts = [1, 2, 3, 4, 4, 5];
    const numAffixes = affixCounts[rIdx];
    const affixes = [];
    const usedStats = new Set();
    for (let i = 0; i < numAffixes; i++) {
      const def = AFFIX_POOL[Math.floor(rnd() * AFFIX_POOL.length)];
      if (usedStats.has(def.stat)) continue;
      usedStats.add(def.stat);
      const rawVal = (def.base + def.perIlvl * (ilvl - 1) * 0.45) * (0.85 + rnd() * 0.3) * (1 + rIdx * 0.14);
      const val = def.pct ? Number(Math.min(0.45, rawVal).toFixed(3)) : Math.max(1, Math.round(rawVal));
      affixes.push({ name: def.name, stat: def.stat, value: val, tag: def.tag, pct: !!def.pct });
      if (def.tag) tags.add(def.tag);
    }

    // Rune Sockets (weapon, armor, shield, tome)
    let sockets = 0;
    if (["weapon", "armor", "shield", "tome"].includes(slot)) {
      const sRoll = rnd();
      if (rIdx >= 3 && sRoll < 0.45) sockets = 2;
      else if (rIdx >= 2 && sRoll < 0.25) sockets = 2;
      else if (rIdx >= 1 && sRoll < 0.55) sockets = 1;
      if (isBoss && sockets < 2 && rnd() < 0.5) sockets = 2;
    }

    // Build-Revamping Mutators on Rare+ items
    const ruleMutators = [];
    const mutChance = rarity === "Rare" ? 0.30 : rarity === "Epic" ? 0.60 : (rarity === "Legendary" || rarity === "Corrupted") ? 1.0 : 0;
    if (rnd() < mutChance) {
      const m = CAMPAIGN_MUTATORS[Math.floor(rnd() * CAMPAIGN_MUTATORS.length)];
      ruleMutators.push({ ...m });
      if (m.tag) tags.add(m.tag);
    }

    // Corrupted implicit bonus
    if (rarity === "Corrupted") {
      const corruptRoll = Math.floor(rnd() * 4);
      if (corruptRoll === 0) stats.critMulti = Number(((stats.critMulti || 0) + 0.20).toFixed(2));
      else if (corruptRoll === 1) stats.haste = Number(((stats.haste || 0) + 0.06).toFixed(3));
      else if (corruptRoll === 2) { stats.fireRes = Number(((stats.fireRes || 0) + 0.10).toFixed(2)); stats.lightningRes = Number(((stats.lightningRes || 0) + 0.10).toFixed(2)); stats.poisonRes = Number(((stats.poisonRes || 0) + 0.10).toFixed(2)); }
      else stats.increasedDamage = Number(((stats.increasedDamage || 0) + 0.16).toFixed(2));
    }

    const baseList = SLOT_BASE_NAMES[slot] || ["Relic"];
    const baseName = baseList[Math.floor(rnd() * baseList.length)];
    const prefix = affixes[0]?.name ? `${affixes[0].name} ` : "";
    const mutSuffix = ruleMutators[0] ? ` of ${ruleMutators[0].name}` : "";

    const item = {
      id: `CMP-EQP-${Math.floor(rnd() * 1e9).toString(36)}`,
      name: `${prefix}${baseName}${mutSuffix}`.trim(),
      slot,
      rarity,
      tier: RARITY_TIER[rarity] || 1,
      ilvl,
      upgradeLevel: 0,
      swingTicks: slot === "weapon" ? (14 + Math.floor(rnd() * 7)) : undefined,
      icon: GEAR_ICONS[slot] || GEAR_ICONS.weapon,
      tags: Array.from(tags),
      stats,
      affixes,
      sockets,
      socketedRunes: [],
      ruleMutators,
      hooks: ruleMutators.map(m => ({ kind: `mut:${m.id}`, description: m.description })),
      catalystBoosts: {},
      corrupted: rarity === "Corrupted",
      isNew: true,
    };
    item.powerScore = computeItemPowerScore(item);
    return item;
  }

  function rollCampaignMaterials(isBoss, isChampion, rnd) {
    const found = [];
    const mult = isBoss ? 12 : isChampion ? 2.5 : 1;

    // 1. Tag Catalysts (~2.5% base per kill)
    if (rnd() < Math.min(0.85, 0.025 * mult)) {
      const tagCats = Object.values(MATERIALS_META).filter(m => m.kind === "tag");
      const pick = tagCats[Math.floor(rnd() * tagCats.length)];
      found.push(pick.id);
    }
    // 2. Prism / Nullifying Catalysts (~0.8% base per kill)
    if (rnd() < Math.min(0.45, 0.008 * mult)) {
      found.push(rnd() < 0.55 ? "cat_prism" : "cat_nullifying");
    }
    // 3. Overclock Corruption Core (~0.25% base wave kill, ~14% from Zone Boss)
    const coreChance = isBoss ? 0.14 : isChampion ? 0.012 : 0.0025;
    if (rnd() < coreChance) {
      found.push("cat_overclock");
    }
    return found;
  }

  function evaluateLootFilter(item, filter) {
    if (!item || !filter) return { keep: true, reason: "No filter" };

    // Always Keep Overrides
    if (filter.keepMutators && (item.ruleMutators?.length || 0) > 0) {
      return { keep: true, reason: "Override: Build-Revamping Mutator" };
    }
    if (filter.keepTwoSockets && (item.sockets || 0) >= 2) {
      return { keep: true, reason: "Override: 2+ Rune Sockets" };
    }
    if (filter.keepRunesTrinkets && (item.slot === "rune" || item.slot === "trinket")) {
      return { keep: true, reason: "Override: Rune / Trinket" };
    }

    // Minimum Rarity check
    const minRank = RARITY_RANK[filter.minRarity || "Common"] ?? 0;
    const itemRank = RARITY_RANK[item.rarity || "Common"] ?? 0;
    if (itemRank < minRank) {
      return { keep: false, reason: `Rarity ${item.rarity} < ${filter.minRarity}` };
    }

    // Tag / Stat Whitelist check
    const selectedTags = filter.tags || [];
    if (selectedTags.length > 0) {
      const itemTags = new Set(item.tags || []);
      let matches = 0;
      for (const t of selectedTags) {
        if (itemTags.has(t)) matches++;
      }
      const need = Math.min(selectedTags.length, Math.max(1, Number(filter.minTagMatches) || 1));
      if (matches < need) {
        return { keep: false, reason: `Matched ${matches}/${need} selected tags` };
      }
    }

    return { keep: true, reason: "Matched Filter" };
  }

  function salvageItemToMaterials(item) {
    if (!item) return { forged_scrap: 0, arcane_dust: 0, essence_shards: 0 };
    const rIdx = RARITY_RANK[item.rarity || "Common"] ?? 0;
    const baseAmt = Math.max(1, Math.round((2 + (item.ilvl || 1) * 0.25) * (1 + rIdx * 0.65)));
    const isMetal = ["weapon", "armor", "shield"].includes(item.slot);
    return {
      forged_scrap: isMetal ? baseAmt : Math.max(1, Math.floor(baseAmt * 0.45)),
      arcane_dust: isMetal ? Math.max(1, Math.floor(baseAmt * 0.45)) : baseAmt,
      essence_shards: rIdx >= 2 ? Math.max(1, rIdx - 1) : 0,
    };
  }

  function resolveItemLootDrop(campaign, item, onKeep, onSalvage) {
    const res = evaluateLootFilter(item, campaign.lootFilter);
    if (res.keep) {
      campaign.inventory.unshift(item);
      campaign.statsSummary.itemsKept = (campaign.statsSummary.itemsKept || 0) + 1;
      // Keep bag bounded at 80 entries so localStorage stays lean
      if (campaign.inventory.length > 80) {
        const overflow = campaign.inventory.pop();
        const mats = salvageItemToMaterials(overflow);
        campaign.materials.forged_scrap = (campaign.materials.forged_scrap || 0) + mats.forged_scrap;
        campaign.materials.arcane_dust = (campaign.materials.arcane_dust || 0) + mats.arcane_dust;
        campaign.materials.essence_shards = (campaign.materials.essence_shards || 0) + mats.essence_shards;
      }
      if (onKeep) onKeep(item, res.reason);
      return { kept: true, reason: res.reason };
    }
    const mats = salvageItemToMaterials(item);
    campaign.materials.forged_scrap = (campaign.materials.forged_scrap || 0) + mats.forged_scrap;
    campaign.materials.arcane_dust = (campaign.materials.arcane_dust || 0) + mats.arcane_dust;
    campaign.materials.essence_shards = (campaign.materials.essence_shards || 0) + mats.essence_shards;
    campaign.statsSummary.itemsSalvaged = (campaign.statsSummary.itemsSalvaged || 0) + 1;
    if (onSalvage) onSalvage(item, mats, res.reason);
    return { kept: false, mats, reason: res.reason };
  }

  function findCampaignItem(campaign, itemId) {
    if (!itemId) return null;
    return (campaign.inventory || []).find(x => x.id === itemId)
      || Object.values(campaign.equipped || {}).find(x => x && x.id === itemId)
      || null;
  }

  // Crafting Workbench Operations
  function upgradeItemRank(campaign, itemId) {
    const item = findCampaignItem(campaign, itemId);
    if (!item) return { ok: false, error: "Item not found." };
    const rank = item.upgradeLevel || 0;
    if (rank >= 10) return { ok: false, error: "Item is already at max rank (+10)." };
    const scrapCost = 4 + rank * 3;
    const dustCost = 2 + rank * 2;
    if ((campaign.materials.forged_scrap || 0) < scrapCost || (campaign.materials.arcane_dust || 0) < dustCost) {
      return { ok: false, error: `Need ${scrapCost} Forged Scrap and ${dustCost} Arcane Dust.` };
    }
    campaign.materials.forged_scrap -= scrapCost;
    campaign.materials.arcane_dust -= dustCost;
    item.upgradeLevel = rank + 1;
    item.powerScore = computeItemPowerScore(item);
    return { ok: true, message: `Upgraded ${item.name} to +${item.upgradeLevel}!` };
  }

  function addRuneSocket(campaign, itemId) {
    const item = findCampaignItem(campaign, itemId);
    if (!item) return { ok: false, error: "Item not found." };
    if (!["weapon", "armor", "shield", "tome"].includes(item.slot)) {
      return { ok: false, error: "Only Weapon, Armor, Shield, or Tome can gain Rune sockets." };
    }
    const sockets = item.sockets || 0;
    if (sockets >= 3) return { ok: false, error: "Item already has max 3 Rune sockets." };
    const scrapCost = 10 + sockets * 10;
    const shardCost = 2 + sockets * 2;
    if ((campaign.materials.forged_scrap || 0) < scrapCost || (campaign.materials.essence_shards || 0) < shardCost) {
      return { ok: false, error: `Need ${scrapCost} Forged Scrap and ${shardCost} Essence Shards.` };
    }
    campaign.materials.forged_scrap -= scrapCost;
    campaign.materials.essence_shards -= shardCost;
    item.sockets = sockets + 1;
    item.powerScore = computeItemPowerScore(item);
    return { ok: true, message: `Added Rune Socket (${item.sockets}/3) to ${item.name}.` };
  }

  function socketRuneIntoItem(campaign, itemId, runeId) {
    const item = findCampaignItem(campaign, itemId);
    const runeIdx = (campaign.inventory || []).findIndex(x => x.id === runeId && x.slot === "rune");
    if (!item || runeIdx < 0) return { ok: false, error: "Select a valid item and Rune from inventory." };
    item.socketedRunes = item.socketedRunes || [];
    if (item.socketedRunes.length >= (item.sockets || 0)) {
      return { ok: false, error: "No open Rune sockets remaining on this item." };
    }
    const [rune] = campaign.inventory.splice(runeIdx, 1);
    item.socketedRunes.push(rune);
    item.powerScore = computeItemPowerScore(item);
    return { ok: true, message: `Socketed ${rune.name} into ${item.name}!` };
  }

  function rerollItemAffixes(campaign, itemId, rnd = Math.random) {
    const item = findCampaignItem(campaign, itemId);
    if (!item) return { ok: false, error: "Item not found." };
    const dustCost = 6;
    const shardCost = 1;
    if ((campaign.materials.arcane_dust || 0) < dustCost || (campaign.materials.essence_shards || 0) < shardCost) {
      return { ok: false, error: `Need ${dustCost} Arcane Dust and ${shardCost} Essence Shards.` };
    }
    campaign.materials.arcane_dust -= dustCost;
    campaign.materials.essence_shards -= shardCost;
    const count = Math.max(1, (item.affixes || []).length || 2);
    const rIdx = RARITY_RANK[item.rarity || "Common"] ?? 0;
    const nextAffixes = [];
    const used = new Set();
    for (let i = 0; i < count; i++) {
      const def = AFFIX_POOL[Math.floor(rnd() * AFFIX_POOL.length)];
      if (used.has(def.stat)) continue;
      used.add(def.stat);
      const rawVal = (def.base + def.perIlvl * ((item.ilvl || 1) - 1) * 0.45) * (0.9 + rnd() * 0.28) * (1 + rIdx * 0.14);
      const val = def.pct ? Number(Math.min(0.45, rawVal).toFixed(3)) : Math.max(1, Math.round(rawVal));
      nextAffixes.push({ name: def.name, stat: def.stat, value: val, tag: def.tag, pct: !!def.pct });
      if (def.tag && !(item.tags || []).includes(def.tag)) {
        item.tags = [...(item.tags || []), def.tag];
      }
    }
    item.affixes = nextAffixes;
    item.powerScore = computeItemPowerScore(item);
    return { ok: true, message: `Rerolled ${nextAffixes.length} affixes on ${item.name}!` };
  }

  function applyCatalystToItem(campaign, itemId, catalystId, rnd = Math.random) {
    const item = findCampaignItem(campaign, itemId);
    const meta = MATERIALS_META[catalystId];
    if (!item || !meta || meta.tier !== 2) return { ok: false, error: "Invalid item or catalyst." };
    if ((campaign.materials[catalystId] || 0) < 1) return { ok: false, error: `No ${meta.name} available.` };

    if (meta.kind === "tag") {
      item.catalystBoosts = item.catalystBoosts || {};
      const cap = item.corrupted ? 30 : 20;
      const cur = item.catalystBoosts[meta.tag] || 0;
      if (cur >= cap) return { ok: false, error: `${meta.tag} quality is already at +${cap}% cap.` };
      campaign.materials[catalystId]--;
      item.catalystBoosts[meta.tag] = Math.min(cap, cur + 10);
      if (!(item.tags || []).includes(meta.tag)) item.tags = [...(item.tags || []), meta.tag];
      // Ensure item has at least one matching stat if none existed
      const hasMatch = (item.affixes || []).some(a => a.tag === meta.tag);
      if (!hasMatch) {
        const matchDef = AFFIX_POOL.find(a => a.tag === meta.tag);
        if (matchDef) {
          const rawVal = (matchDef.base + matchDef.perIlvl * ((item.ilvl || 1) - 1) * 0.4);
          const val = matchDef.pct ? Number(Math.min(0.45, rawVal).toFixed(3)) : Math.max(1, Math.round(rawVal));
          item.affixes = [...(item.affixes || []), { name: matchDef.name, stat: matchDef.stat, value: val, tag: matchDef.tag, pct: !!matchDef.pct }];
        }
      }
      item.powerScore = computeItemPowerScore(item);
      return { ok: true, message: `Infused ${meta.name}: ${item.name} (${meta.tag} +${item.catalystBoosts[meta.tag]}%).` };
    }

    if (meta.kind === "prism") {
      const rIdx = RARITY_RANK[item.rarity || "Common"] ?? 0;
      if (rIdx >= 3) return { ok: false, error: "Prism Catalyst works on Common, Uncommon, or Rare items (up to Epic)." };
      campaign.materials[catalystId]--;
      const nextRarity = RARITIES[Math.min(3, rIdx + 1)];
      item.rarity = nextRarity;
      item.tier = RARITY_TIER[nextRarity];
      const def = AFFIX_POOL[Math.floor(rnd() * AFFIX_POOL.length)];
      const rawVal = (def.base + def.perIlvl * ((item.ilvl || 1) - 1) * 0.45) * (1 + (rIdx + 1) * 0.16);
      const val = def.pct ? Number(Math.min(0.45, rawVal).toFixed(3)) : Math.max(1, Math.round(rawVal));
      item.affixes = [...(item.affixes || []), { name: def.name, stat: def.stat, value: val, tag: def.tag, pct: !!def.pct }];
      if (def.tag && !(item.tags || []).includes(def.tag)) item.tags = [...(item.tags || []), def.tag];
      item.powerScore = computeItemPowerScore(item);
      return { ok: true, message: `Prism Catalyst elevated ${item.name} to ${nextRarity}!` };
    }

    if (meta.kind === "nullify") {
      if (!(item.affixes || []).length) return { ok: false, error: "Item has no affixes to reforge." };
      campaign.materials[catalystId]--;
      let weakIdx = 0;
      let weakScore = Infinity;
      item.affixes.forEach((a, idx) => {
        const sc = a.pct ? a.value * 300 : a.value;
        if (sc < weakScore) { weakScore = sc; weakIdx = idx; }
      });
      const def = AFFIX_POOL[Math.floor(rnd() * AFFIX_POOL.length)];
      const rIdx = RARITY_RANK[item.rarity || "Common"] ?? 0;
      const rawVal = (def.base + def.perIlvl * ((item.ilvl || 1) - 1) * 0.55) * (1.2 + rIdx * 0.16);
      const val = def.pct ? Number(Math.min(0.45, rawVal).toFixed(3)) : Math.max(1, Math.round(rawVal));
      item.affixes[weakIdx] = { name: def.name, stat: def.stat, value: val, tag: def.tag, pct: !!def.pct };
      item.powerScore = computeItemPowerScore(item);
      return { ok: true, message: `Nullifying Catalyst reforged an affix on ${item.name}!` };
    }

    if (meta.kind === "corrupt") {
      if (item.corrupted) return { ok: false, error: "Item is already Overclocked / Corrupted." };
      campaign.materials[catalystId]--;
      item.corrupted = true;
      item.rarity = "Corrupted";
      item.tier = 5;
      item.catalystBoosts = item.catalystBoosts || {};
      for (const k of Object.keys(item.catalystBoosts)) {
        item.catalystBoosts[k] = Math.min(30, item.catalystBoosts[k] + 10);
      }
      if (!Object.keys(item.catalystBoosts).length) {
        const t = (item.tags || [])[0] || "Physical";
        item.catalystBoosts[t] = 30;
      }
      item.stats = item.stats || {};
      item.stats.critMulti = Number(((item.stats.critMulti || 0) + 0.15).toFixed(2));
      item.stats.increasedDamage = Number(((item.stats.increasedDamage || 0) + 0.12).toFixed(2));
      if (!(item.ruleMutators || []).length) {
        const m = CAMPAIGN_MUTATORS[Math.floor(rnd() * CAMPAIGN_MUTATORS.length)];
        item.ruleMutators = [{ ...m }];
        item.hooks = [{ kind: `mut:${m.id}`, description: m.description }];
      }
      item.powerScore = computeItemPowerScore(item);
      return { ok: true, message: `Overclock Core corrupted ${item.name} (+30% Catalyst cap & +12% Damage)!` };
    }

    return { ok: false, error: "Unsupported catalyst." };
  }

  // Randomized 1-5 enemy wave builder (Normal packs, Armored Vanguards, Backline Hexers, Support Warders, Rare Champions)
  function buildCampaignWave(data, zoneIndex, wave, rnd) {
    const zone = getCampaignZone(zoneIndex);
    const waveNum = Math.max(1, Number(wave) || 1);
    const count = 1 + Math.floor(rnd() * 5); // 1 to 5 enemies
    const waveScale = 1 + (waveNum - 1) * 0.12;
    const hpTotalScale = zone.hpMult * waveScale;
    const dmgTotalScale = zone.dmgMult * (1 + (waveNum - 1) * 0.08);
    const boardSlots = [null, null, null, null, null];
    const enemies = [];

    const slotOrder = count === 1 ? [2] : count === 2 ? [1, 3] : count === 3 ? [1, 2, 3] : count === 4 ? [0, 1, 2, 3] : [0, 1, 2, 3, 4];
    let hasChampion = false;

    for (let i = 0; i < count; i++) {
      const slotIndex = slotOrder[i];
      const enId = zone.enemyPool[Math.floor(rnd() * zone.enemyPool.length)];
      const def = data.enemies.find(e => e.id === enId) || data.enemies[0];

      // Pick archetype
      let archetype = "Normal";
      const roll = rnd();
      if (!hasChampion && waveNum >= 2 && roll < 0.16) {
        archetype = "Rare Champion";
        hasChampion = true;
      } else if (slotIndex >= 3 && roll < 0.55) {
        archetype = "Backline Hexer";
      } else if (i > 0 && roll < 0.45) {
        archetype = "Support Warder";
      } else if (roll < 0.72) {
        archetype = "Armored Vanguard";
      }

      let hpMult = 1.0, dmgMult = 1.0, dr = zone.armorDr, rank = "Normal", atkIntMult = 1.0;
      let prefix = "";
      if (archetype === "Armored Vanguard") {
        hpMult = 1.3; dmgMult = 0.95; dr = Math.min(0.65, zone.armorDr + 0.25); prefix = "Vanguard ";
      } else if (archetype === "Backline Hexer") {
        hpMult = 0.8; dmgMult = 1.25; atkIntMult = 0.85; prefix = "Hexer ";
      } else if (archetype === "Support Warder") {
        hpMult = 1.05; dmgMult = 0.8; prefix = "Warder ";
      } else if (archetype === "Rare Champion") {
        hpMult = 2.5; dmgMult = 1.5; dr = Math.min(0.65, zone.armorDr + 0.15); rank = "Elite"; prefix = "Champion ";
      }

      const maxHp = Math.max(12, Math.round(def.hp * 0.55 * hpTotalScale * hpMult));
      const attack = Math.max(2, Math.round(def.attack * 1.45 * dmgTotalScale * dmgMult));
      const baseInt = Math.max(10, Math.round(((def.attackIntervalMs || 2100) / 100) * atkIntMult));
      const en = {
        ...def,
        name: `${prefix}${def.name}`,
        archetype,
        isChampion: archetype === "Rare Champion",
        isWarder: archetype === "Support Warder",
        wardCooldownTicks: 40 + Math.floor(rnd() * 20),
        uid: i,
        slotIndex,
        rank,
        frame: RANK_FRAMES[rank] || RANK_FRAMES.Normal,
        maxHp,
        hp: maxHp,
        wardHp: 0,
        attack,
        mitigation: dr,
        elemResist: zone.resPct,
        attackIntervalTicks: baseInt,
        attackTimer: baseInt * (0.45 + i * 0.14),
        ailments: {},
        lastHitCrit: false,
        dead: false,
        comboCdTicks: 0,
        slowTicks: 0,
        slowPct: 0,
        xpReward: Math.round(zone.xpBase * (1 + (waveNum - 1) * 0.08) * (archetype === "Rare Champion" ? 2.4 : 1) / Math.max(1, count * 0.45)),
        goldReward: Math.round(zone.goldBase * (1 + (waveNum - 1) * 0.08) * (archetype === "Rare Champion" ? 2.8 : 1) / Math.max(1, count * 0.5)),
      };
      enemies.push(en);
      boardSlots[slotIndex] = en;
    }

    return { enemies, boardSlots, zone };
  }

  // Multi-Slot Zone Boss (occupies Slots 1–3, Posture Bar, Telegraphed Heavy Cast, 60s Enrage)
  function buildCampaignBoss(data, zoneIndex, wave) {
    const zone = getCampaignZone(zoneIndex);
    const def = data.enemies.find(e => e.id === zone.bossId) || data.enemies[data.enemies.length - 1];
    const maxHp = Math.round(920 * zone.hpMult * (1 + Math.max(0, wave - 1) * 0.05));
    const attack = Math.round(12 * zone.dmgMult);
    const boss = {
      ...def,
      name: zone.bossName,
      title: zone.bossTitle,
      school: zone.bossSchool || def.school,
      boss: true,
      isCampaignBoss: true,
      occupiedSlots: [1, 2, 3],
      uid: 0,
      slotIndex: 2,
      rank: "Boss",
      frame: RANK_FRAMES.Boss,
      maxHp,
      hp: maxHp,
      wardHp: 0,
      attack,
      mitigation: Math.min(0.60, zone.armorDr + 0.12),
      elemResist: zone.resPct,
      attackIntervalTicks: 18,
      attackTimer: 18,
      posture: 100,
      maxPosture: 100,
      staggerTicks: 0,
      telegraphCooldownTicks: 85, // casts every ~8.5s
      telegraphTicks: 0,
      telegraphMaxTicks: 28,      // 2.8s windup to interrupt
      telegraphName: zone.bossCastName || "Crushing Blow",
      enrageTicks: 600,           // Enrages at 60.0s
      enraged: false,
      ailments: {},
      lastHitCrit: false,
      dead: false,
      comboCdTicks: 0,
      slowTicks: 0,
      slowPct: 0,
      xpReward: Math.round(zone.xpBase * 6.5),
      goldReward: Math.round(zone.goldBase * 7.5),
    };
    return {
      enemies: [boss],
      boardSlots: [null, boss, null, null, null],
      zone,
    };
  }

  function startCampaignCharacter(campaign, data, classId, archetypeId) {
    const cls = data.classes.find(c => c.id === classId) || data.classes[0];
    const weapon = makeStarterWeaponItem(archetypeId);
    const unlocked = cls.loadout.slice(0, 2);

    campaign.started = true;
    campaign.classId = cls.id;
    campaign.starterWeaponArchetype = archetypeId;
    campaign.level = 1;
    campaign.xp = 0;
    campaign.xpNext = 100;
    campaign.restedXp = 75;
    campaign.gold = 0;
    campaign.deaths = 0;
    campaign.wavesCleared = 0;
    campaign.bossesKilled = 0;
    campaign.autoAdvance = true;
    campaign.unlockedZone = 0;
    campaign.zoneIndex = 0;
    campaign.wave = 1;
    campaign.maxWaveByZone = { 0: 1 };
    campaign.bossReadyPct = 0;
    campaign.unlockedAbilities = [...unlocked];
    campaign.loadout = [unlocked[0] || null, unlocked[1] || null, null, null, null];
    campaign.equipped = { weapon, armor: null, shield: null, tome: null, ring: null, rune: null, trinket: null };
    campaign.inventory = [];
    campaign.materials = {
      forged_scrap: 12,
      arcane_dust: 8,
      essence_shards: 2,
      cat_pyric: 0, cat_sanguine: 0, cat_voltaic: 0, cat_noxious: 0,
      cat_chrono: 0, cat_aegis: 0, cat_arcane: 0, cat_tempering: 0,
      cat_prism: 0, cat_nullifying: 0, cat_overclock: 0,
    };
    campaign.statsSummary = { itemsKept: 0, itemsSalvaged: 0, rareMaterials: 0 };
    campaign.lastDeathTip = null;
    campaign.lastOfflineSummary = null;
    campaign.seed = (campaign.seed || 20261122) + 1;
  }

  function grantCampaignXp(campaign, data, baseXp) {
    const raw = Math.max(0, Math.round(baseXp || 0));
    if (!raw) return { gained: 0, bonusUsed: 0, levelsGained: 0, unlockedNames: [] };

    let remainingBase = raw;
    let totalGained = 0;
    let bonusUsed = 0;
    let levelsGained = 0;
    const unlockedNames = [];

    const cls = data.classes.find(c => c.id === campaign.classId) || data.classes[0];
    while (remainingBase > 0) {
      const rested = Math.max(0, campaign.restedXp || 0);
      const bonus = Math.min(rested, remainingBase);
      campaign.restedXp = Math.max(0, rested - bonus);
      bonusUsed += bonus;
      const chunk = remainingBase + bonus;
      totalGained += chunk;
      campaign.xp += chunk;
      remainingBase = 0;

      while (campaign.xp >= campaign.xpNext) {
        campaign.xp -= campaign.xpNext;
        campaign.level++;
        levelsGained++;
        campaign.xpNext = Math.round(campaign.xpNext * 1.35);
        // Unlock next class skill cleanly at Lv 2, 3, 4
        const nextSkillId = (cls.loadout || []).find(id => !(campaign.unlockedAbilities || []).includes(id));
        if (nextSkillId) {
          campaign.unlockedAbilities.push(nextSkillId);
          const emptyIdx = campaign.loadout.indexOf(null);
          if (emptyIdx >= 0) campaign.loadout[emptyIdx] = nextSkillId;
          const ab = data.abilities.find(a => a.id === nextSkillId);
          if (ab) unlockedNames.push(ab.name);
        }
      }
    }
    const maxRested = Math.round(campaign.xpNext * 1.5);
    campaign.restedXp = Math.min(maxRested, campaign.restedXp || 0);
    return { gained: totalGained, bonusUsed, levelsGained, unlockedNames };
  }

  function applyCampfireDeathPenalty(campaign, wasBoss) {
    campaign.deaths = (campaign.deaths || 0) + 1;
    const maxRested = Math.round((campaign.xpNext || 100) * 1.5);
    const lost = Math.round(maxRested * 0.05);
    campaign.restedXp = Math.max(0, (campaign.restedXp || 0) - lost);
    if (!wasBoss) {
      campaign.wave = Math.max(1, (campaign.wave || 1) - 1);
    }
    return lost;
  }

  function buildCampaignCombatProfile(campaign, isBossFight = false) {
    const equippedIds = {};
    const campaignItems = [];
    for (const [slot, item] of Object.entries(campaign.equipped || {})) {
      if (item && typeof item === "object") {
        equippedIds[slot] = item.id;
        campaignItems.push(item);
      } else {
        equippedIds[slot] = null;
      }
    }
    return {
      level: campaign.level || 1,
      classId: campaign.classId || "templar",
      loadout: [...(campaign.loadout || [])],
      equipped: equippedIds,
      campaignItems,
      customSpells: [],
      customItems: [],
      statOverrides: null,
      sandboxEncounter: null,
      campaignMode: true,
      isBossFight,
      campaignZoneIndex: campaign.zoneIndex || 0,
      campaignWave: campaign.wave || 1,
      enableWeaponAutoAttack: true,
      botMode: "optimal",
      seed: campaign.seed || 20261122,
    };
  }

  // Deterministic Offline Progress Simulator fast-forwarding the real Combat engine
  function simulateOfflineHours(data, campaign, hours) {
    const Combat = window.Tickforge.Combat;
    const targetTicks = Math.max(100, Math.round(Number(hours) * 36000));
    const startLevel = campaign.level;
    const rnd = mulberry32(((campaign.seed || 20261122) + targetTicks) >>> 0);

    // Offline rest bonus: +10% of xpNext per simulated AFK hour (capped at 150%) if below cap
    const restedGrant = Math.round((campaign.xpNext || 100) * 0.10 * hours);
    campaign.restedXp = Math.min(Math.round(campaign.xpNext * 1.5), (campaign.restedXp || 0) + restedGrant);

    let ticksUsed = 0;
    let wavesCleared = 0;
    let deaths = 0;
    let xpGained = 0;
    let restedXpUsed = 0;
    let goldGained = 0;
    let itemsKept = 0;
    let itemsSalvaged = 0;
    const keptPreview = [];
    const materialsGained = { forged_scrap: 0, arcane_dust: 0, essence_shards: 0 };
    const rareMaterialsFound = {};

    const noopEvents = {
      fct() {}, feed() {}, fx() {}, projectile() {}, enemySwing() {}, pulse() {},
      death() {}, waveEnd() {}, playerDown() {},
    };

    while (ticksUsed < targetTicks) {
      campaign.seed = ((campaign.seed || 1) + 131) >>> 0;
      const simProfile = buildCampaignCombatProfile(campaign, false);
      const wavePack = buildCampaignWave(data, campaign.zoneIndex, campaign.wave, rnd);
      simProfile.prebuiltWave = wavePack;

      const c = new Combat(data, simProfile, noopEvents, { silent: true });
      while (!c.state.result && ticksUsed < targetTicks) {
        c.tick();
        ticksUsed++;
      }

      if (c.state.result === "victory") {
        wavesCleared++;
        campaign.wavesCleared = (campaign.wavesCleared || 0) + 1;
        let hasChampion = false;
        for (const en of (c.state.initialEnemies || wavePack.enemies || [])) {
          const xpRes = grantCampaignXp(campaign, data, en.xpReward || 24);
          xpGained += xpRes.gained;
          restedXpUsed += xpRes.bonusUsed;
          const g = en.goldReward || 12;
          campaign.gold = (campaign.gold || 0) + g;
          goldGained += g;
          if (en.isChampion) hasChampion = true;

          // Equipment drop roll (~24% normal, 65% champion)
          if (rnd() < (en.isChampion ? 0.65 : 0.24)) {
            const drop = rollCampaignDrop(campaign.zoneIndex, campaign.wave, false, en.isChampion, rnd);
            resolveItemLootDrop(
              campaign,
              drop,
              (it) => {
                itemsKept++;
                if (keptPreview.length < 6) keptPreview.push({ name: it.name, rarity: it.rarity, ilvl: it.ilvl });
              },
              (_it, mats) => {
                itemsSalvaged++;
                materialsGained.forged_scrap += mats.forged_scrap;
                materialsGained.arcane_dust += mats.arcane_dust;
                materialsGained.essence_shards += mats.essence_shards;
              }
            );
          }

          // Tier 2 Rare Material drop roll
          const matDrops = rollCampaignMaterials(false, en.isChampion, rnd);
          for (const mId of matDrops) {
            campaign.materials[mId] = (campaign.materials[mId] || 0) + 1;
            campaign.statsSummary.rareMaterials = (campaign.statsSummary.rareMaterials || 0) + 1;
            rareMaterialsFound[mId] = (rareMaterialsFound[mId] || 0) + 1;
          }
        }
        campaign.bossReadyPct = Math.min(100, (campaign.bossReadyPct || 0) + (hasChampion ? 35 : 20));
        if (campaign.autoAdvance) {
          campaign.wave++;
          campaign.maxWaveByZone[campaign.zoneIndex] = Math.max(campaign.maxWaveByZone[campaign.zoneIndex] || 1, campaign.wave);
        }
      } else if (c.state.result === "defeat") {
        deaths++;
        applyCampfireDeathPenalty(campaign, false);
        ticksUsed += 20; // 2.0s Campfire Recovery delay
      } else {
        // Time limit reached mid-wave
        break;
      }
    }

    const summary = {
      hours,
      wavesCleared,
      deaths,
      startLevel,
      endLevel: campaign.level,
      levelsGained: campaign.level - startLevel,
      xpGained,
      restedXpUsed,
      goldGained,
      itemsKept,
      keptPreview,
      itemsSalvaged,
      materialsGained,
      rareMaterialsFound,
      zoneName: getCampaignZone(campaign.zoneIndex).shortName,
      endingWave: campaign.wave,
    };
    campaign.lastOfflineSummary = summary;
    return summary;
  }

  function runCampaignMonteCarlo(data, campaign, opts = {}) {
    const runMc = window.Tickforge.runMonteCarlo;
    const target = ["wave", "boss", "next_zone"].includes(opts.target) ? opts.target : "boss";
    const runs = Math.max(1, Math.min(250, Math.round(Number(opts.runs) || 50)));
    const baseSeed = opts.baseSeed != null ? Number(opts.baseSeed) : ((campaign.seed || 20261122) >>> 0);

    const simCampaign = opts.overrideItem
      ? {
          ...campaign,
          equipped: {
            ...(campaign.equipped || {}),
            [opts.overrideItem.slot]: opts.overrideItem,
          },
        }
      : campaign;

    const targetZoneIdx = target === "next_zone" ? (campaign.zoneIndex || 0) + 1 : (campaign.zoneIndex || 0);
    const targetWave = target === "next_zone" ? 1 : (campaign.wave || 1);
    const isBossFight = target === "boss";
    const zone = getCampaignZone(targetZoneIdx);

    let expectedXpPerWin = 0;
    let expectedGoldPerWin = 0;

    const factory = (_idx, rnd) => {
      const simProfile = buildCampaignCombatProfile(simCampaign, isBossFight);
      simProfile.campaignZoneIndex = targetZoneIdx;
      simProfile.campaignWave = targetWave;
      const pack = isBossFight
        ? buildCampaignBoss(data, targetZoneIdx, targetWave)
        : buildCampaignWave(data, targetZoneIdx, targetWave, rnd);
      simProfile.prebuiltWave = pack;
      for (const en of pack.enemies) {
        expectedXpPerWin += en.xpReward || 24;
        expectedGoldPerWin += en.goldReward || 12;
      }
      return simProfile;
    };

    const mc = runMc(data, factory, runs, baseSeed);
    const avgXpWin = expectedXpPerWin / runs;
    const avgGoldWin = expectedGoldPerWin / runs;
    const restedMult = (campaign.restedXp || 0) > 0 ? 1.5 : 1.0;

    // Average wall-clock time per fight factoring 2.0s campfire recovery on defeats/timeouts
    const lossRate = (mc.defeats + mc.timeouts) / runs;
    const avgCycleSec = Math.max(0.5, mc.avgTtkSec + lossRate * 2.0);
    const winsPerHour = ((mc.wins / runs) * 3600) / avgCycleSec;
    const xpPerHour = Math.round(winsPerHour * avgXpWin * restedMult);
    const goldPerHour = Math.round(winsPerHour * avgGoldWin);

    let verdict = "HIGH RISK";
    let verdictCode = "HIGH_RISK";
    let advice = "";

    if (mc.winRatePct >= 95 && mc.enrageRatePct === 0 && mc.avgHpRemainingPct >= 35) {
      verdict = "SAFE CLEAR";
      verdictCode = "SAFE_CLEAR";
      advice = target === "boss"
        ? `Strong clear margin (${mc.avgHpRemainingPct}% avg HP left). Ready to challenge ${zone.bossName}.`
        : target === "next_zone"
        ? `Ready for ${zone.shortName} (${zone.hpMult}× HP, ${zone.dmgMult}× DMG).`
        : `Consistent wave farming (~${xpPerHour.toLocaleString()} XP/hr).`;
    } else if (mc.winRatePct >= 75) {
      verdict = "CONTESTED";
      verdictCode = "CONTESTED";
      advice = mc.enrageRatePct > 0
        ? `${mc.enrageRatePct}% runs hit Boss Enrage. Upgrade Weapon DPS or slot Haste/Crit gear.`
        : `Clearable (${mc.winRatePct}% win), though close on HP (${mc.avgHpRemainingPct}% left). Adding Armor or Resist improves safety.`;
    } else if (target === "next_zone" || mc.winRatePct < 45) {
      verdict = "STAT WALL";
      verdictCode = "STAT_WALL";
      advice = mc.enrageRatePct > 15
        ? `DPS check failing (${mc.enrageRatePct}% Enrage). Forge Weapon ranks, socket Runes, or tune hotbar priority.`
        : `${zone.shortName} hits hard (${Math.round(zone.armorDr * 100)}% DR, ${Math.round(zone.resPct * 100)}% Res). Farm current zone Rare+ gear & Forge upgrades first.`;
    } else {
      verdict = "HIGH RISK";
      verdictCode = "HIGH_RISK";
      advice = `High death risk (${mc.defeats}/${mc.runs} defeats). Improve Armor/Block/Resistances or step down a wave.`;
    }

    return {
      ...mc,
      target,
      targetLabel:
        target === "boss"
          ? `${zone.bossName} (Zone ${targetZoneIdx + 1} Boss)`
          : target === "next_zone"
          ? `${zone.name} Wave 1`
          : `${zone.shortName} Wave ${targetWave}`,
      zoneName: zone.shortName,
      xpPerHour,
      goldPerHour,
      verdict,
      verdictCode,
      advice,
    };
  }

  function compareCampaignCandidate(data, campaign, candidateItem, opts = {}) {
    const baseSeed = opts.baseSeed != null ? Number(opts.baseSeed) : ((campaign.seed || 20261122) >>> 0);
    const runs = opts.runs || 50;
    const target = opts.target || "boss";

    const baseline = runCampaignMonteCarlo(data, campaign, { target, runs, baseSeed });
    const candidate = runCampaignMonteCarlo(data, campaign, { target, runs, baseSeed, overrideItem: candidateItem });
    const equippedItem = campaign.equipped?.[candidateItem.slot] || null;

    return {
      baseline,
      candidate,
      candidateItem,
      equippedItem,
      deltas: {
        winRatePct: Number((candidate.winRatePct - baseline.winRatePct).toFixed(1)),
        avgDps: candidate.avgDps - baseline.avgDps,
        p50Dps: candidate.p50Dps - baseline.p50Dps,
        avgTtkSec: Number((candidate.avgTtkSec - baseline.avgTtkSec).toFixed(2)),
        xpPerHour: candidate.xpPerHour - baseline.xpPerHour,
        avgHpRemainingPct: Number((candidate.avgHpRemainingPct - baseline.avgHpRemainingPct).toFixed(1)),
      },
    };
  }

  window.Tickforge = Object.assign(window.Tickforge || {}, {
    CAMPAIGN_RARITIES: RARITIES,
    RARITY_COLOR,
    FILTER_TAGS,
    STARTER_WEAPONS,
    CAMPAIGN_MUTATORS,
    MATERIALS_META,
    getCampaignZone,
    makeStarterWeaponItem,
    computeItemPowerScore,
    rollCampaignDrop,
    rollCampaignMaterials,
    evaluateLootFilter,
    salvageItemToMaterials,
    resolveItemLootDrop,
    upgradeItemRank,
    addRuneSocket,
    socketRuneIntoItem,
    rerollItemAffixes,
    applyCatalystToItem,
    buildCampaignWave,
    buildCampaignBoss,
    startCampaignCharacter,
    grantCampaignXp,
    applyCampfireDeathPenalty,
    buildCampaignCombatProfile,
    simulateOfflineHours,
    runCampaignMonteCarlo,
    compareCampaignCandidate,
  });
})();
