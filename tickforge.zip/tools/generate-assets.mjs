// Tickforge asset generator — programmatic SVG portraits, icons and FX sprites.
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";

mkdirSync("assets/enemies", { recursive: true });
mkdirSync("assets/icons", { recursive: true });
mkdirSync("assets/fx", { recursive: true });

const T = {
  enemies: JSON.parse(readFileSync("data/enemies.json", "utf8")),
  abilities: JSON.parse(readFileSync("data/abilities.json", "utf8")),
  schools: JSON.parse(readFileSync("data/schools.json", "utf8")),
};

function svg(body, w = 120, h = 120) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}">${body}</svg>`;
}

// ── Enemy portraits: dark oval vignette + creature silhouette keyed by shape ──
const shapes = {
  ram:`<path d="M60 34 C42 34 30 50 30 68 C30 90 44 100 60 100 C76 100 90 90 90 68 C90 50 78 34 60 34 Z" fill="{c}"/><path d="M30 52 C18 44 14 30 22 24 C30 18 40 26 42 36 M90 52 C102 44 106 30 98 24 C90 18 80 26 78 36" stroke="{c}" stroke-width="9" fill="none" stroke-linecap="round"/><circle cx="50" cy="62" r="4" fill="#0b0e16"/><circle cx="70" cy="62" r="4" fill="#0b0e16"/>`,
  worm:`<path d="M28 88 C28 56 44 40 60 40 C76 40 92 56 92 88" stroke="{c}" stroke-width="16" fill="none" stroke-linecap="round"/><path d="M28 74 C40 60 52 72 60 58 C68 72 80 60 92 74" stroke="{c}" stroke-width="10" fill="none" stroke-linecap="round"/><circle cx="50" cy="52" r="4" fill="#0b0e16"/><circle cx="70" cy="52" r="4" fill="#0b0e16"/>`,
  manta:`<path d="M60 30 C86 42 104 62 96 76 C86 70 74 68 60 68 C46 68 34 70 24 76 C16 62 34 42 60 30 Z" fill="{c}"/><path d="M60 68 L54 96 L66 96 Z" fill="{c}"/><circle cx="50" cy="54" r="4" fill="#0b0e16"/><circle cx="70" cy="54" r="4" fill="#0b0e16"/>`,
  husk:`<path d="M60 26 C46 26 38 38 38 52 L38 96 L52 96 L52 74 L68 74 L68 96 L82 96 L82 52 C82 38 74 26 60 26 Z" fill="{c}"/><circle cx="52" cy="44" r="4" fill="#0b0e16"/><circle cx="68" cy="44" r="4" fill="#0b0e16"/>`,
  wyrm:`<path d="M34 92 C34 60 46 40 64 36 L88 28 L72 50 C84 58 86 76 74 88 C64 98 44 100 34 92 Z" fill="{c}"/><path d="M88 28 L96 20 M84 34 L96 34" stroke="{c}" stroke-width="6" stroke-linecap="round"/><circle cx="58" cy="54" r="4" fill="#0b0e16"/>`,
  beetle:`<ellipse cx="60" cy="66" rx="28" ry="32" fill="{c}"/><path d="M60 34 L60 98" stroke="#0b0e16" stroke-width="4"/><path d="M40 44 L28 34 M80 44 L92 34 M36 66 L22 66 M84 66 L98 66" stroke="{c}" stroke-width="6" stroke-linecap="round"/><circle cx="50" cy="50" r="3.5" fill="#0b0e16"/><circle cx="70" cy="50" r="3.5" fill="#0b0e16"/>`,
  toadstool:`<path d="M52 62 L68 62 L72 100 L48 100 Z" fill="{c}" opacity="0.85"/><path d="M24 62 C24 40 42 28 60 28 C78 28 96 40 96 62 Z" fill="{c}"/><circle cx="44" cy="48" r="6" fill="#0b0e16" opacity="0.5"/><circle cx="66" cy="42" r="5" fill="#0b0e16" opacity="0.5"/><circle cx="78" cy="54" r="4" fill="#0b0e16" opacity="0.5"/>`,
  spider:`<circle cx="60" cy="58" r="18" fill="{c}"/><path d="M46 50 L22 34 M46 62 L18 62 M46 74 L24 90 M74 50 L98 34 M74 62 L102 62 M74 74 L96 90" stroke="{c}" stroke-width="6" stroke-linecap="round"/><circle cx="54" cy="54" r="3" fill="#0b0e16"/><circle cx="66" cy="54" r="3" fill="#0b0e16"/>`,
  hound:`<path d="M36 96 L40 60 C40 44 52 34 66 36 L88 30 L82 52 C88 62 86 82 78 96 L66 96 L68 72 L52 72 L54 96 Z" fill="{c}"/><path d="M66 36 L70 22 L80 34" fill="{c}"/><circle cx="76" cy="42" r="3.5" fill="#0b0e16"/>`,
  boar:`<ellipse cx="60" cy="68" rx="32" ry="24" fill="{c}"/><path d="M84 56 L104 48 L98 64 L106 70 L86 72 Z" fill="{c}"/><circle cx="46" cy="60" r="4" fill="#0b0e16"/><path d="M36 76 L28 88 M52 82 L50 96" stroke="{c}" stroke-width="7" stroke-linecap="round"/>`,
};

for (const e of T.enemies) {
  const color = T.schools.find(s => s.id === e.school).color;
  const body = `
    <defs><radialGradient id="v" cx="50%" cy="42%" r="65%">
      <stop offset="0%" stop-color="${color}" stop-opacity="0.5"/>
      <stop offset="100%" stop-color="#10141d" stop-opacity="1"/></radialGradient></defs>
    <ellipse cx="60" cy="62" rx="56" ry="56" fill="url(#v)" stroke="#2a3245" stroke-width="3"/>
    ${shapes[e.shape].replaceAll("{c}", color)}
    <ellipse cx="60" cy="62" rx="56" ry="56" fill="none" stroke="#000" stroke-opacity="0.35" stroke-width="10"/>`;
  writeFileSync(`assets/enemies/${e.portrait.replace("assets/enemies/","")}`, svg(body, 120, 120));
}

// ── Gear slot icons ──
const gearIcons = {
  WEP:`<path d="M60 14 L66 60 L60 106 L54 60 Z" fill="{c}"/><path d="M38 46 L82 46 M46 78 L74 78" stroke="{c}" stroke-width="8" stroke-linecap="round"/>`,
  SHI:`<path d="M60 16 L96 30 L92 68 C88 88 74 98 60 104 C46 98 32 88 28 68 L24 30 Z" fill="{c}"/><path d="M60 32 L60 88 M40 52 L80 52" stroke="#10141d" stroke-width="6"/>`,
  TOM:`<path d="M28 24 L60 34 L92 24 L92 90 L60 100 L28 90 Z" fill="{c}"/><path d="M60 34 L60 100" stroke="#10141d" stroke-width="5"/>`,
  RIN:`<circle cx="60" cy="66" r="26" fill="none" stroke="{c}" stroke-width="10"/><circle cx="60" cy="30" r="10" fill="{c}"/>`,
  RUN:`<path d="M60 12 L94 40 L82 100 L38 100 L26 40 Z" fill="{c}"/><path d="M60 34 L60 80 M46 50 L74 66 M74 50 L46 66" stroke="#10141d" stroke-width="6" stroke-linecap="round"/>`,
  TRI:`<circle cx="60" cy="60" r="30" fill="{c}"/><circle cx="60" cy="60" r="16" fill="#10141d"/><path d="M60 30 L60 44 M60 76 L60 90 M30 60 L44 60 M76 60 L90 60" stroke="{c}" stroke-width="6"/>`,
};
for (const [code, body] of Object.entries(gearIcons)) {
  writeFileSync(`assets/icons/GS-ICO-GEAR-${code}.svg`, svg(body.replaceAll("{c}", "#c9a24b")));
}

// ── Ability/FX sprites per school: projectile, impact, aura, burst, chain ──
const fxKinds = {
  PRJ:`<circle cx="60" cy="60" r="16" fill="{c}"/><path d="M18 60 L44 60 M76 60 L102 60" stroke="{c}" stroke-width="8" stroke-linecap="round" opacity="0.7"/>`,
  IMP:`<path d="M60 20 L74 50 L104 60 L74 70 L60 100 L46 70 L16 60 L46 50 Z" fill="{c}"/>`,
  AUR:`<circle cx="60" cy="60" r="34" fill="none" stroke="{c}" stroke-width="8"/><circle cx="60" cy="60" r="14" fill="{c}" opacity="0.6"/>`,
  BST:`<path d="M60 14 L70 48 L106 60 L70 72 L60 106 L50 72 L14 60 L50 48 Z" fill="{c}" opacity="0.9"/><circle cx="60" cy="60" r="10" fill="#fff" opacity="0.8"/>`,
  CHN:`<path d="M14 44 L44 60 L30 74 L60 88 L54 60 L74 52 L46 30 Z" fill="{c}" opacity="0.85"/>`,
};
for (const s of T.schools) {
  const key = s.id.replace("school_", "").slice(0, 3).toUpperCase();
  for (const [kind, body] of Object.entries(fxKinds)) {
    writeFileSync(`assets/fx/GS-FX-${key}-${kind}.svg`, svg(body.replaceAll("{c}", s.color)));
  }
}
console.log(`portraits ${T.enemies.length}, gear icons 6, fx ${T.schools.length * Object.keys(fxKinds).length}`);
