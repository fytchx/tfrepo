// Tickforge save repository — the single data layer owning persistence.
// All reads and writes of player profile state go through this module.
(() => {
  const KEY = "tickforge.save.v2";

  const defaultEncounter = () => [
    { enemyId: "GS-ENM-PHY-1", baseHp: 100, multiplier: 1, rank: "Normal" },
    { enemyId: "GS-ENM-FIR-1", baseHp: 100, multiplier: 1, rank: "Elite" },
    { enemyId: "GS-ENM-LIG-1", baseHp: 100, multiplier: 1, rank: "Normal" },
    null,
    null,
  ];

  const defaultCampaign = () => ({
    started: false,
    classId: "templar",
    starterWeaponArchetype: "greathammer",
    level: 1,
    xp: 0,
    xpNext: 100,
    restedXp: 75,
    gold: 0,
    deaths: 0,
    wavesCleared: 0,
    bossesKilled: 0,
    autoAdvance: true,
    unlockedZone: 0,
    zoneIndex: 0,
    wave: 1,
    maxWaveByZone: { 0: 1 },
    bossReadyPct: 0,
    loadout: ["GS-ABL-TEM-01", "GS-ABL-TEM-02", null, null, null],
    unlockedAbilities: ["GS-ABL-TEM-01", "GS-ABL-TEM-02"],
    equipped: { weapon: null, armor: null, shield: null, tome: null, ring: null, rune: null, trinket: null },
    inventory: [],
    materials: {
      forged_scrap: 12,
      arcane_dust: 8,
      essence_shards: 2,
      cat_pyric: 0,
      cat_sanguine: 0,
      cat_voltaic: 0,
      cat_noxious: 0,
      cat_chrono: 0,
      cat_aegis: 0,
      cat_arcane: 0,
      cat_tempering: 0,
      cat_prism: 0,
      cat_nullifying: 0,
      cat_overclock: 0,
    },
    lootFilter: {
      minRarity: "Common",
      tags: [],
      minTagMatches: 1,
      keepMutators: true,
      keepTwoSockets: true,
      keepRunesTrinkets: true,
    },
    statsSummary: {
      itemsKept: 0,
      itemsSalvaged: 0,
      rareMaterials: 0,
    },
    lastDeathTip: null,
    lastOfflineSummary: null,
    lastActiveAt: Date.now(),
    seed: 20261122,
  });

  const defaults = () => ({
    version: 2,
    gameMode: "sandbox",     // "sandbox" | "campaign"
    level: 1, xp: 0, xpNext: 120, gold: 0, shards: 0,
    classId: "templar",
    loadout: ["GS-ABL-TEM-01", "GS-ABL-TEM-02", "GS-ABL-TEM-03", "GS-ABL-TEM-04", null],
    equipped: { weapon: null, armor: null, shield: null, tome: null, ring: null, rune: null, trinket: null },
    bag: [],
    materials: {},           // catalystId → count
    bonuses: {},             // stat → permanent total from attuned catalysts
    skillPoints: 0,
    skillNodes: {},          // nodeId → rank
    zoneIndex: 0, stage: 0,
    settings: { fx: true, feed: true },
    seed: 20261122,
    // Sandbox slice fields
    sandboxEncounter: defaultEncounter(),
    customSpells: [],
    customItems: [],
    statOverrides: null,     // null or { maxHp, attackDamage, spellPower, haste, critChance, armor, resourceRegen }
    botMode: "optimal",      // "optimal" | "casual" | "sloppy"
    buildSnapshot: null,     // Pinned Build A snapshot for Phase 3 A/B comparison
    // Idle Campaign mode state
    campaign: defaultCampaign(),
  });

  function mergeCampaign(raw) {
    const base = defaultCampaign();
    if (!raw || typeof raw !== "object") return base;
    const merged = Object.assign(base, raw);
    merged.equipped = Object.assign(defaultCampaign().equipped, raw.equipped || {});
    merged.materials = Object.assign(defaultCampaign().materials, raw.materials || {});
    merged.lootFilter = Object.assign(defaultCampaign().lootFilter, raw.lootFilter || {});
    merged.statsSummary = Object.assign(defaultCampaign().statsSummary, raw.statsSummary || {});
    merged.maxWaveByZone = Object.assign({ 0: 1 }, raw.maxWaveByZone || {});
    if (!Array.isArray(merged.inventory)) merged.inventory = [];
    if (!Array.isArray(merged.loadout) || merged.loadout.length !== 5) {
      merged.loadout = [0, 1, 2, 3, 4].map(i => (raw.loadout || [])[i] || null);
    }
    if (!Array.isArray(merged.unlockedAbilities)) merged.unlockedAbilities = [];
    if (!Array.isArray(merged.lootFilter.tags)) merged.lootFilter.tags = [];
    return merged;
  }

  class SaveRepository {
    constructor() { this.profile = this.load(); }
    load() {
      try {
        const raw = localStorage.getItem(KEY);
        if (raw) {
          const p = JSON.parse(raw);
          if (p.version === 2) {
            const base = defaults();
            const merged = Object.assign(base, p);
            merged.equipped = Object.assign(defaults().equipped, p.equipped || {});
            merged.settings = Object.assign(defaults().settings, p.settings || {});
            if (!["sandbox", "campaign"].includes(merged.gameMode)) merged.gameMode = "sandbox";
            if (!Array.isArray(merged.sandboxEncounter) || merged.sandboxEncounter.length !== 5) {
              merged.sandboxEncounter = defaultEncounter();
            }
            if (!Array.isArray(merged.customSpells)) merged.customSpells = [];
            if (!Array.isArray(merged.customItems)) merged.customItems = [];
            merged.campaign = mergeCampaign(p.campaign);
            return merged;
          }
        }
      } catch (e) { /* corrupted or blocked storage — fall through to defaults */ }
      return defaults();
    }
    save() {
      try {
        if (this.profile?.campaign) this.profile.campaign.lastActiveAt = Date.now();
        localStorage.setItem(KEY, JSON.stringify(this.profile));
      } catch (e) { /* private mode: play without persistence */ }
    }
    reset() {
      try { localStorage.removeItem(KEY); } catch (e) {}
      this.profile = defaults();
      this.save();
    }
    resetCampaign() {
      this.profile.campaign = defaultCampaign();
      this.save();
    }
    addXp(n) {
      const p = this.profile;
      p.xp += n;
      while (p.xp >= p.xpNext) {
        p.xp -= p.xpNext; p.level++; p.xpNext = Math.round(p.xpNext * 1.35);
        p.skillPoints = (p.skillPoints || 0) + 1; // 1 skill point per level
      }
      this.save();
    }
  }

  window.Tickforge = Object.assign(window.Tickforge || {}, {
    SaveRepository,
    defaultCampaignState: defaultCampaign,
    mergeCampaignState: mergeCampaign,
  });
})();
