// Tickforge UI — Combat & Build Sandbox + Idle Campaign Mode. Reads window.TFDATA.
(() => {
  const {
    Combat, SaveRepository, TickEngine, fmt, RANK_MODS, computeEncounterEnemy, runMonteCarlo,
    CAMPAIGN_RARITIES, RARITY_COLOR, FILTER_TAGS, STARTER_WEAPONS, CAMPAIGN_MUTATORS, MATERIALS_META,
    getCampaignZone, computeItemPowerScore, rollCampaignDrop, rollCampaignMaterials,
    evaluateLootFilter, salvageItemToMaterials, resolveItemLootDrop,
    upgradeItemRank, addRuneSocket, socketRuneIntoItem, rerollItemAffixes, applyCatalystToItem,
    buildCampaignWave, buildCampaignBoss, startCampaignCharacter,
    grantCampaignXp, applyCampfireDeathPenalty, buildCampaignCombatProfile, simulateOfflineHours,
    runCampaignMonteCarlo, compareCampaignCandidate,
  } = window.Tickforge;
  const D = window.TFDATA;
  const $ = (sel, el = document) => el.querySelector(sel);
  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  };
  const svgEl = (tag, attrs = {}) => {
    const n = document.createElementNS("http://www.w3.org/2000/svg", tag);
    for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, String(v));
    return n;
  };

  const SCHOOL_OPTIONS = [
    { id: "school_physical", label: "Physical", code: "PHY" },
    { id: "school_fire", label: "Fire", code: "FIR" },
    { id: "school_lightning", label: "Lightning", code: "LIG" },
    { id: "school_poison", label: "Poison", code: "POI" },
    { id: "school_bleed", label: "Bleed", code: "BLE" },
  ];

  const GEAR_ICONS = {
    weapon: "assets/icons/GS-ICO-GEAR-WEA.svg",
    armor: "assets/icons/GS-ICO-GEAR-SHI.svg",
    shield: "assets/icons/GS-ICO-GEAR-SHI.svg",
    tome: "assets/icons/GS-ICO-GEAR-TOM.svg",
    ring: "assets/icons/GS-ICO-GEAR-RIN.svg",
    rune: "assets/icons/GS-ICO-GEAR-RUN.svg",
    trinket: "assets/icons/GS-ICO-GEAR-TRI.svg",
  };

  const CLASS_PORTRAITS = {
    templar: "assets/icons/GS-ICO-GEAR-SHI.svg",
    warrior: "assets/icons/GS-ICO-GEAR-WEA.svg",
    elementalist: "assets/icons/GS-ICO-GEAR-TOM.svg",
    nightblade: "assets/icons/GS-ICO-GEAR-WEP.svg",
    monk: "assets/icons/GS-ICO-GEAR-RUN.svg",
  };

  const fmtClock = (ms) => {
    const totalSec = Math.max(0, Math.floor((ms || 0) / 1000));
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m}:${String(s).padStart(2, "0")}`;
  };

  const fxPath = (schoolId, fxCode) => {
    const code = (schoolId || "school_physical").replace("school_", "").slice(0, 3).toUpperCase();
    return `assets/fx/GS-FX-${code}-${fxCode || "IMP"}.svg`;
  };

  class UI {
    constructor() {
      this.repo = new SaveRepository();
      this.combat = null;
      this.boardEl = $("#board");
      this.feedEl = $("#feed");
      this.lootFeedEl = $("#lootFeed");
      this.activeTab = this.repo.profile.gameMode === "campaign" ? "campaign_home" : "encounter";
      this.selectedEnemySlot = 0;
      this.selectedHotbarSlot = 0;
      this.spellFilter = "all";
      this.spellSearch = "";
      this.itemFilter = "all";
      this.itemSearch = "";
      this.showNewSpellForm = false;
      this.showNewItemForm = false;
      this._lastSummaryKey = "";
      this._lastBuffKey = "";
      this._lastChartKey = "";
      this.mcResult = null;
      this.combatLogFilter = "all";
      this.combatLogEntries = [];
      this.lootEntries = [];
      this.sessionTracker = {
        startedAt: Date.now(),
        xp: 0,
        gold: 0,
        kills: 0,
        drops: 0,
      };

      // Campaign UI state
      this.onboardClassId = this.repo.profile.campaign?.classId || "templar";
      this.onboardWeaponId = this.repo.profile.campaign?.starterWeaponArchetype || "greathammer";
      this.campaignBossActive = false;
      this.campfireRemainingMs = 0;
      this.campfireTotalMs = 2000;
      this.campfireLastTs = 0;
      this.selectedForgeItemId = null;
      this.forgeMessage = null;
      this.campaignBagFilter = "all";
      this.filterPreviewResult = null;
      this.campMcTarget = "boss";
      this.campMcResult = null;
      this.campMcCompare = null;
      this.selectedCompareItemId = null;

      this.events = {
        fct: e => this.spawnFct(e),
        feed: (text, cls) => this.feed(text, cls),
        loot: e => this.onLootEvent(e),
        fx: (key, o) => this.spawnFx(key, o),
        projectile: p => this.spawnProjectile(p),
        enemySwing: o => this.flashEnemy(o?.enemy?.slotIndex, "swing-flash", 220),
        pulse: id => this.pulseSlot(id),
        death: () => { this.shake("light"); this.sessionTracker.kills++; },
        waveEnd: () => this.onFightEnd("victory"),
        playerDown: () => this.onFightEnd("defeat"),
      };

      this.buildShell();
      this.bindKeyboardShortcuts();
      this.newFight(false);
      this.renderActiveTab();
      this.frame();
    }

    isCampaignMode() {
      return this.repo.profile.gameMode === "campaign";
    }

    bindKeyboardShortcuts() {
      window.addEventListener("keydown", (e) => {
        const tag = (document.activeElement?.tagName || "").toUpperCase();
        if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
        const modalOpen = !$("#modalBackdrop")?.hidden;
        if (e.key === "Escape" && modalOpen) {
          this.closeModal();
          return;
        }
        if (modalOpen) return;

        if (e.code === "Space") {
          e.preventDefault();
          $("#btnPlayPause")?.click();
        } else if (e.key === "ArrowRight") {
          e.preventDefault();
          $("#btnStep")?.click();
        } else if (e.key === "r" || e.key === "R") {
          if (!e.ctrlKey && !e.metaKey && !e.altKey) {
            e.preventDefault();
            $("#btnResetFight")?.click();
          }
        } else if (["1", "2", "3", "4", "5"].includes(e.key)) {
          const idx = Number(e.key) - 1;
          this.selectedHotbarSlot = idx;
          this.refreshHeaderAndHotbar();
          if (this.activeTab === "spells" || this.activeTab === "campaign_home") this.renderActiveTab();
        }
      });
    }

    allSpells() {
      return [...(this.repo.profile.customSpells || []), ...(D.abilities || [])];
    }

    allItems() {
      return [...(this.repo.profile.customItems || []), ...(D.equipment || [])];
    }

    buildShell() {
      const p = this.repo.profile;
      const clsSelect = $("#classSelect");
      clsSelect.replaceChildren();
      for (const c of D.classes) {
        const opt = el("option", null, `${c.name} (${c.hero})`);
        opt.value = c.id;
        if (c.id === (p.classId || "templar")) opt.selected = true;
        clsSelect.appendChild(opt);
      }
      clsSelect.onchange = () => {
        const c = D.classes.find(x => x.id === clsSelect.value);
        if (!c) return;
        p.classId = c.id;
        p.loadout = [0, 1, 2, 3, 4].map(i => c.loadout[i] || null);
        this.repo.save();
        this.refreshHeaderAndHotbar();
        this.newFight(false);
        this.renderActiveTab();
      };

      $("#btnModeSandbox").onclick = () => this.switchGameMode("sandbox");
      $("#btnModeCampaign").onclick = () => this.switchGameMode("campaign");

      $("#botModeSelect").value = p.botMode || "optimal";
      $("#botModeSelect").onchange = () => {
        p.botMode = $("#botModeSelect").value;
        this.repo.save();
        this.newFight(false);
      };

      $("#btnPlayPause").onclick = () => {
        if (this.isCampaignMode() && !this.repo.profile.campaign?.started) return;
        if (this.campfireRemainingMs > 0) return;
        if (!this.combat || !this.combat.state.enemies.length) return;
        if (this.combat.state.result) {
          this.newFight(false);
          this.engine.resume();
        } else {
          this.engine.togglePause();
        }
        this.syncPlaybackButtons();
      };

      $("#btnStep").onclick = () => {
        if (this.isCampaignMode() && !this.repo.profile.campaign?.started) return;
        if (this.campfireRemainingMs > 0) return;
        if (!this.combat || !this.combat.state.enemies.length) return;
        if (this.combat.state.result) this.newFight(false);
        this.engine.step();
        this.syncPlaybackButtons();
        this.updateSummary(true);
      };

      $("#btnResetFight").onclick = () => {
        if (this.isCampaignMode() && !this.repo.profile.campaign?.started) return;
        this.campfireRemainingMs = 0;
        const wasPaused = this.engine?.paused;
        this.newFight(false);
        if (wasPaused) this.engine.pause();
        else this.engine.resume();
        this.syncPlaybackButtons();
      };

      for (const btn of document.querySelectorAll(".speed-btn")) {
        btn.onclick = () => {
          const sp = Number(btn.dataset.speed) || 1;
          this.engine.setSpeed(sp);
          for (const b of document.querySelectorAll(".speed-btn")) {
            b.classList.toggle("active", Number(b.dataset.speed) === sp);
          }
        };
      }

      $("#btnInstantSim").onclick = () => this.runInstantSim();
      $("#btnClearLog").onclick = () => {
        this.combatLogEntries = [];
        this.renderCombatFeed();
      };
      const logFilter = $("#combatLogFilter");
      if (logFilter) {
        logFilter.value = this.combatLogFilter;
        logFilter.onchange = () => {
          this.combatLogFilter = logFilter.value || "all";
          this.renderCombatFeed();
        };
      }
      $("#btnBuildJson").onclick = () => this.openJsonModal();
      $("#btnSettings").onclick = () => this.openSettingsModal();
      $("#modalBackdrop").onclick = (e) => {
        if (e.target === $("#modalBackdrop")) this.closeModal();
      };

      // Campaign HUD Controls
      $("#campZoneSelect").onchange = () => {
        const c = this.repo.profile.campaign;
        const nextIdx = Math.max(0, Math.min(c.unlockedZone || 0, Number($("#campZoneSelect").value) || 0));
        c.zoneIndex = nextIdx;
        c.wave = Math.max(1, c.maxWaveByZone?.[nextIdx] || 1);
        c.bossReadyPct = 0;
        this.campaignBossActive = false;
        this.campfireRemainingMs = 0;
        this.repo.save();
        this.newFight(false);
        this.renderActiveTab();
      };

      $("#chkAutoAdvance").onchange = () => {
        this.repo.profile.campaign.autoAdvance = $("#chkAutoAdvance").checked;
        this.repo.save();
      };

      $("#btnChallengeBoss").onclick = () => {
        const c = this.repo.profile.campaign;
        if (!c.started || (c.bossReadyPct || 0) < 100 || this.campfireRemainingMs > 0) return;
        this.campaignBossActive = true;
        this.newFight(false);
        this.engine?.resume();
        this.syncPlaybackButtons();
        this.feed(`Challenged ${getCampaignZone(c.zoneIndex).bossName}! Watch for Telegraphed Heavy Casts & 60s Enrage.`, "system");
      };

      $("#btnSimBossHud").onclick = () => {
        const c = this.repo.profile.campaign;
        if (!c.started) return;
        this.campMcTarget = "boss";
        this.campMcResult = runCampaignMonteCarlo(D, c, { target: "boss", runs: 50 });
        this.campMcCompare = null;
        this.switchTab("campaign_mc");
        this.feed(
          `Boss Sim (50 runs vs ${getCampaignZone(c.zoneIndex).bossName}): ${this.campMcResult.verdict} — ${this.campMcResult.winRatePct}% Win, ${fmt(this.campMcResult.p50Dps)}/s Median DPS.`,
          "system"
        );
      };

      for (const b of document.querySelectorAll(".camp-afk-btn")) {
        b.onclick = () => {
          const hrs = Number(b.dataset.afkHours) || 1;
          this.runCampaignOfflineSim(hrs);
        };
      }

      $("#btnDismissBossTip").onclick = () => {
        this.repo.profile.campaign.lastDeathTip = null;
        this.repo.save();
        this.refreshCampaignHud();
      };

      this.syncModeUI();
      this.rebuildNavTabs();
      this.refreshHeaderAndHotbar();
    }

    switchGameMode(mode) {
      if (this.repo.profile.gameMode === mode) return;
      this.repo.profile.gameMode = mode;
      this.campaignBossActive = false;
      this.campfireRemainingMs = 0;
      this.activeTab = mode === "campaign" ? "campaign_home" : "encounter";
      this.repo.save();
      this.syncModeUI();
      this.rebuildNavTabs();
      this.refreshHeaderAndHotbar();
      this.newFight(false);
      this.renderActiveTab();
    }

    syncModeUI() {
      const campMode = this.isCampaignMode();
      $("#btnModeSandbox").classList.toggle("active", !campMode);
      $("#btnModeCampaign").classList.toggle("active", campMode);
      $("#classFieldWrap").hidden = campMode;
      $("#botModeWrap").hidden = campMode;
      $("#btnInstantSim").hidden = campMode;
      $("#campaignHudCard").hidden = !campMode || !this.repo.profile.campaign?.started;
      $("#btnResetFight").textContent = campMode ? "Reset Wave" : "Reset Fight";
      this.refreshModeStatusStrip();
    }

    refreshModeStatusStrip() {
      const strip = $("#modeStatusStrip");
      if (!strip) return;
      if (!this.isCampaignMode()) {
        strip.textContent = "Sandbox Tuning · 1–5 Custom Enemies · Live Stat Editor";
        return;
      }
      const c = this.repo.profile.campaign;
      if (!c.started) {
        strip.textContent = "Idle Campaign · Pick Class & Starter Weapon to begin Zone 1: Gallowsfen";
        return;
      }
      const z = getCampaignZone(c.zoneIndex);
      strip.textContent = `${z.shortName} · Wave ${c.wave} · ${fmt(c.gold)} Gold · ${c.deaths} Deaths`;
    }

    rebuildNavTabs() {
      const nav = $("#nav");
      nav.replaceChildren();
      const tabs = this.isCampaignMode()
        ? [
            ["campaign_home", "Campaign"],
            ["campaign_gear", "Gear & Forge"],
            ["campaign_mc", "Monte Carlo"],
            ["campaign_filter", "Loot Filter"],
            ["campaign_stats", "Stats & Mutators"],
          ]
        : [
            ["encounter", "Encounter"],
            ["spells", "Spells & Hotbar"],
            ["items", "Items & Gear"],
            ["stats", "Live Stats"],
            ["theorycraft", "Theorycraft"],
          ];
      if (!tabs.some(t => t[0] === this.activeTab)) this.activeTab = tabs[0][0];
      for (const [id, label] of tabs) {
        const b = el("button", id === this.activeTab ? "active" : null, label);
        b.type = "button";
        b.dataset.tab = id;
        b.onclick = () => this.switchTab(id);
        nav.appendChild(b);
      }
    }

    switchTab(id) {
      this.activeTab = id;
      for (const b of $("#nav").children) {
        b.classList.toggle("active", b.dataset.tab === id);
      }
      this.renderActiveTab();
    }

    refreshHeaderAndHotbar() {
      const p = this.repo.profile;
      const campMode = this.isCampaignMode();
      const c = p.campaign;
      const clsId = campMode ? (c.classId || "templar") : (p.classId || "templar");
      const cls = D.classes.find(x => x.id === clsId) || D.classes[0];
      const activeLoadout = campMode ? (c.loadout || []) : (p.loadout || []);

      const porImg = $("#charPortraitImg");
      if (porImg) {
        porImg.src = CLASS_PORTRAITS[cls.id] || "assets/icons/GS-ICO-GEAR-SHI.svg";
        porImg.alt = cls.name;
      }

      $("#charName").textContent = (cls.hero || cls.name).toUpperCase();
      const classSub = $("#charClassSub");
      if (classSub) {
        classSub.textContent = cls.name;
        classSub.style.color = cls.color || "#a8c9a2";
      }

      const lv = campMode ? (c.level || 1) : (p.level || 1);
      const xp = campMode ? (c.xp || 0) : (p.xp || 0);
      const xpNext = Math.max(1, campMode ? (c.xpNext || 100) : (p.xpNext || 120));
      const xpPct = Math.min(100, Math.round((xp / xpNext) * 100));

      const hedLv = $("#hedLevelBadge");
      if (hedLv) hedLv.textContent = `LV. ${lv}`;
      const hedXpFill = $("#hedXpFill");
      if (hedXpFill) hedXpFill.style.width = `${xpPct}%`;
      const hedXpPct = $("#hedXpPct");
      if (hedXpPct) hedXpPct.textContent = `${xpPct}%`;

      if (campMode) {
        const z = getCampaignZone(c.zoneIndex);
        $("#charLevel").textContent = c.started
          ? `${z.shortName} W${c.wave} · ${cls.resource.label}`
          : "New Campaign Setup";
      } else {
        $("#charLevel").textContent = `Sandbox · ${cls.resource.label}`;
      }

      const plaque = $("#arenaZonePlaque");
      if (plaque) {
        if (campMode) {
          const z = getCampaignZone(c.zoneIndex);
          plaque.innerHTML = "";
          plaque.append(
            el("strong", null, z.shortName.toUpperCase()),
            el("span", null, this.campaignBossActive ? `Boss: ${z.bossName}` : `Wave ${c.wave}`)
          );
        } else {
          const cnt = (p.sandboxEncounter || []).filter(Boolean).length;
          plaque.innerHTML = "";
          plaque.append(
            el("strong", null, "SANDBOX ARENA"),
            el("span", null, `${cnt} ${cnt === 1 ? "Enemy" : "Enemies"}`)
          );
        }
      }

      const hot = $("#hotbar");
      hot.replaceChildren();
      const spells = this.allSpells();
      for (let i = 0; i < 5; i++) {
        const slot = el("div", "GS-UI-SKL-slot" + (i === this.selectedHotbarSlot ? " selected-hotbar" : ""));
        slot.appendChild(el("span", "key", String(i + 1)));
        const abId = activeLoadout[i];
        const ab = abId ? spells.find(a => a.id === abId) : null;
        if (ab) {
          const img = el("img");
          img.src = fxPath(ab.school, ab.fx);
          img.alt = ab.name;
          slot.appendChild(img);
          slot.title = `Slot ${i + 1}: ${ab.name} — ${ab.description || ""}`;
        } else {
          slot.classList.add("disabled");
          slot.appendChild(el("span", "empty-key", "—"));
          slot.title = `Slot ${i + 1}: Empty (click to assign spell)`;
        }
        slot.append(el("div", "cd"), el("div", "gcd"));
        slot.onclick = () => {
          this.selectedHotbarSlot = i;
          this.refreshHeaderAndHotbar();
          if (campMode) {
            if (this.activeTab !== "campaign_home") this.switchTab("campaign_home");
            else this.renderActiveTab();
          } else {
            if (this.activeTab !== "spells") this.switchTab("spells");
            else this.renderActiveTab();
          }
        };
        hot.appendChild(slot);
      }

      const mpFill = $("#mpFill");
      if (mpFill) {
        const rc = cls.resource.color || "#3a8dff";
        mpFill.style.background = `linear-gradient(90deg, #101d38 0%, ${rc} 52%, #132240 100%)`;
      }
      document.documentElement.style.setProperty("--tf-class", cls.resource.color);
      const pips = $("#pips");
      if (pips) pips.style.display = cls.resource.type === "holy_power" ? "" : "none";
      this.refreshCampaignHud();
      this.refreshModeStatusStrip();
    }

    refreshCampaignHud() {
      const card = $("#campaignHudCard");
      if (!card) return;
      const c = this.repo.profile.campaign;
      const show = this.isCampaignMode() && c.started;
      card.hidden = !show;
      if (!show) return;

      const z = getCampaignZone(c.zoneIndex);
      $("#campZoneLabel").textContent = z.name;
      $("#campWaveLabel").textContent = this.campaignBossActive ? `Boss: ${z.bossName}` : `Wave ${c.wave}`;
      $("#campHudMeta").textContent = `${fmt(c.gold)} Gold · ${c.deaths} Deaths · ${c.wavesCleared} Waves`;

      const xpPct = Math.min(100, Math.round((c.xp / Math.max(1, c.xpNext)) * 100));
      const maxRested = Math.round(c.xpNext * 1.5);
      const restedCapBar = Math.min(100, Math.round(((c.xp + (c.restedXp || 0)) / Math.max(1, c.xpNext)) * 100));
      $("#campLevelText").textContent = `Lv ${c.level} · ${fmt(c.xp)} / ${fmt(c.xpNext)} XP`;
      $("#campRestedText").textContent = c.restedXp > 0
        ? `Rested: ${fmt(c.restedXp)} / ${fmt(maxRested)} (2.0× XP active)`
        : `Rested: 0 / ${fmt(maxRested)} (1.0× XP)`;
      $("#campXpFill").style.width = `${xpPct}%`;
      $("#campRestedFill").style.width = `${restedCapBar}%`;

      // Zone Selector options (0 .. unlockedZone)
      const zSel = $("#campZoneSelect");
      const maxZ = Math.max(0, c.unlockedZone || 0);
      if (zSel.options.length !== maxZ + 1 || Number(zSel.value) !== c.zoneIndex) {
        zSel.replaceChildren();
        for (let zi = 0; zi <= maxZ; zi++) {
          const zn = getCampaignZone(zi);
          const opt = el("option", null, zn.name);
          opt.value = String(zi);
          if (zi === c.zoneIndex) opt.selected = true;
          zSel.appendChild(opt);
        }
      }
      $("#chkAutoAdvance").checked = c.autoAdvance !== false;

      const ready = Math.min(100, Math.round(c.bossReadyPct || 0));
      $("#campBossReadyFill").style.width = `${ready}%`;
      $("#campBossReadyText").textContent = this.campaignBossActive ? "BOSS ACTIVE" : `Boss ${ready}%`;
      const bossBtn = $("#btnChallengeBoss");
      bossBtn.disabled = ready < 100 || this.campaignBossActive || this.campfireRemainingMs > 0;
      bossBtn.textContent = this.campaignBossActive ? "Boss Engaged" : "Challenge Zone Boss";

      // Campfire Banner
      const campBanner = $("#campfireBanner");
      if (this.campfireRemainingMs > 0) {
        campBanner.hidden = false;
        const pct = Math.max(0, Math.min(100, 100 - (this.campfireRemainingMs / this.campfireTotalMs) * 100));
        $("#campfireCountdown").textContent = `${(this.campfireRemainingMs / 1000).toFixed(1)}s`;
        $("#campfireFill").style.width = `${pct}%`;
        $("#campfireSub").textContent = `Resting at Campfire · Auto-resuming Wave ${c.wave} at 100% HP & Resource`;
      } else {
        campBanner.hidden = true;
      }

      // Boss Death Tip
      const tipBanner = $("#bossTipBanner");
      if (c.lastDeathTip) {
        tipBanner.hidden = false;
        $("#bossTipText").textContent = `Boss Tip: ${c.lastDeathTip}`;
      } else {
        tipBanner.hidden = true;
      }

      // Offline Summary Card
      this.renderOfflineSummaryCard();
    }

    renderOfflineSummaryCard() {
      const wrap = $("#offlineSummaryWrap");
      if (!wrap) return;
      const sum = this.repo.profile.campaign?.lastOfflineSummary;
      if (!sum) {
        wrap.hidden = true;
        wrap.replaceChildren();
        return;
      }
      wrap.hidden = false;
      wrap.replaceChildren();
      const head = el("div", "offline-summary-head");
      head.appendChild(el("strong", null, `Offline Summary (+${sum.hours} Hr${sum.hours > 1 ? "s" : ""} AFK in ${sum.zoneName})`));
      const closeBtn = el("button", "tf-link-btn", "Dismiss");
      closeBtn.type = "button";
      closeBtn.onclick = () => {
        this.repo.profile.campaign.lastOfflineSummary = null;
        this.repo.save();
        this.renderOfflineSummaryCard();
      };
      head.appendChild(closeBtn);
      wrap.appendChild(head);

      const grid = el("div", "offline-summary-grid");
      const addStat = (k, v) => {
        const box = el("div", "offline-stat");
        box.append(el("span", null, k), el("b", null, v));
        grid.appendChild(box);
      };
      addStat("Time Elapsed", `${sum.hours} Hr${sum.hours > 1 ? "s" : ""}`);
      addStat("Waves Cleared", fmt(sum.wavesCleared));
      addStat("Total Deaths", fmt(sum.deaths));
      addStat("Levels Gained", `+${sum.levelsGained} (Lv ${sum.endLevel})`);
      addStat("Rested XP Used", fmt(sum.restedXpUsed));
      addStat("Items Kept", fmt(sum.itemsKept));
      addStat("Auto-Salvaged", fmt(sum.itemsSalvaged));
      const rareCount = Object.values(sum.rareMaterialsFound || {}).reduce((a, b) => a + b, 0);
      addStat("Rare Catalysts", fmt(rareCount));
      wrap.appendChild(grid);

      const scrap = sum.materialsGained || {};
      const detail = el("div", "campfire-sub",
        `Earned ${fmt(sum.goldGained)} Gold, ${fmt(sum.xpGained)} XP, +${scrap.forged_scrap || 0} Scrap, +${scrap.arcane_dust || 0} Dust, +${scrap.essence_shards || 0} Shards.`
      );
      wrap.appendChild(detail);
    }

    runCampaignOfflineSim(hours) {
      const c = this.repo.profile.campaign;
      if (!c.started) return;
      const summary = simulateOfflineHours(D, c, hours);
      this.campfireRemainingMs = 0;
      this.campaignBossActive = false;
      this.repo.save();
      this.refreshHeaderAndHotbar();
      this.newFight(false);
      this.engine?.resume();
      this.renderActiveTab();
      this.feed(
        `Simulated +${hours}h AFK: ${summary.wavesCleared} waves cleared, ${summary.deaths} deaths, +${summary.levelsGained} levels, ${summary.itemsKept} kept / ${summary.itemsSalvaged} salvaged.`,
        "loot"
      );
    }

    newFight(save = true) {
      if (save) this.repo.save();
      if (!this.isCampaignMode()) {
        this.combatLogEntries = [];
        this.renderCombatFeed();
      }
      this._lastSummaryKey = "";
      this._lastBuffKey = "";
      this._lastChartKey = "";
      this.mcResult = null;
      this.campMcResult = null;
      this.campMcCompare = null;

      const skyStops = $("#arenaSky")?.querySelectorAll("stop");

      if (this.isCampaignMode()) {
        const c = this.repo.profile.campaign;
        if (!c.started) {
          this.combat = null;
          if (this.engine) this.engine.pause();
          this.boardEl.style.background = "";
          this.renderEnemies();
          this.syncPlaybackButtons();
          return;
        }
        c.seed = ((c.seed || 20261122) + 97) >>> 0;
        let a = c.seed >>> 0;
        const rnd = () => {
          a |= 0; a = (a + 0x6D2B79F5) | 0;
          let t = Math.imul(a ^ (a >>> 15), 1 | a);
          t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
          return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
        const simProfile = buildCampaignCombatProfile(c, this.campaignBossActive);
        const pack = this.campaignBossActive
          ? buildCampaignBoss(D, c.zoneIndex, c.wave)
          : buildCampaignWave(D, c.zoneIndex, c.wave, rnd);
        simProfile.prebuiltWave = pack;
        const z = pack.zone;
        if (skyStops && skyStops.length >= 3) {
          skyStops[0].setAttribute("stop-color", z.bg || "#0d2626");
          skyStops[1].setAttribute("stop-color", z.bgGlow || "#1e3d31");
          skyStops[2].setAttribute("stop-color", "#090c08");
        }
        this.combat = new Combat(D, simProfile, this.events);
      } else {
        if (skyStops && skyStops.length >= 3) {
          skyStops[0].setAttribute("stop-color", "#0d2626");
          skyStops[1].setAttribute("stop-color", "#1e3d31");
          skyStops[2].setAttribute("stop-color", "#0b120d");
        }
        this.combat = new Combat(D, this.repo.profile, this.events);
      }

      if (this.engine) {
        this.engine.combat = this.combat;
      } else {
        this.engine = new TickEngine(this.combat, () => {}, () => this.onTick());
        this.engine.start();
      }
      if (!this.combat.state.enemies.length) this.engine.pause();
      else if (this.isCampaignMode() && this.campfireRemainingMs <= 0) this.engine.resume();
      this.refreshHeaderAndHotbar();
      this.renderEnemies();
      this.updateBuffsBar();
      this.syncPlaybackButtons();
      this.updateSummary(true);
      this.refreshCampaignHud();
      this.refreshModeStatusStrip();
    }

    onTick() {
      this.updateSummary(false);
    }

    onFightEnd(outcome) {
      if (this.isCampaignMode()) {
        if (outcome === "victory") this.onCampaignWaveVictory();
        else this.onCampaignPlayerDown();
        return;
      }
      if (this.engine) this.engine.pause();
      this.syncPlaybackButtons();
      this.updateSummary(true);
    }

    onCampaignWaveVictory() {
      const c = this.repo.profile.campaign;
      if (!c.started || !this.combat) return;
      const s = this.combat.state;
      let a = ((c.seed || 20261122) + s.elapsedMs + 313) >>> 0;
      const rnd = () => {
        a |= 0; a = (a + 0x6D2B79F5) | 0;
        let t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
      };
      c.seed = a;

      let totalXp = 0, totalBonus = 0, totalGold = 0, hasChamp = false;
      const wasBoss = this.campaignBossActive;

      for (const en of (s.initialEnemies || s.enemies || [])) {
        const xpRes = grantCampaignXp(c, D, en.xpReward || 24);
        totalXp += xpRes.gained;
        totalBonus += xpRes.bonusUsed;
        const g = en.goldReward || 12;
        c.gold = (c.gold || 0) + g;
        totalGold += g;
        if (en.isChampion) hasChamp = true;
        if (xpRes.levelsGained > 0) {
          this.feed(`LEVEL UP! Reached Lv ${c.level}!${xpRes.unlockedNames.length ? ` Unlocked: ${xpRes.unlockedNames.join(", ")}` : ""}`, "loot");
        }

        const dropChance = wasBoss ? 1.0 : en.isChampion ? 0.70 : 0.26;
        if (rnd() < dropChance) {
          const drop = rollCampaignDrop(c.zoneIndex, c.wave, wasBoss, en.isChampion, rnd);
          resolveItemLootDrop(
            c,
            drop,
            (it, reason) => {
              this.sessionTracker.drops++;
              this.addLootEntry(it.name, RARITY_COLOR[it.rarity] || "#f2d34a", s.elapsedMs);
              this.feed(`Loot Kept [${it.rarity}]: ${it.name} (${reason})`, "loot");
            },
            (it, mats, reason) => {
              this.sessionTracker.drops++;
              this.addLootEntry(`${it.name} → +${mats.forged_scrap} Scrap`, "#9a9a9a", s.elapsedMs);
              this.feed(`Auto-Salvaged ${it.name} (${reason}) → +${mats.forged_scrap} Scrap, +${mats.arcane_dust} Dust`, "system");
            }
          );
        }

        const rareMats = rollCampaignMaterials(wasBoss, en.isChampion, rnd);
        for (const mId of rareMats) {
          c.materials[mId] = (c.materials[mId] || 0) + 1;
          c.statsSummary.rareMaterials = (c.statsSummary.rareMaterials || 0) + 1;
          this.sessionTracker.drops++;
          const mName = MATERIALS_META[mId]?.name || mId;
          this.addLootEntry(mName, "#e08a4c", s.elapsedMs);
          this.feed(`Rare Drop: ${mName}!`, "loot");
        }
      }
      if (totalGold > 0) {
        this.sessionTracker.gold += totalGold;
        this.addLootEntry(`+${totalGold} gold`, "#e7c35c", s.elapsedMs);
      }
      if (totalXp > 0) this.sessionTracker.xp += totalXp;

      if (wasBoss) {
        c.bossesKilled = (c.bossesKilled || 0) + 1;
        c.bossReadyPct = 0;
        this.campaignBossActive = false;
        const nextZoneIdx = c.zoneIndex + 1;
        if (nextZoneIdx > (c.unlockedZone || 0)) {
          c.unlockedZone = nextZoneIdx;
          c.maxWaveByZone[nextZoneIdx] = 1;
          const nextZone = getCampaignZone(nextZoneIdx);
          this.feed(`ZONE BOSS SLAIN! Unlocked ${nextZone.name} (${nextZone.hpMult}× HP, ${nextZone.dmgMult}× DMG)! Use the Zone Selector when ready.`, "loot");
        } else {
          this.feed(`Zone Boss Defeated! +${fmt(totalXp)} XP, +${fmt(totalGold)} Gold.`, "loot");
        }
      } else {
        c.wavesCleared = (c.wavesCleared || 0) + 1;
        c.bossReadyPct = Math.min(100, (c.bossReadyPct || 0) + (hasChamp ? 35 : 20));
        if (c.autoAdvance !== false) {
          c.wave = (c.wave || 1) + 1;
          c.maxWaveByZone[c.zoneIndex] = Math.max(c.maxWaveByZone[c.zoneIndex] || 1, c.wave);
        }
        this.feed(
          `Wave cleared: +${fmt(totalXp)} XP${totalBonus > 0 ? ` (${fmt(totalBonus)} Rested)` : ""}, +${fmt(totalGold)} Gold.`,
          "resource"
        );
      }

      this.repo.save();
      this.refreshHeaderAndHotbar();
      this.newFight(false);
      // Immediately execute Tick 1 of the next wave
      if (this.combat && !this.combat.state.result) {
        this.combat.tick();
        this.engine?.resume();
      }
      if (["campaign_home", "campaign_gear", "campaign_stats"].includes(this.activeTab)) {
        this.renderActiveTab();
      }
    }

    onCampaignPlayerDown() {
      const c = this.repo.profile.campaign;
      if (!c.started) return;
      const wasBoss = this.campaignBossActive;
      const cause = this.combat?.state?.lastFatalCause;
      const lostRested = applyCampfireDeathPenalty(c, wasBoss);

      if (wasBoss) {
        const z = getCampaignZone(c.zoneIndex);
        if (cause?.wasEnraged) {
          c.lastDeathTip = `${z.bossName} enraged after 60s (+150% DMG). Upgrade weapon/gear ranks or socket Runes for higher DPS before retrying.`;
        } else if (cause?.isTelegraph) {
          c.lastDeathTip = `Slain by ${cause.castName || "Heavy Cast"}. Slot an Interrupt (Rebuke, Tempest Kick, or Shadow Veil) or break Posture faster during the 2.8s warning.`;
        } else if ((cause?.resPct || 0) < 0.15 && cause?.school !== "school_physical") {
          const sName = String(cause.school || "").replace("school_", "");
          c.lastDeathTip = `Low ${sName} resistance (${Math.round((cause.resPct || 0) * 100)}%). Roll ${sName} Resistance/Armor gear or infuse Aegis Catalysts before retrying ${z.bossName}.`;
        } else {
          c.lastDeathTip = `${z.bossName} overwhelmed your defenses. Farm Wave ${c.wave} for Rare+ drops, upgrade gear at the Forge, and retry when stronger.`;
        }
      }

      this.campaignBossActive = false;
      this.campfireTotalMs = 2000;
      this.campfireRemainingMs = 2000;
      this.campfireLastTs = performance.now();
      if (this.engine) this.engine.pause();
      this.repo.save();

      this.feed(
        `Slain — Recovering at Campfire (2.0s)... Lost ${lostRested} Rested XP (5%). Stepping back to Wave ${c.wave}.`,
        "system"
      );
      this.refreshHeaderAndHotbar();
      this.syncPlaybackButtons();
      this.updateSummary(true);
      if (this.activeTab === "campaign_stats" || this.activeTab === "campaign_home") {
        this.renderActiveTab();
      }
    }

    syncPlaybackButtons() {
      const btn = $("#btnPlayPause");
      const hasEnemies = this.combat && this.combat.state.enemies.length > 0;
      const recovering = this.campfireRemainingMs > 0;
      btn.disabled = !hasEnemies || recovering;
      $("#btnStep").disabled = !hasEnemies || recovering;
      $("#btnInstantSim").disabled = !hasEnemies;
      if (recovering) {
        btn.textContent = "Campfire...";
        return;
      }
      if (!hasEnemies) {
        btn.textContent = "Start";
        return;
      }
      if (this.combat.state.result) {
        btn.textContent = "Restart";
      } else {
        btn.textContent = this.engine?.paused ? "Start" : "Pause";
      }
    }

    runInstantSim() {
      const p = this.repo.profile;
      const hasAny = (p.sandboxEncounter || []).some(Boolean);
      if (!hasAny) return;
      this.combatLogEntries = [];
      this.renderCombatFeed();
      const bufferedLog = [];
      const simEvents = {
        fct() {},
        fx() {},
        projectile() {},
        enemySwing() {},
        pulse() {},
        death() {},
        waveEnd() {},
        playerDown() {},
        feed: (text, cls) => bufferedLog.push([text, cls]),
      };
      const c = new Combat(D, p, simEvents);
      for (let t = 0; t < 6000 && !c.state.result; t++) c.tick();
      if (!c.state.result) {
        c.state.result = "timeout";
        c.state.ttkMs = c.state.elapsedMs;
        bufferedLog.push([`[${(c.state.elapsedMs / 1000).toFixed(1)}s] Sim reached 600.0s cap.`, "system"]);
      }

      // Wire real events back so subsequent stepping/UI reads work cleanly
      c.events = this.events;
      this.combat = c;
      this.engine.combat = c;
      this.engine.pause();
      this._lastBuffKey = "";
      this.renderEnemies();
      this.updateBuffsBar();
      for (const [text, cls] of bufferedLog.slice(-120)) this.feed(text, cls);
      this.syncPlaybackButtons();
      this.updateSummary(true);
    }

    renderEnemies() {
      const row = $("#enemyRow");
      row.replaceChildren();
      const slots = this.combat?.state?.boardSlots || [null, null, null, null, null];
      const hasMultiBoss = !!slots[1]?.isCampaignBoss;
      for (let i = 0; i < 5; i++) {
        if (hasMultiBoss && (i === 2 || i === 3)) continue;
        const en = slots[i];
        const card = el("div", "GS-UI-BOARD-enemy"
          + (en?.isCampaignBoss ? " boss-multi" : "")
          + (!this.isCampaignMode() && i === this.selectedEnemySlot ? " selected-slot" : ""));
        card.dataset.slot = String(en ? en.slotIndex : i);
        if (!en) {
          const empty = el("div", "enemy-empty-slot");
          empty.append(el("b", null, this.isCampaignMode() ? "·" : "+"), el("span", null, `Slot ${i}`));
          card.append(empty, el("div", "name", "Empty"));
        } else {
          card.dataset.uid = String(en.uid);
          if (en.dead) card.classList.add("dead");
          const stage = el("div", "portrait-stage");
          stage.appendChild(el("span", "slot-idx-badge", en.isCampaignBoss ? "1–3" : String(i)));
          const por = el("img", "en-por");
          por.src = en.portrait;
          por.alt = en.name;
          const frm = el("img", "en-frame");
          frm.src = en.frame || RANK_MODS.Normal.frame;
          frm.alt = "";
          const rankLabel = en.isCampaignBoss ? "Boss" : (en.archetype && en.archetype !== "Normal" ? en.archetype : (en.rank || "Normal"));
          const badge = el("span", `rank-badge ${en.rank || "Normal"}`, rankLabel);

          const atkDiamond = el("div", "en-diamond atk");
          atkDiamond.title = `Attack ${en.attack} · Swing countdown`;
          atkDiamond.appendChild(el("span", "en-atk-val", String(Math.max(1, Math.ceil((en.attackTimer || 0) / 10)))));

          const hpFmt = fmt(en.hp);
          const hpDiamond = el("div", "en-diamond hp" + (hpFmt.length >= 4 ? " compact-txt" : ""));
          hpDiamond.title = `HP ${fmt(en.hp)} / ${fmt(en.maxHp)}`;
          hpDiamond.appendChild(el("span", "en-hp-val", hpFmt));

          stage.append(por, frm, badge, atkDiamond, hpDiamond);

          const hpBar = el("div", "hp");
          const fill = el("i");
          fill.style.width = `${Math.max(0, (en.hp / en.maxHp) * 100)}%`;
          hpBar.appendChild(fill);

          const swingBar = el("div", "swing-bar");
          swingBar.title = `Swing timer (${(en.attackIntervalTicks / 10).toFixed(1)}s base)`;
          swingBar.appendChild(el("i"));

          card.append(stage, hpBar, swingBar);

          if (en.isCampaignBoss) {
            const pBar = el("div", "posture-bar");
            pBar.title = "Boss Posture Bar — break to Stagger & Interrupt!";
            const pFill = el("i");
            pFill.style.width = `${Math.max(0, ((en.posture ?? 100) / (en.maxPosture || 100)) * 100)}%`;
            pBar.appendChild(pFill);

            const teleBar = el("div", "telegraph-bar");
            teleBar.hidden = !(en.telegraphTicks > 0);
            teleBar.append(el("i"), el("span", null, ""));

            const enrageLine = el("div", "boss-enrage-line", `Enrage ${(Math.max(0, en.enrageTicks || 0) / 10).toFixed(1)}s`);
            card.append(pBar, teleBar, enrageLine);
          }

          const name = el("div", "name", en.name);
          name.title = en.name;
          const drPct = Math.round((en.mitigation || 0) * 100);
          const statsMini = el("div", "enemy-stats-mini");
          const hpTxt = el("b", "hp-txt", `${fmt(en.hp)}/${fmt(en.maxHp)}`);
          statsMini.append(hpTxt, el("div", null, `DMG ${en.attack} · DR ${drPct}%`));
          const dots = el("div", "dots");

          card.append(name, statsMini, dots);
        }
        card.onclick = () => {
          if (this.isCampaignMode()) return;
          this.selectedEnemySlot = i;
          this.renderEnemies();
          if (this.activeTab !== "encounter") this.switchTab("encounter");
          else this.renderActiveTab();
        };
        row.appendChild(card);
      }
    }

    frame() {
      const now = performance.now();
      if (this.campfireRemainingMs > 0) {
        const dt = Math.max(0, Math.min(250, now - (this.campfireLastTs || now)));
        this.campfireLastTs = now;
        this.campfireRemainingMs = Math.max(0, this.campfireRemainingMs - dt);
        this.refreshCampaignHud();
        if (this.campfireRemainingMs <= 0) {
          this.newFight(false);
          if (this.combat && !this.combat.state.result) {
            this.combat.tick();
            this.engine?.resume();
          }
          this.syncPlaybackButtons();
          this.feed(`Campfire recovery complete — Combat resumed at 100% HP.`, "system");
        }
      }

      if (this.combat) {
        const s = this.combat.state;
        const slots = $("#hotbar").children;
        const h = Math.min(0.85, this.combat.haste());
        const gcdDenom = Math.max(100, window.Tickforge.GCD_BASE_MS * (1 - h));
        const gcdFrac = s.gcdRemaining / gcdDenom;

        for (let i = 0; i < 5; i++) {
          const ab = this.combat.hotbarSlots?.[i];
          const slotEl = slots[i];
          if (!slotEl || !ab) continue;
          const cdDenom = Math.max(1, (ab.cooldownMs || 1) * (1 - h));
          slotEl.querySelector(".cd").style.transform = `scaleY(${Math.min(1, ab.cooldownRemaining / cdDenom)})`;
          slotEl.querySelector(".gcd").style.transform = `scaleX(${ab.autoCast || ab.gcd === false ? 0 : Math.min(1, gcdFrac)})`;
        }

        const autoFill = $("#autoAttackFill");
        if (autoFill) {
          let autoPct = 0;
          if (!s.result && s.enemies.some(e => !e.dead)) {
            if (this.combat.profile.enableWeaponAutoAttack) {
              const interval = Math.max(1, s.weaponSwingInterval || 18);
              autoPct = Math.max(0, Math.min(100, (1 - (s.weaponSwingTimer / interval)) * 100));
            } else {
              autoPct = Math.max(0, Math.min(100, (1 - Math.max(0, s.gcdRemaining) / gcdDenom) * 100));
            }
          }
          autoFill.style.width = `${autoPct.toFixed(1)}%`;
        }

        const maxHp = Math.max(1, this.combat.playerStats.maxHp);
        const hpRatio = Math.max(0, Math.min(1, s.playerHp / maxHp));
        const hpFillEl = $("#hpFill");
        if (hpFillEl) hpFillEl.style.height = `${(hpRatio * 100).toFixed(1)}%`;
        const hpLbl = $("#hpLabel");
        if (hpLbl) {
          hpLbl.textContent = fmt(s.playerHp);
          hpLbl.parentElement.title = `Player Health: ${fmt(s.playerHp)} / ${fmt(maxHp)}`;
        }

        const cls = this.combat.cls;
        const resRatio = Math.max(0, Math.min(1, s.resource / Math.max(1, s.resourceMax)));
        const mpFillEl = $("#mpFill");
        if (mpFillEl) {
          mpFillEl.style.height = `${(resRatio * 100).toFixed(1)}%`;
          const rc = cls.resource.color || "#3a8dff";
          mpFillEl.style.background = `linear-gradient(90deg, #101d38 0%, ${rc} 52%, #132240 100%)`;
        }
        const mpLbl = $("#mpLabel");
        if (mpLbl) {
          mpLbl.textContent = fmt(Math.round(s.resource));
          mpLbl.parentElement.title = `${cls.resource.label}: ${Math.round(s.resource)} / ${s.resourceMax}`;
        }

        for (let i = 0; i < 5; i++) {
          const pip = $(`#pip${i}`);
          if (pip) {
            pip.setAttribute("fill", cls.resource.type === "holy_power" && i < s.resource ? cls.resource.color : "#2a1d09");
          }
        }

        // Update live enemy cards in place
        const aliveList = s.enemies.filter(e => !e.dead);
        const focusedEnemy = aliveList.find(e => e.slotIndex === s.lastTargetSlot)
          || (aliveList.length ? aliveList.reduce((a, b) => (a.hp <= b.hp ? a : b)) : null);
        const frozenAll = s.freezeRemaining > 0 && this.combat.hasHook("temporal");

        for (const card of this.boardEl.querySelectorAll(".GS-UI-BOARD-enemy")) {
          const slotIdx = Number(card.dataset.slot);
          const en = (s.enemies || []).find(e => e.slotIndex === slotIdx) || s.boardSlots?.[slotIdx];
          if (!en) continue;
          const hpPct = Math.max(0, (en.hp / en.maxHp) * 100);
          const bar = card.querySelector(".hp i");
          if (bar) bar.style.width = `${hpPct}%`;
          const hpTxt = card.querySelector(".hp-txt");
          if (hpTxt) hpTxt.textContent = en.wardHp > 0 ? `${fmt(en.hp)}+${fmt(en.wardHp)}/${fmt(en.maxHp)}` : `${fmt(en.hp)}/${fmt(en.maxHp)}`;

          const atkVal = card.querySelector(".en-atk-val");
          if (atkVal) {
            const cdSec = en.dead ? 0 : Math.max(1, Math.ceil((en.attackTimer || 0) / 10));
            atkVal.textContent = String(cdSec);
            atkVal.parentElement.title = `Attack ${en.attack} · Next swing in ${(Math.max(0, en.attackTimer || 0) / 10).toFixed(1)}s`;
          }
          const hpVal = card.querySelector(".en-hp-val");
          if (hpVal) {
            const hpStr = fmt(en.hp);
            hpVal.textContent = hpStr;
            hpVal.parentElement.classList.toggle("compact-txt", hpStr.length >= 4);
            hpVal.parentElement.title = `HP ${fmt(en.hp)} / ${fmt(en.maxHp)} (${Math.round((en.mitigation || 0) * 100)}% DR)`;
          }

          card.classList.toggle("dead", !!en.dead);
          card.classList.toggle("focused", !!focusedEnemy && focusedEnemy.slotIndex === slotIdx && !en.dead);
          card.classList.toggle("boss-telegraphing", !!(en.isCampaignBoss && en.telegraphTicks > 0 && !en.dead));

          const swingBar = card.querySelector(".swing-bar");
          if (swingBar) {
            const fill = swingBar.firstElementChild;
            const denom = Math.max(1, en.attackIntervalTicks || 20);
            const prog = en.dead ? 0 : Math.max(0, Math.min(1, 1 - en.attackTimer / denom));
            if (fill) fill.style.transform = `scaleX(${prog.toFixed(3)})`;
            const slowed = !frozenAll && (s.rebukeRemaining > 0 || (en.slowTicks > 0 && en.slowPct > 0));
            swingBar.classList.toggle("frozen", frozenAll && !en.dead);
            swingBar.classList.toggle("slowed", slowed && !en.dead);
          }

          if (en.isCampaignBoss) {
            const pFill = card.querySelector(".posture-bar i");
            if (pFill) {
              const pPct = Math.max(0, ((en.posture ?? 100) / (en.maxPosture || 100)) * 100);
              pFill.style.width = `${pPct}%`;
            }
            const tBar = card.querySelector(".telegraph-bar");
            if (tBar) {
              if (en.telegraphTicks > 0 && !en.dead) {
                tBar.hidden = false;
                tBar.classList.add("active");
                const tProg = Math.max(0, Math.min(100, (1 - en.telegraphTicks / (en.telegraphMaxTicks || 28)) * 100));
                tBar.firstElementChild.style.width = `${tProg}%`;
                tBar.lastElementChild.textContent = `CASTING ${en.telegraphName} (${(en.telegraphTicks / 10).toFixed(1)}s) — INTERRUPT!`;
              } else {
                tBar.hidden = true;
                tBar.classList.remove("active");
              }
            }
            const eLine = card.querySelector(".boss-enrage-line");
            if (eLine) {
              eLine.classList.toggle("enraged", !!en.enraged);
              eLine.textContent = en.enraged ? "ENRAGED (+150% DMG · +50% SPD)" : `Enrage in ${(Math.max(0, en.enrageTicks || 0) / 10).toFixed(1)}s`;
            }
          }

          const dots = card.querySelector(".dots");
          if (dots) {
            const tags = [];
            for (const [sid, ail] of Object.entries(en.ailments || {})) {
              if (ail.remaining <= 0) continue;
              const school = D.schools.find(x => x.id === sid);
              tags.push({ text: fmt(Math.max(1, Math.round(ail.dps))), color: school?.color || "#fff" });
            }
            if (en.vulnTicks > 0) tags.push({ text: `${(en.vulnTicks / 10).toFixed(0)}s`, color: "#8fd4ff" });
            if (en.slowTicks > 0 && en.slowPct > 0) tags.push({ text: `${(en.slowTicks / 10).toFixed(0)}s`, color: "#7eb4f0" });
            if (en.staggerTicks > 0) tags.push({ text: `STG`, color: "#f4d98b" });

            if (dots.children.length !== tags.length) {
              dots.replaceChildren(...tags.map(t => {
                const pill = el("span", "dot-pill");
                const orb = el("i", "dot-orb");
                orb.style.background = t.color;
                const val = el("span", null, t.text);
                val.style.color = t.color;
                pill.append(orb, val);
                return pill;
              }));
            } else {
              for (let ti = 0; ti < tags.length; ti++) {
                const pill = dots.children[ti];
                const orb = pill.firstElementChild;
                const val = pill.lastElementChild;
                if (orb && orb.style.background !== tags[ti].color) orb.style.background = tags[ti].color;
                if (val && val.textContent !== tags[ti].text) val.textContent = tags[ti].text;
                if (val && val.style.color !== tags[ti].color) val.style.color = tags[ti].color;
              }
            }
          }
        }
        this.updateBuffsBar();
        this.updateSummary(false);
      }
      requestAnimationFrame(() => this.frame());
    }

    updateBuffsBar() {
      const bar = $("#playerBuffsBar");
      if (!bar || !this.combat) return;
      const s = this.combat.state;
      const tags = [];
      if (s.armorBuffRemaining > 0) tags.push({ cls: "defense", text: `Armor +25% DR ${(s.armorBuffRemaining / 1000).toFixed(1)}s` });
      if (s.dodgeRemaining > 0) tags.push({ cls: "defense", text: `Dodge +25% ${(s.dodgeRemaining / 1000).toFixed(1)}s` });
      if (s.hasteBuffRemaining > 0) tags.push({ cls: "offense", text: `Haste +25% ${(s.hasteBuffRemaining / 1000).toFixed(1)}s` });
      if (s.absorb > 0) tags.push({ cls: "ward", text: `Ward ${fmt(Math.round(s.absorb))}` });
      if (s.stagger > 0) tags.push({ cls: "stagger", text: `Stagger ${fmt(Math.round(s.stagger))}` });
      if (s.rebukeRemaining > 0) tags.push({ cls: "control", text: `Rebuke Slow ${(s.rebukeRemaining / 1000).toFixed(1)}s` });
      if (s.freezeRemaining > 0 && this.combat.hasHook("temporal")) tags.push({ cls: "control", text: `Temporal Freeze ${(s.freezeRemaining / 1000).toFixed(1)}s` });
      if (s.highJudgeReady) tags.push({ cls: "offense", text: "High Judge Surge" });
      if (s.bleedSpeedBoostTicks > 0) tags.push({ cls: "offense", text: `Bleed Rush ${(s.bleedSpeedBoostTicks / 10).toFixed(1)}s` });
      if (this.combat.itemMods?.dualPolarity) {
        tags.push({ cls: "offense", text: s.polarityIndex === 0 ? "Polarity: Fire +40%" : "Polarity: Lightning +40%" });
      }

      const key = tags.map(t => `${t.cls}:${t.text}`).join("|") || "idle";
      if (key === this._lastBuffKey) return;
      this._lastBuffKey = key;

      bar.replaceChildren();
      if (!tags.length) {
        bar.appendChild(el("span", "buff-idle", "Active Buffs & Wards: None"));
        return;
      }
      for (const t of tags) {
        bar.appendChild(el("span", `buff-tag ${t.cls}`, t.text));
      }
    }

    updateSummary(force) {
      if (!this.combat) return;
      const s = this.combat.state;
      const statusText = !s.enemies.length ? "EMPTY"
        : s.result === "victory" ? "VICTORY"
        : s.result === "defeat" ? "DEFEAT"
        : s.result === "timeout" ? "TIMEOUT"
        : this.engine?.paused ? "PAUSED" : "RUNNING";

      const key = `${statusText}|${s.elapsedMs}|${s.stats.damage}|${s.stats.casts}|${s.stats.totalHits || 0}|${s.stats.crits}|${s.stats.comboCount || 0}`;
      if (!force && key === this._lastSummaryKey) return;
      this._lastSummaryKey = key;

      const badge = $("#simStatus");
      if (badge) {
        badge.textContent = statusText;
        badge.className = `status-badge ${statusText}`;
      }

      const liveDps = this.combat.dps();
      const dpsEl = $("#dps");
      if (dpsEl) dpsEl.textContent = liveDps.toLocaleString();
      const timeSec = ((s.ttkMs ?? s.elapsedMs) / 1000).toFixed(1);
      const ttkEl = $("#ttk");
      if (ttkEl) ttkEl.textContent = `${timeSec}s`;
      const totEl = $("#totalDmg");
      if (totEl) totEl.textContent = fmt(s.stats.damage);
      const ccEl = $("#castsCrits");
      if (ccEl) ccEl.textContent = `${s.stats.casts} / ${s.stats.crits}`;

      const src = s.stats.bySourceType || { direct: 0, dot: 0, proc: 0 };
      const sb = $("#sourceBreakdown");
      if (sb) {
        sb.textContent = `Direct ${fmt(src.direct || 0)} · DoT ${fmt(src.dot || 0)} · Proc ${fmt(src.proc || 0)} · Combos ${s.stats.comboCount || 0}`;
      }

      this.renderDpsTimeline(s);
      this.renderDamageMeter(s);
      this.renderTimersPanel(s);
      this.renderLiveStatsPanel(s);
      this.renderKpiStrip(s);
    }

    renderDamageMeter(s) {
      const box = $("#damageMeterBody");
      if (!box) return;
      box.replaceChildren();

      const hdr = el("div", "mt mh");
      hdr.append(
        el("span", null, "SOURCE"),
        el("span", null, "DMG"),
        el("span", null, "%"),
        el("span", null, "HITS"),
        el("span", null, "CRIT"),
        el("span", null, "AVG"),
        el("span", null, "DPS")
      );
      box.appendChild(hdr);

      const entries = Object.values(s.stats.byAbility || {})
        .filter(e => e.damage > 0)
        .sort((a, b) => b.damage - a.damage);
      const elapsedSec = Math.max(0.1, (s.ttkMs ?? s.elapsedMs) / 1000);
      const totalDmg = Math.max(1, s.stats.damage);

      if (!entries.length) {
        const emptyRow = el("div", "mt");
        emptyRow.append(
          el("span", null, "Awaiting combat damage..."),
          el("span", null, "0"),
          el("span", null, "0"),
          el("span", null, "0"),
          el("span", null, "0%"),
          el("span", null, "0"),
          el("span", null, "0")
        );
        box.appendChild(emptyRow);
      } else {
        for (const e of entries.slice(0, 6)) {
          const hits = Math.max(1, e.hits || e.casts || 1);
          const pct = Math.round((e.damage / totalDmg) * 100);
          const critPct = Math.round(((e.crits || 0) / hits) * 100);
          const avg = Math.round(e.damage / hits);
          const abDps = Math.round(e.damage / elapsedSec);

          const row = el("div", "mt");
          const srcSpan = el("span", null);
          srcSpan.title = e.name;
          const sq = el("b", "sq");
          sq.style.background = e.color || "#efe6cf";
          srcSpan.append(sq, document.createTextNode(e.name));
          row.append(
            srcSpan,
            el("span", null, fmt(e.damage)),
            el("span", null, String(pct)),
            el("span", null, String(hits)),
            el("span", null, `${critPct}%`),
            el("span", null, fmt(avg)),
            el("span", null, fmt(abDps))
          );
          box.appendChild(row);
        }
      }

      const totHits = Math.max(0, s.stats.totalHits || 0);
      const totCritPct = totHits > 0 ? Math.round(((s.stats.crits || 0) / totHits) * 100) : 0;
      const totAvg = totHits > 0 ? Math.round(s.stats.damage / totHits) : 0;
      const totDps = s.elapsedMs > 0 ? Math.round(s.stats.damage / elapsedSec) : 0;

      const totRow = el("div", "mt mt-total");
      totRow.append(
        el("span", null, `Total · ${fmtClock(s.ttkMs ?? s.elapsedMs)}`),
        el("span", null, fmt(s.stats.damage)),
        el("span", null, s.stats.damage > 0 ? "100" : "0"),
        el("span", null, String(totHits)),
        el("span", null, `${totCritPct}%`),
        el("span", null, fmt(totAvg)),
        el("span", null, fmt(totDps))
      );
      box.appendChild(totRow);
    }

    renderTimersPanel(s) {
      const list = $("#timersList");
      const tgtLbl = $("#timersTargetLabel");
      if (!list) return;
      list.replaceChildren();

      const alive = s.enemies.filter(e => !e.dead);
      const focused = alive.find(e => e.slotIndex === s.lastTargetSlot)
        || (alive.length ? alive.reduce((a, b) => (a.hp <= b.hp ? a : b)) : null);
      if (tgtLbl) tgtLbl.textContent = focused ? `TARGET ${focused.slotIndex + 1}` : "ACTIVE";

      const items = [];
      if (focused) {
        for (const [sid, ail] of Object.entries(focused.ailments || {})) {
          if (ail.remaining <= 0) continue;
          const sc = D.schools.find(x => x.id === sid);
          items.push({
            name: (ail.abilityName || sc?.name || "DoT").replace(/\s*\(DoT\)$/, ""),
            pct: Math.min(100, Math.round((ail.remaining / 50) * 100)),
            time: `${(ail.remaining / 10).toFixed(1)}s`,
            color: sc?.color || "#58c24b",
          });
        }
        if (focused.vulnTicks > 0) {
          items.push({
            name: "Shocked",
            pct: Math.min(100, Math.round((focused.vulnTicks / 30) * 100)),
            time: `${(focused.vulnTicks / 10).toFixed(1)}s`,
            color: "#8fd4ff",
          });
        }
      }

      if (s.armorBuffRemaining > 0) items.push({ name: "Iron Warcry", pct: Math.min(100, Math.round((s.armorBuffRemaining / 4000) * 100)), time: `${(s.armorBuffRemaining / 1000).toFixed(1)}s`, color: "#e7c35c" });
      if (s.dodgeRemaining > 0) items.push({ name: "Shadow Veil", pct: Math.min(100, Math.round((s.dodgeRemaining / 3000) * 100)), time: `${(s.dodgeRemaining / 1000).toFixed(1)}s`, color: "#6fe3c2" });
      if (s.hasteBuffRemaining > 0) items.push({ name: "Haste Surge", pct: Math.min(100, Math.round((s.hasteBuffRemaining / 3000) * 100)), time: `${(s.hasteBuffRemaining / 1000).toFixed(1)}s`, color: "#ff8a2a" });
      if (s.rebukeRemaining > 0) items.push({ name: "Rebuke Aura", pct: Math.min(100, Math.round((s.rebukeRemaining / 500) * 100)), time: `${(s.rebukeRemaining / 1000).toFixed(1)}s`, color: "#3fb8a8" });

      for (const ab of this.combat.equippedAbilities || []) {
        if (ab.cooldownRemaining > 0 && ab.cooldownMs > 0) {
          items.push({
            name: `${ab.name} CD`,
            pct: Math.min(100, Math.round((ab.cooldownRemaining / ab.cooldownMs) * 100)),
            time: `${(ab.cooldownRemaining / 1000).toFixed(1)}s`,
            color: "#b07cff",
          });
        }
      }

      if (!items.length) {
        const empty = el("div", "kv");
        empty.append(el("span", null, "No active timers"), el("b", null, "—"));
        list.appendChild(empty);
        return;
      }

      for (const it of items.slice(0, 6)) {
        const row = el("div", "tm");
        const nameEl = el("span", null, it.name);
        nameEl.title = it.name;
        const bar = el("div", "bar");
        const fill = el("div", "bar-fill");
        fill.style.width = `${Math.max(4, it.pct)}%`;
        fill.style.background = it.color;
        bar.appendChild(fill);
        row.append(nameEl, bar, el("span", null, it.time));
        list.appendChild(row);
      }
    }

    renderLiveStatsPanel(s) {
      const body = $("#statsBody");
      if (!body) return;
      body.replaceChildren();
      const st = this.combat.playerStats;
      const totHits = s.stats.totalHits || 0;
      const obsCritPct = totHits > 0 ? ((s.stats.crits || 0) / totHits) * 100 : (st.critChance * 100);
      const critDmgBonus = Math.round((0.5 + (st.critMulti || 0.35)) * 100);
      const hastePct = this.combat.haste() * 100;
      const ticks = Math.max(1, this.combat.currentTick || 0);
      const dotUptimePct = this.combat.currentTick > 0 ? Math.min(100, Math.round(((s.stats.dotActiveTicks || 0) / ticks) * 100)) : 0;
      const elapsedSec = Math.max(0.1, (s.ttkMs ?? s.elapsedMs) / 1000);
      const ticksPerSec = s.elapsedMs > 0 ? (s.stats.dotTicks || 0) / elapsedSec : 0;
      const kt = s.stats.killTimesMs || [];
      const avgKillSec = kt.length ? (kt.reduce((a, b) => a + b, 0) / kt.length) / 1000 : 0;

      const addKv = (k, v) => {
        const row = el("div", "kv");
        row.append(el("span", null, k), el("b", null, v));
        body.appendChild(row);
      };
      addKv("Crit chance", `${obsCritPct.toFixed(1)}%`);
      addKv("Crit damage", `+${critDmgBonus}%`);
      addKv("Haste", `${hastePct.toFixed(1)}%`);
      addKv("DoT uptime", `${dotUptimePct}%`);
      addKv("Ticks / sec", ticksPerSec.toFixed(1));
      addKv("Avg kill time", avgKillSec > 0 ? `${avgKillSec.toFixed(1)}s` : "—");
    }

    renderKpiStrip(s) {
      const elapsedHr = Math.max(1 / 360, (Date.now() - this.sessionTracker.startedAt) / 3600000);
      const fightHr = Math.max(1 / 720, ((s.ttkMs ?? s.elapsedMs) || 1000) / 3600000);

      let xpHr = 0, goldHr = 0, killsHr = 0, dropsHr = 0;
      if (this.sessionTracker.kills > 0 || this.sessionTracker.xp > 0 || this.sessionTracker.gold > 0) {
        xpHr = Math.round(this.sessionTracker.xp / elapsedHr);
        goldHr = Math.round(this.sessionTracker.gold / elapsedHr);
        killsHr = Math.round(this.sessionTracker.kills / elapsedHr);
        dropsHr = Math.round(this.sessionTracker.drops / elapsedHr);
      } else if (s.stats.kills > 0 && s.elapsedMs > 0) {
        killsHr = Math.round(s.stats.kills / fightHr);
      }

      const setTxt = (id, val) => {
        const node = $(id);
        if (node) node.textContent = val;
      };
      setTxt("#kpiXpHr", fmt(xpHr));
      setTxt("#kpiGoldHr", fmt(goldHr));
      setTxt("#kpiKillsHr", fmt(killsHr));
      setTxt("#kpiDropsHr", fmt(dropsHr));
    }

    renderDpsTimeline(s) {
      const svg = $("#dpsTimelineSvg");
      const peakEl = $("#dpsPeak");
      if (!svg) return;
      const pts = s.timeline || [];
      const chartKey = `${pts.length}|${s.result || ""}|${s.stats.damage}`;
      if (chartKey === this._lastChartKey) return;
      this._lastChartKey = chartKey;

      svg.replaceChildren();
      const W = 360, H = 76, padX = 4, padY = 6;
      const plotW = W - padX * 2, plotH = H - padY * 2;

      // Baseline horizontal guide lines
      for (const frac of [0.25, 0.5, 0.75, 1]) {
        const y = padY + plotH * frac;
        svg.appendChild(svgEl("line", {
          x1: padX, y1: y.toFixed(1), x2: W - padX, y2: y.toFixed(1),
          stroke: "#232838", "stroke-width": 1, "stroke-dasharray": frac < 1 ? "3 3" : "none",
        }));
      }

      if (!pts.length) {
        if (peakEl) peakEl.textContent = "Peak 0";
        const t = svgEl("text", { x: W / 2, y: H / 2 + 3, "text-anchor": "middle", fill: "#6e768d", "font-size": 10 });
        t.textContent = "Timeline updates every 1.0s during combat";
        svg.appendChild(t);
        return;
      }

      const maxY = Math.max(10, ...pts.map(p => p.total));
      if (peakEl) peakEl.textContent = `Peak ${fmt(maxY)}/s`;

      const toPoints = (getter) => {
        if (pts.length === 1) {
          const v = getter(pts[0]);
          const y = (padY + plotH * (1 - v / maxY)).toFixed(1);
          return `${padX},${y} ${W - padX},${y}`;
        }
        return pts.map((p, idx) => {
          const x = padX + (idx / (pts.length - 1)) * plotW;
          const y = padY + plotH * (1 - getter(p) / maxY);
          return `${x.toFixed(1)},${y.toFixed(1)}`;
        }).join(" ");
      };

      const totalPts = toPoints(p => p.total || 0);
      const baseY = (padY + plotH).toFixed(1);
      svg.appendChild(svgEl("polygon", {
        fill: "#f4d98b",
        "fill-opacity": "0.10",
        points: `${padX},${baseY} ${totalPts} ${W - padX},${baseY}`,
      }));

      const series = [
        { key: "proc", color: "#6fe3c2", width: 1.4, opacity: 0.9 },
        { key: "dot", color: "#ff9448", width: 1.5, opacity: 0.9 },
        { key: "direct", color: "#c8cdd8", width: 1.4, opacity: 0.75 },
        { key: "total", color: "#f4d98b", width: 2.2, opacity: 1.0 },
      ];
      for (const ser of series) {
        svg.appendChild(svgEl("polyline", {
          fill: "none",
          stroke: ser.color,
          "stroke-width": ser.width,
          "stroke-opacity": ser.opacity,
          "stroke-linejoin": "round",
          "stroke-linecap": "round",
          points: ser.key === "total" ? totalPts : toPoints(p => p[ser.key] || 0),
        }));
      }

      const last = pts[pts.length - 1];
      const lbl = svgEl("text", { x: W - padX - 2, y: 12, "text-anchor": "end", fill: "#9ca3b8", "font-size": 9 });
      lbl.textContent = `${last.sec.toFixed(1)}s · 3s ${fmt(last.total)}/s · Avg ${fmt(last.cumDps)}/s`;
      svg.appendChild(lbl);
    }

    spawnFct({ target, text, crit, color }) {
      if (!this.repo.profile.settings?.fx) return;
      const board = this.boardEl;
      const f = el("div", `FCT${crit ? " crit" : ""}`, text);
      f.style.color = color;
      let x = board.clientWidth / 2, y = board.clientHeight * 0.4;
      if (target) {
        const card = board.querySelector(`.GS-UI-BOARD-enemy[data-slot="${target.slotIndex}"]`);
        if (card) {
          const r = card.getBoundingClientRect(), b = board.getBoundingClientRect();
          x = r.left - b.left + r.width / 2;
          y = r.top - b.top + 12;
        }
      }
      f.style.left = `${x + (Math.random() * 24 - 12)}px`;
      f.style.top = `${y - 6}px`;
      board.appendChild(f);
      setTimeout(() => f.remove(), 920);
      if (crit) this.shake("light");
    }

    spawnFx(key, { target }) {
      if (!this.repo.profile.settings?.fx || !this.combat || this.combat.fxTier === 0) return;
      const board = this.boardEl;
      const fx = el("div", "GS-FX");
      const img = el("img");
      img.src = key.startsWith("GS-FX-") ? `assets/fx/${key}.svg` : `assets/fx/GS-FX-${key}.svg`;
      img.alt = "";
      img.style.width = "100%";
      fx.appendChild(img);
      let x = board.clientWidth / 2, y = board.clientHeight * 0.35;
      if (target) {
        this.flashEnemy(target.slotIndex, "hit-flash", 160);
        const card = board.querySelector(`.GS-UI-BOARD-enemy[data-slot="${target.slotIndex}"]`);
        if (card) {
          const r = card.getBoundingClientRect(), b = board.getBoundingClientRect();
          x = r.left - b.left + r.width / 2;
          y = r.top - b.top + 38;
        }
      }
      fx.style.left = `${x}px`;
      fx.style.top = `${y}px`;
      board.appendChild(fx);
      setTimeout(() => fx.remove(), 460);
    }

    flashEnemy(slotIdx, cls, ms = 180) {
      if (slotIdx == null || !this.repo.profile.settings?.fx || this.combat?.fxTier === 0) return;
      const card = this.boardEl?.querySelector(`.GS-UI-BOARD-enemy[data-slot="${slotIdx}"]`);
      if (!card) return;
      card.classList.remove(cls);
      void card.offsetWidth;
      card.classList.add(cls);
      setTimeout(() => card.classList.remove(cls), ms);
    }

    spawnProjectile({ school, slotIndex, targetSlots, fxKey }) {
      if (!this.repo.profile.settings?.fx || !this.combat || this.combat.fxTier === 0) return;
      if (window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches) return;
      const board = this.boardEl;
      const hotbarEl = $("#hotbar");
      const srcEl = hotbarEl?.children[slotIndex ?? 0] || hotbarEl;
      if (!board || !srcEl || !targetSlots?.length) return;

      const b = board.getBoundingClientRect();
      const sr = srcEl.getBoundingClientRect();
      const x0 = sr.left - b.left + sr.width / 2;
      const y0 = sr.top - b.top + sr.height / 2;
      const srcPath = fxKey ? (fxKey.startsWith("GS-FX-") ? `assets/fx/${fxKey}.svg` : `assets/fx/GS-FX-${fxKey}.svg`)
        : fxPath(school?.id, "PRJ");

      for (const tSlot of targetSlots) {
        const card = board.querySelector(`.GS-UI-BOARD-enemy[data-slot="${tSlot}"] .portrait-stage`)
          || board.querySelector(`.GS-UI-BOARD-enemy[data-slot="${tSlot}"]`);
        if (!card) continue;
        const tr = card.getBoundingClientRect();
        const x1 = tr.left - b.left + tr.width / 2;
        const y1 = tr.top - b.top + tr.height / 2;
        const deg = Math.round(Math.atan2(y1 - y0, x1 - x0) * (180 / Math.PI));

        const proj = el("div", "GS-PROJ");
        const img = el("img");
        img.src = srcPath;
        img.alt = "";
        proj.appendChild(img);
        board.appendChild(proj);

        if (typeof proj.animate === "function") {
          const anim = proj.animate([
            { transform: `translate3d(${x0}px, ${y0}px, 0) rotate(${deg}deg) scale(0.75)`, opacity: 0.9 },
            { transform: `translate3d(${x1}px, ${y1}px, 0) rotate(${deg}deg) scale(1.15)`, opacity: 1, offset: 0.82 },
            { transform: `translate3d(${x1}px, ${y1}px, 0) rotate(${deg}deg) scale(1.3)`, opacity: 0 },
          ], { duration: 220, easing: "cubic-bezier(0.22, 1, 0.36, 1)", fill: "forwards" });
          anim.onfinish = () => proj.remove();
          setTimeout(() => { if (proj.isConnected) proj.remove(); }, 280);
        } else {
          proj.style.transform = `translate3d(${x1}px, ${y1}px, 0)`;
          setTimeout(() => proj.remove(), 220);
        }
      }
    }

    pulseSlot(abilityId) {
      const p = this.repo.profile;
      const activeLoadout = this.isCampaignMode() ? (p.campaign?.loadout || []) : (p.loadout || []);
      const i = activeLoadout.indexOf(abilityId);
      const slot = $("#hotbar").children[i];
      if (!slot) return;
      slot.classList.add("pulse");
      setTimeout(() => slot.classList.remove("pulse"), 120);
    }

    shake(kind) {
      if (!this.repo.profile.settings?.fx || !this.combat || this.combat.fxTier === 0) return;
      this.boardEl.classList.remove("tf-shake-light", "tf-shake-heavy");
      void this.boardEl.offsetWidth;
      this.boardEl.classList.add(`tf-shake-${kind}`);
    }

    feed(text, cls) {
      if (!this.repo.profile.settings?.feed) return;
      const raw = String(text || "");
      const m = raw.match(/^\[(\d+(?:\.\d+)?)s\]\s*/);
      const elapsedMs = m ? Math.round(parseFloat(m[1]) * 1000) : (this.combat?.state?.elapsedMs || 0);
      const clean = m ? raw.slice(m[0].length) : raw;
      this.combatLogEntries.push({
        timeStr: fmtClock(elapsedMs),
        text: clean,
        cls: cls || "system",
      });
      if (this.combatLogEntries.length > 120) this.combatLogEntries.shift();
      this.renderCombatFeed();
    }

    renderCombatFeed() {
      if (!this.feedEl) return;
      const filter = this.combatLogFilter || "all";
      const rows = filter === "all"
        ? this.combatLogEntries
        : this.combatLogEntries.filter(e => e.cls === filter);

      this.feedEl.replaceChildren();
      const colorMap = {
        loot: "#ffd84a",
        cast: "#d4b0ff",
        hook: "#7ee06f",
        resource: "#8fd4ff",
        system: "#cdbf9f",
      };
      for (const entry of rows.slice(-60)) {
        const row = el("div", `lg GS-UI-FEED-line ${entry.cls}`);
        const tm = el("i", null, entry.timeStr);
        const sp = el("span", null, entry.text);
        sp.style.color = colorMap[entry.cls] || "#cdbf9f";
        sp.title = entry.text;
        row.append(tm, sp);
        this.feedEl.appendChild(row);
      }
      this.feedEl.scrollTop = this.feedEl.scrollHeight;
    }

    onLootEvent(evt) {
      if (!evt) return;
      if (evt.kind === "gold") {
        const g = parseInt(String(evt.text || "0").replace(/[^\d]/g, ""), 10) || 0;
        this.sessionTracker.gold += g;
      } else if (evt.kind === "item") {
        this.sessionTracker.drops++;
      }
      const color = evt.color || RARITY_COLOR[evt.rarity] || "#f2d34a";
      this.addLootEntry(evt.text, color, evt.elapsedMs || 0);
    }

    addLootEntry(text, color = "#f2d34a", elapsedMs = 0) {
      this.lootEntries.unshift({
        timeStr: fmtClock(elapsedMs),
        text,
        color,
      });
      if (this.lootEntries.length > 80) this.lootEntries.pop();

      const cnt = $("#lootCountLabel");
      if (cnt) cnt.textContent = `${this.lootEntries.length} ITEMS`;
      if (!this.lootFeedEl) return;
      this.lootFeedEl.replaceChildren();
      for (const item of this.lootEntries.slice(0, 40)) {
        const row = el("div", "lg");
        const tm = el("i", null, item.timeStr);
        const sp = el("span", null, item.text);
        sp.style.color = item.color;
        sp.title = item.text;
        row.append(tm, sp);
        this.lootFeedEl.appendChild(row);
      }
    }

    // ── RIGHT PANEL TABS ──
    renderActiveTab() {
      const body = $("#sandboxTabBody");
      body.replaceChildren();
      if (this.isCampaignMode()) {
        if (!this.repo.profile.campaign?.started) {
          this.renderCampaignOnboarding(body);
          return;
        }
        if (this.activeTab === "campaign_home") this.renderCampaignHomeTab(body);
        else if (this.activeTab === "campaign_gear") this.renderCampaignGearTab(body);
        else if (this.activeTab === "campaign_mc") this.renderCampaignMonteCarloTab(body);
        else if (this.activeTab === "campaign_filter") this.renderCampaignFilterTab(body);
        else if (this.activeTab === "campaign_stats") this.renderCampaignStatsTab(body);
        else this.renderCampaignHomeTab(body);
        return;
      }
      if (this.activeTab === "encounter") this.renderEncounterTab(body);
      else if (this.activeTab === "spells") this.renderSpellsTab(body);
      else if (this.activeTab === "items") this.renderItemsTab(body);
      else if (this.activeTab === "stats") this.renderStatsTab(body);
      else if (this.activeTab === "theorycraft") this.renderTheorycraftTab(body);
    }

    // ── FEATURE 1: Full-Freedom Enemy Encounter Sandbox (1 to 5 Enemies) ──
    renderEncounterTab(body) {
      const p = this.repo.profile;
      const enc = p.sandboxEncounter;

      // Top card: 5 Portrait Slots + Fill 1-5 / Clear Slot
      const slotCard = el("div", "panel-card");
      const head = el("div", "panel-card-head");
      head.appendChild(el("h3", null, "Encounter Slots (0–4)"));
      const actions = el("div", "preset-row");
      const filledCount = enc.filter(Boolean).length;

      const fillBtn = el("button", "tf-btn primary", filledCount < 5 ? "Fill 1–5 (All 5)" : "Fill 1–5 (1 Only)");
      fillBtn.type = "button";
      fillBtn.onclick = () => {
        const ref = enc[this.selectedEnemySlot] || enc.find(Boolean) || { enemyId: D.enemies[0].id, baseHp: 100, multiplier: 1, rank: "Normal" };
        if (filledCount < 5) {
          for (let i = 0; i < 5; i++) {
            if (!enc[i]) {
              const def = D.enemies[(i * 2) % D.enemies.length];
              enc[i] = { enemyId: def.id, baseHp: ref.baseHp, multiplier: ref.multiplier, rank: ref.rank };
            }
          }
        } else {
          const keep = enc[0] || ref;
          for (let i = 0; i < 5; i++) enc[i] = i === 0 ? keep : null;
          this.selectedEnemySlot = 0;
        }
        this.repo.save();
        this.newFight(false);
        this.renderActiveTab();
      };

      const clearBtn = el("button", "tf-btn danger", `Clear Slot ${this.selectedEnemySlot}`);
      clearBtn.type = "button";
      clearBtn.disabled = !enc[this.selectedEnemySlot];
      clearBtn.onclick = () => {
        enc[this.selectedEnemySlot] = null;
        this.repo.save();
        this.newFight(false);
        this.renderActiveTab();
      };

      actions.append(fillBtn, clearBtn);
      head.appendChild(actions);
      slotCard.appendChild(head);

      const strip = el("div", "slot-strip");
      for (let i = 0; i < 5; i++) {
        const cfg = enc[i];
        const pill = el("button", "slot-pill" + (i === this.selectedEnemySlot ? " active" : ""));
        pill.type = "button";
        if (cfg) {
          const def = D.enemies.find(e => e.id === cfg.enemyId) || D.enemies[0];
          const img = el("img");
          img.src = def.portrait;
          img.alt = def.name;
          pill.append(el("span", null, `Slot ${i}`), img, el("span", "slot-name", def.name));
        } else {
          pill.append(el("span", null, `Slot ${i}`), el("b", null, "+"), el("span", "slot-name", "Empty"));
        }
        pill.onclick = () => {
          this.selectedEnemySlot = i;
          this.renderEnemies();
          this.renderActiveTab();
        };
        strip.appendChild(pill);
      }
      slotCard.appendChild(strip);
      body.appendChild(slotCard);

      // Slot Configurator Card
      const cfgCard = el("div", "panel-card");
      const cfgHead = el("div", "panel-card-head");
      cfgHead.appendChild(el("h3", null, `Configure Slot ${this.selectedEnemySlot}`));

      let cur = enc[this.selectedEnemySlot];
      if (!cur) {
        const addBtn = el("button", "tf-btn primary", `+ Place Enemy in Slot ${this.selectedEnemySlot}`);
        addBtn.type = "button";
        addBtn.onclick = () => {
          const ref = enc.find(Boolean) || { baseHp: 100, multiplier: 1, rank: "Normal" };
          enc[this.selectedEnemySlot] = {
            enemyId: D.enemies[this.selectedEnemySlot % D.enemies.length].id,
            baseHp: ref.baseHp,
            multiplier: ref.multiplier,
            rank: ref.rank,
          };
          this.repo.save();
          this.newFight(false);
          this.renderActiveTab();
        };
        cfgHead.appendChild(addBtn);
        cfgCard.append(cfgHead, el("p", "GS-UI-FEED-line", "This slot is currently empty. Place an enemy here or use Fill 1–5 above."));
        body.appendChild(cfgCard);
        return;
      }

      const applyAllBtn = el("button", "tf-btn", "Apply HP / Mult / Rank to All");
      applyAllBtn.type = "button";
      applyAllBtn.onclick = () => {
        for (let i = 0; i < 5; i++) {
          if (enc[i]) {
            enc[i].baseHp = cur.baseHp;
            enc[i].multiplier = cur.multiplier;
            enc[i].rank = cur.rank;
          }
        }
        this.repo.save();
        this.newFight(false);
        this.renderActiveTab();
      };
      cfgHead.appendChild(applyAllBtn);
      cfgCard.appendChild(cfgHead);

      // Enemy Type Picker
      const enemyWrap = el("label", "field-col", "Enemy Type (data/enemies.json)");
      const enemySelect = el("select", "tf-select");
      for (const def of D.enemies) {
        const opt = el("option", null, `${def.name} (${def.school.replace("school_", "")}, base ATK ${def.attack}, ${def.attackIntervalMs / 1000}s swing)`);
        opt.value = def.id;
        if (def.id === cur.enemyId) opt.selected = true;
        enemySelect.appendChild(opt);
      }
      enemySelect.onchange = () => {
        cur.enemyId = enemySelect.value;
        this.repo.save();
        this.newFight(false);
        this.renderActiveTab();
      };
      enemyWrap.appendChild(enemySelect);
      cfgCard.appendChild(enemyWrap);

      // Base HP Presets: 1 HP, 5 HP, 25 HP, 100 HP, 1,000 HP
      cfgCard.appendChild(el("div", "sub-label", "Base HP Selector"));
      const hpRow = el("div", "preset-row");
      for (const hpVal of [1, 5, 25, 100, 1000]) {
        const b = el("button", "tf-btn" + (cur.baseHp === hpVal ? " active" : ""), `${hpVal.toLocaleString()} HP`);
        b.type = "button";
        b.onclick = () => {
          cur.baseHp = hpVal;
          this.repo.save();
          this.newFight(false);
          this.renderActiveTab();
        };
        hpRow.appendChild(b);
      }
      cfgCard.appendChild(hpRow);

      // HP/Stat Multiplier: x1, x2, x5, x10
      cfgCard.appendChild(el("div", "sub-label", "HP / Stat Multiplier"));
      const multRow = el("div", "preset-row");
      for (const m of [1, 2, 5, 10]) {
        const b = el("button", "tf-btn" + (cur.multiplier === m ? " active" : ""), `x${m}`);
        b.type = "button";
        b.onclick = () => {
          cur.multiplier = m;
          this.repo.save();
          this.newFight(false);
          this.renderActiveTab();
        };
        multRow.appendChild(b);
      }
      cfgCard.appendChild(multRow);

      // Rank Selector: Normal, Elite, Boss
      cfgCard.appendChild(el("div", "sub-label", "Rank Selector"));
      const rankRow = el("div", "preset-row");
      for (const [rk, info] of [
        ["Normal", "Normal (1.0x HP, 1.0x DMG, 0% DR)"],
        ["Elite", "Elite (2.5x HP, 1.5x DMG, 15% DR)"],
        ["Boss", "Boss (6.0x HP, 2.2x DMG, 30% DR)"],
      ]) {
        const b = el("button", "tf-btn" + (cur.rank === rk ? " active" : ""), info);
        b.type = "button";
        b.onclick = () => {
          cur.rank = rk;
          this.repo.save();
          this.newFight(false);
          this.renderActiveTab();
        };
        rankRow.appendChild(b);
      }
      cfgCard.appendChild(rankRow);

      // Calculated Preview
      const def = D.enemies.find(e => e.id === cur.enemyId) || D.enemies[0];
      const preview = computeEncounterEnemy(def, cur, this.selectedEnemySlot);
      const pvBox = el("div", "formula-preview");
      pvBox.append(
        el("span", null, `Final HP: `),
        el("b", null, preview.maxHp.toLocaleString()),
        el("span", null, `Final Damage: `),
        el("b", null, String(preview.attack)),
        el("span", null, `Armor DR: `),
        el("b", null, `${Math.round(preview.mitigation * 100)}%`)
      );
      cfgCard.appendChild(pvBox);
      body.appendChild(cfgCard);
    }

    // ── FEATURE 2A: Premade + Custom Spells & Hotbar (Slots 1-5) ──
    renderSpellsTab(body) {
      const p = this.repo.profile;
      const spells = this.allSpells();

      // Hotbar Slot Picker
      const hotCard = el("div", "panel-card");
      const hotHead = el("div", "panel-card-head");
      hotHead.appendChild(el("h3", null, `Active Hotbar (Editing Slot ${this.selectedHotbarSlot + 1})`));
      const btnRow = el("div", "preset-row");
      const clearSlotBtn = el("button", "tf-btn danger", `Clear Slot ${this.selectedHotbarSlot + 1}`);
      clearSlotBtn.type = "button";
      clearSlotBtn.disabled = !p.loadout[this.selectedHotbarSlot];
      clearSlotBtn.onclick = () => {
        p.loadout[this.selectedHotbarSlot] = null;
        this.repo.save();
        this.refreshHeaderAndHotbar();
        this.newFight(false);
        this.renderActiveTab();
      };
      const newSpellToggle = el("button", "tf-btn primary", this.showNewSpellForm ? "Close Creator" : "+ New Spell");
      newSpellToggle.type = "button";
      newSpellToggle.onclick = () => {
        this.showNewSpellForm = !this.showNewSpellForm;
        this.renderActiveTab();
      };
      btnRow.append(clearSlotBtn, newSpellToggle);
      hotHead.appendChild(btnRow);
      hotCard.appendChild(hotHead);

      const strip = el("div", "slot-strip");
      for (let i = 0; i < 5; i++) {
        const abId = p.loadout[i];
        const ab = abId ? spells.find(a => a.id === abId) : null;
        const pill = el("button", "slot-pill" + (i === this.selectedHotbarSlot ? " active" : ""));
        pill.type = "button";
        if (ab) {
          const img = el("img");
          img.src = fxPath(ab.school, ab.fx);
          img.alt = ab.name;
          pill.append(el("span", null, `Key ${i + 1}`), img, el("span", "slot-name", ab.name));
        } else {
          pill.append(el("span", null, `Key ${i + 1}`), el("b", null, "—"), el("span", "slot-name", "Empty"));
        }
        pill.onclick = () => {
          this.selectedHotbarSlot = i;
          this.refreshHeaderAndHotbar();
          this.renderActiveTab();
        };
        strip.appendChild(pill);
      }
      const shiftRow = el("div", "slot-move-row");
      shiftRow.appendChild(el("div", "d", "Auto-casts left-to-right (Slots 1 → 5) during combat."));
      const moveBtns = el("div", "slot-move-btns");
      const mvLeft = el("button", "tf-btn", "◄ Shift Left");
      mvLeft.type = "button";
      mvLeft.disabled = this.selectedHotbarSlot <= 0 || !p.loadout[this.selectedHotbarSlot];
      mvLeft.onclick = () => {
        const idx = this.selectedHotbarSlot;
        if (idx <= 0) return;
        const tmp = p.loadout[idx - 1];
        p.loadout[idx - 1] = p.loadout[idx];
        p.loadout[idx] = tmp;
        this.selectedHotbarSlot = idx - 1;
        this.repo.save();
        this.refreshHeaderAndHotbar();
        this.newFight(false);
        this.renderActiveTab();
      };
      const mvRight = el("button", "tf-btn", "Shift Right ►");
      mvRight.type = "button";
      mvRight.disabled = this.selectedHotbarSlot >= 4 || !p.loadout[this.selectedHotbarSlot];
      mvRight.onclick = () => {
        const idx = this.selectedHotbarSlot;
        if (idx >= 4) return;
        const tmp = p.loadout[idx + 1];
        p.loadout[idx + 1] = p.loadout[idx];
        p.loadout[idx] = tmp;
        this.selectedHotbarSlot = idx + 1;
        this.repo.save();
        this.refreshHeaderAndHotbar();
        this.newFight(false);
        this.renderActiveTab();
      };
      moveBtns.append(mvLeft, mvRight);
      shiftRow.appendChild(moveBtns);
      hotCard.append(strip, shiftRow);
      body.appendChild(hotCard);

      // + New Spell Creator
      if (this.showNewSpellForm) {
        body.appendChild(this.buildNewSpellForm());
      }

      // Premade + Custom Spell Browser
      const listCard = el("div", "panel-card");
      const listHead = el("div", "panel-card-head");
      listHead.appendChild(el("h3", null, "Spell Library"));
      const searchInput = el("input", "tf-input");
      searchInput.type = "search";
      searchInput.placeholder = "Search spells...";
      searchInput.value = this.spellSearch;
      searchInput.oninput = () => {
        this.spellSearch = searchInput.value;
        this.renderSpellCatalog(catalog);
      };
      listHead.appendChild(searchInput);
      listCard.appendChild(listHead);

      const filterRow = el("div", "preset-row");
      for (const [fKey, fLabel] of [
        ["all", "All"], ["custom", "Custom"],
        ["school_physical", "Physical"], ["school_fire", "Fire"],
        ["school_lightning", "Lightning"], ["school_poison", "Poison"], ["school_bleed", "Bleed"],
      ]) {
        const b = el("button", "tf-btn" + (this.spellFilter === fKey ? " active" : ""), fLabel);
        b.type = "button";
        b.onclick = () => {
          this.spellFilter = fKey;
          this.renderActiveTab();
        };
        filterRow.appendChild(b);
      }
      listCard.appendChild(filterRow);

      const catalog = el("div", "catalog-list");
      this.renderSpellCatalog(catalog);
      listCard.appendChild(catalog);
      body.appendChild(listCard);
    }

    renderSpellCatalog(container) {
      container.replaceChildren();
      const p = this.repo.profile;
      const q = this.spellSearch.trim().toLowerCase();
      const filtered = this.allSpells().filter(ab => {
        if (this.spellFilter === "custom" && !ab.isCustom) return false;
        if (this.spellFilter.startsWith("school_") && ab.school !== this.spellFilter) return false;
        if (q && !ab.name.toLowerCase().includes(q) && !(ab.description || "").toLowerCase().includes(q)) return false;
        return true;
      });

      if (!filtered.length) {
        container.appendChild(el("div", "GS-UI-FEED-line", "No matching spells."));
        return;
      }

      for (const ab of filtered) {
        const card = el("div", "GS-UI-CARD");
        const img = el("img");
        img.src = fxPath(ab.school, ab.fx);
        img.alt = ab.name;
        const info = el("div", "card-info");
        const schoolName = (D.schools.find(s => s.id === ab.school)?.name) || "Physical";
        const metaParts = [
          schoolName,
          `CD ${((ab.cooldownMs || 0) / 1000).toFixed(1)}s`,
          ab.targetType || "single",
        ];
        if (ab.customBaseDamage != null) metaParts.push(`Base ${ab.customBaseDamage}`);
        if (ab.resourceCost) metaParts.push(`-${ab.resourceCost} Res`);
        if (ab.resourceGain) metaParts.push(`+${ab.resourceGain} Res`);
        if (ab.applies?.dot) metaParts.push(`DoT ${(ab.applies.duration || 40) / 10}s`);
        if (ab.proc?.trigger && ab.proc.trigger !== "none") metaParts.push(`Proc ${ab.proc.trigger}`);
        if (ab.isCustom) metaParts.unshift("CUSTOM");

        info.append(
          el("div", "t", ab.name),
          el("div", "tier", metaParts.join(" · ")),
          el("div", "d", ab.description || "")
        );

        const btnCol = el("div", "preset-row");
        const slottedIdx = (p.loadout || []).indexOf(ab.id);
        const assignBtn = el("button", "tf-btn" + (slottedIdx === this.selectedHotbarSlot ? " active" : ""),
          slottedIdx === this.selectedHotbarSlot ? `In Slot ${slottedIdx + 1}` : `Slot ${this.selectedHotbarSlot + 1}`);
        assignBtn.type = "button";
        assignBtn.onclick = () => {
          p.loadout[this.selectedHotbarSlot] = ab.id;
          this.repo.save();
          this.refreshHeaderAndHotbar();
          this.newFight(false);
          this.renderActiveTab();
        };
        btnCol.appendChild(assignBtn);

        if (ab.isCustom) {
          const delBtn = el("button", "tf-btn danger", "✕");
          delBtn.type = "button";
          delBtn.title = "Delete Custom Spell";
          delBtn.onclick = () => {
            p.customSpells = (p.customSpells || []).filter(s => s.id !== ab.id);
            p.loadout = (p.loadout || []).map(id => (id === ab.id ? null : id));
            this.repo.save();
            this.refreshHeaderAndHotbar();
            this.newFight(false);
            this.renderActiveTab();
          };
          btnCol.appendChild(delBtn);
        }

        card.append(img, info, btnCol);
        container.appendChild(card);
      }
    }

    buildNewSpellForm() {
      const p = this.repo.profile;
      const card = el("div", "panel-card");
      card.appendChild(el("div", "panel-card-head").appendChild(el("h3", null, "Create Custom Spell")).parentElement);

      const grid = el("div", "form-grid");
      const mkField = (label, inputEl) => {
        const w = el("label", "field-col", label);
        w.appendChild(inputEl);
        return w;
      };

      const nameIn = el("input", "tf-input");
      nameIn.type = "text"; nameIn.value = "Arcane Nova"; nameIn.maxLength = 40;

      const schoolSel = el("select", "tf-select");
      for (const s of SCHOOL_OPTIONS) {
        const o = el("option", null, s.label);
        o.value = s.id;
        schoolSel.appendChild(o);
      }

      const dmgIn = el("input", "tf-input");
      dmgIn.type = "number"; dmgIn.min = "1"; dmgIn.step = "1"; dmgIn.value = "35";

      const scaleSel = el("select", "tf-select");
      for (const [val, lbl] of [["0", "0% (Flat Base Only)"], ["0.5", "50% Power"], ["1", "100% Power"], ["1.5", "150% Power"]]) {
        const o = el("option", null, lbl);
        o.value = val;
        if (val === "0.5") o.selected = true;
        scaleSel.appendChild(o);
      }

      const cdIn = el("input", "tf-input");
      cdIn.type = "number"; cdIn.min = "0"; cdIn.step = "0.1"; cdIn.value = "2.0";

      const costIn = el("input", "tf-input");
      costIn.type = "number"; costIn.min = "0"; costIn.step = "1"; costIn.value = "0";

      const gainIn = el("input", "tf-input");
      gainIn.type = "number"; gainIn.min = "0"; gainIn.step = "1"; gainIn.value = "0";

      const targetSel = el("select", "tf-select");
      for (const [val, lbl] of [["single", "Single Target"], ["cleave", "Cleave (Up to 3)"], ["all", "All Enemies"]]) {
        const o = el("option", null, lbl);
        o.value = val;
        targetSel.appendChild(o);
      }

      const bonusStatSel = el("select", "tf-select");
      for (const [val, lbl] of [
        ["", "None"], ["attackDamage", "+Attack Damage"], ["spellPower", "+Spell Power"],
        ["maxHp", "+Max HP"], ["critChance", "+Crit %"], ["haste", "+Haste %"], ["armor", "+Armor"],
      ]) {
        const o = el("option", null, lbl);
        o.value = val;
        bonusStatSel.appendChild(o);
      }

      const bonusValIn = el("input", "tf-input");
      bonusValIn.type = "number"; bonusValIn.step = "1"; bonusValIn.value = "0";

      grid.append(
        mkField("Spell Name", nameIn),
        mkField("Damage Type", schoolSel),
        mkField("Base Damage", dmgIn),
        mkField("Power Scaling", scaleSel),
        mkField("Cooldown (sec)", cdIn),
        mkField("Resource Cost", costIn),
        mkField("Resource Gain", gainIn),
        mkField("Target", targetSel),
        mkField("Optional Stat Bonus", bonusStatSel),
        mkField("Bonus Amount", bonusValIn)
      );

      // Optional DoT Sub-section
      const dotSec = el("div", "form-subsection");
      const dotToggleLabel = el("label", "check-label");
      const dotChk = el("input");
      dotChk.type = "checkbox";
      dotToggleLabel.append(dotChk, el("span", null, "Inflicts Damage over Time (DoT)"));
      const dotGrid = el("div", "form-grid");
      dotGrid.style.display = "none";
      const dotPctIn = el("input", "tf-input");
      dotPctIn.type = "number"; dotPctIn.min = "5"; dotPctIn.step = "5"; dotPctIn.value = "35";
      const dotDurIn = el("input", "tf-input");
      dotDurIn.type = "number"; dotDurIn.min = "1"; dotDurIn.step = "0.5"; dotDurIn.value = "6";
      const dotIntIn = el("input", "tf-input");
      dotIntIn.type = "number"; dotIntIn.min = "0.2"; dotIntIn.step = "0.1"; dotIntIn.value = "1.0";
      dotGrid.append(
        mkField("DoT % per Tick", dotPctIn),
        mkField("DoT Duration (sec)", dotDurIn),
        mkField("Tick Interval (sec)", dotIntIn)
      );
      dotChk.onchange = () => { dotGrid.style.display = dotChk.checked ? "grid" : "none"; };
      dotSec.append(dotToggleLabel, dotGrid);

      // Optional Proc Trigger Sub-section
      const procSec = el("div", "form-subsection");
      procSec.appendChild(el("div", "sub-label", "Optional Proc Trigger"));
      const procGrid = el("div", "form-grid");
      const procTrigSel = el("select", "tf-select");
      for (const [v, l] of [["none", "None"], ["onCast", "On Cast"], ["onHit", "On Hit"], ["onCrit", "On Crit"]]) {
        const o = el("option", null, l); o.value = v; procTrigSel.appendChild(o);
      }
      const procChanceIn = el("input", "tf-input");
      procChanceIn.type = "number"; procChanceIn.min = "1"; procChanceIn.max = "100"; procChanceIn.value = "100";
      const procEffectSel = el("select", "tf-select");
      for (const [v, l] of [
        ["bonus_hit", "Bonus Elemental Hit (% Power)"],
        ["apply_shock", "Apply Shock (+30% Vuln)"],
        ["restore_res", "Restore Resource (+Flat)"],
        ["heal_pct", "Heal Self (% Max HP)"],
      ]) {
        const o = el("option", null, l); o.value = v; procEffectSel.appendChild(o);
      }
      const procValIn = el("input", "tf-input");
      procValIn.type = "number"; procValIn.min = "1"; procValIn.value = "60";
      const procSchoolSel = el("select", "tf-select");
      for (const s of SCHOOL_OPTIONS) {
        const o = el("option", null, s.label); o.value = s.id;
        if (s.id === "school_lightning") o.selected = true;
        procSchoolSel.appendChild(o);
      }
      procGrid.append(
        mkField("Trigger", procTrigSel),
        mkField("Chance %", procChanceIn),
        mkField("Effect", procEffectSel),
        mkField("Effect Value", procValIn),
        mkField("Proc School", procSchoolSel)
      );
      procSec.appendChild(procGrid);

      const footer = el("div", "preset-row");
      const saveBtn = el("button", "tf-btn primary", `Create & Assign to Slot ${this.selectedHotbarSlot + 1}`);
      saveBtn.type = "button";
      saveBtn.onclick = () => {
        const name = nameIn.value.trim() || "Custom Spell";
        const school = schoolSel.value;
        const baseDmg = Math.max(1, Number(dmgIn.value) || 1);
        const power = Math.max(0, Number(scaleSel.value) || 0);
        const cdSec = Math.max(0, Number(cdIn.value) || 0);
        const cost = Math.max(0, Number(costIn.value) || 0);
        const gain = Math.max(0, Number(gainIn.value) || 0);
        const targetType = targetSel.value;
        const fx = targetType === "all" ? "BST" : targetType === "cleave" ? "CHN" : "PRJ";

        const statBonus = {};
        const bKey = bonusStatSel.value;
        const bRaw = Number(bonusValIn.value) || 0;
        if (bKey && bRaw !== 0) {
          statBonus[bKey] = (bKey === "critChance" || bKey === "haste") ? bRaw / 100 : bRaw;
        }

        const applies = {};
        if (dotChk.checked) {
          applies.dot = school;
          applies.dpsPct = Math.max(0.05, (Number(dotPctIn.value) || 35) / 100);
          applies.duration = Math.max(10, Math.round((Number(dotDurIn.value) || 6) * 10));
          applies.interval = Math.max(2, Math.round((Number(dotIntIn.value) || 1) * 10));
        }

        let proc = null;
        if (procTrigSel.value !== "none") {
          proc = {
            trigger: procTrigSel.value,
            chance: Math.min(1, Math.max(0.01, (Number(procChanceIn.value) || 100) / 100)),
            effect: procEffectSel.value,
            value: Math.max(1, Number(procValIn.value) || 50),
            school: procSchoolSel.value,
          };
        }

        const descBits = [`${baseDmg} base + ${Math.round(power * 100)}% power`, `${cdSec}s CD`, targetType];
        if (applies.dot) descBits.push(`DoT ${Math.round(applies.dpsPct * 100)}%/${(applies.interval / 10).toFixed(1)}s for ${(applies.duration / 10).toFixed(1)}s`);
        if (proc) descBits.push(`${Math.round(proc.chance * 100)}% ${proc.trigger} ${proc.effect}`);

        const custom = {
          id: `CS-ABL-${Date.now().toString(36)}`,
          isCustom: true,
          name,
          school,
          role: "strike",
          customBaseDamage: baseDmg,
          power,
          cooldownMs: Math.round(cdSec * 1000),
          gcd: true,
          resourceCost: cost,
          resourceGain: gain,
          targetType,
          fx,
          statBonus,
          applies: Object.keys(applies).length ? applies : undefined,
          proc,
          description: `Custom ${school.replace("school_", "")}: ${descBits.join(" · ")}.`,
        };
        p.customSpells = p.customSpells || [];
        p.customSpells.unshift(custom);
        p.loadout[this.selectedHotbarSlot] = custom.id;
        this.showNewSpellForm = false;
        this.repo.save();
        this.refreshHeaderAndHotbar();
        this.newFight(false);
        this.renderActiveTab();
      };
      footer.appendChild(saveBtn);
      card.append(grid, dotSec, procSec, footer);
      return card;
    }

    // ── FEATURE 2B: Premade + Custom Items & Gear ──
    renderItemsTab(body) {
      const p = this.repo.profile;
      const items = this.allItems();

      // Equipped Summary Card
      const eqCard = el("div", "panel-card");
      const eqHead = el("div", "panel-card-head");
      eqHead.appendChild(el("h3", null, "Equipped Gear"));
      const newItemToggle = el("button", "tf-btn primary", this.showNewItemForm ? "Close Creator" : "+ New Item");
      newItemToggle.type = "button";
      newItemToggle.onclick = () => {
        this.showNewItemForm = !this.showNewItemForm;
        this.renderActiveTab();
      };
      eqHead.appendChild(newItemToggle);
      eqCard.appendChild(eqHead);

      const eqList = el("div", "catalog-list");
      eqList.style.maxHeight = "220px";
      for (const slot of ["weapon", "armor", "shield", "tome", "ring", "rune", "trinket"]) {
        const itId = p.equipped?.[slot];
        const it = itId ? items.find(x => x.id === itId) : null;
        const row = el("div", "GS-UI-CARD");
        const img = el("img");
        img.src = it?.icon || GEAR_ICONS[slot];
        img.alt = slot;
        const info = el("div", "card-info");
        info.append(
          el("div", "tier", slot.toUpperCase()),
          el("div", "t", it ? it.name : "Empty"),
          el("div", "d", it ? this.formatItemStats(it) : "Click Equip on an item below")
        );
        row.append(img, info);
        if (it) {
          const btn = el("button", "tf-btn danger", "Unequip");
          btn.type = "button";
          btn.onclick = () => {
            p.equipped[slot] = null;
            this.repo.save();
            this.newFight(false);
            this.renderActiveTab();
          };
          row.appendChild(btn);
        }
        eqList.appendChild(row);
      }
      eqCard.appendChild(eqList);
      body.appendChild(eqCard);

      const activeHooks = this.combat?.itemMods?.activeDescriptions || [];
      if (activeHooks.length) {
        const hookCard = el("div", "panel-card");
        const hh = el("div", "panel-card-head");
        hh.appendChild(el("h3", null, `Active Item Hooks (${activeHooks.length})`));
        hookCard.appendChild(hh);
        const hList = el("div", "active-hooks-list");
        for (const h of activeHooks) {
          const row = el("div", "active-hook-row");
          row.append(el("b", null, `${h.item}: `), document.createTextNode(h.description));
          hList.appendChild(row);
        }
        hookCard.appendChild(hList);
        body.appendChild(hookCard);
      }

      if (this.showNewItemForm) {
        body.appendChild(this.buildNewItemForm());
      }

      // Item Library Card
      const libCard = el("div", "panel-card");
      const libHead = el("div", "panel-card-head");
      libHead.appendChild(el("h3", null, "Item Library"));
      const searchIn = el("input", "tf-input");
      searchIn.type = "search";
      searchIn.placeholder = "Search items...";
      searchIn.value = this.itemSearch;
      searchIn.oninput = () => {
        this.itemSearch = searchIn.value;
        this.renderItemCatalog(catalog);
      };
      libHead.appendChild(searchIn);
      libCard.appendChild(libHead);

      const filterRow = el("div", "preset-row");
      for (const [fKey, fLbl] of [
        ["all", "All"], ["custom", "Custom"],
        ["weapon", "Weapon"], ["armor", "Armor"], ["shield", "Shield"],
        ["tome", "Tome"], ["ring", "Ring"], ["rune", "Rune"], ["trinket", "Trinket"],
      ]) {
        const b = el("button", "tf-btn" + (this.itemFilter === fKey ? " active" : ""), fLbl);
        b.type = "button";
        b.onclick = () => {
          this.itemFilter = fKey;
          this.renderActiveTab();
        };
        filterRow.appendChild(b);
      }
      libCard.appendChild(filterRow);

      const catalog = el("div", "catalog-list");
      this.renderItemCatalog(catalog);
      libCard.appendChild(catalog);
      body.appendChild(libCard);
    }

    formatItemStats(it) {
      const parts = [];
      for (const [k, v] of Object.entries(it.stats || {})) {
        if (!v) continue;
        if (k === "critChance" || k === "haste" || k === "attackSpeed") {
          parts.push(`+${Math.round(v * 1000) / 10}% ${k}`);
        } else {
          parts.push(`+${v} ${k}`);
        }
      }
      return parts.join(" · ") || "No base stats";
    }

    renderItemCatalog(container) {
      container.replaceChildren();
      const p = this.repo.profile;
      const q = this.itemSearch.trim().toLowerCase();
      const filtered = this.allItems().filter(it => {
        if (this.itemFilter === "custom" && !it.isCustom) return false;
        if (this.itemFilter !== "all" && this.itemFilter !== "custom" && it.slot !== this.itemFilter) return false;
        if (q && !it.name.toLowerCase().includes(q) && !(it.hooks?.[0]?.description || "").toLowerCase().includes(q)) return false;
        return true;
      });

      if (!filtered.length) {
        container.appendChild(el("div", "GS-UI-FEED-line", "No matching items."));
        return;
      }

      for (const it of filtered.slice(0, 120)) {
        const card = el("div", `GS-UI-CARD tier-${Math.min(5, Math.max(1, it.tier || 3))}`);
        const img = el("img");
        img.src = it.icon || GEAR_ICONS[it.slot] || GEAR_ICONS.weapon;
        img.alt = it.name;
        const info = el("div", "card-info");
        const hookTxt = (it.hooks || []).map(h => h.description).join(" ");
        info.append(
          el("div", "t", it.name),
          el("div", "tier", `${it.isCustom ? "CUSTOM · " : ""}${it.slot.toUpperCase()} · ${this.formatItemStats(it)}`),
          el("div", "d", hookTxt || "Equip to apply stats immediately.")
        );

        const isEq = p.equipped?.[it.slot] === it.id;
        const btnCol = el("div", "preset-row");
        const eqBtn = el("button", "tf-btn" + (isEq ? " active" : ""), isEq ? "Equipped" : "Equip");
        eqBtn.type = "button";
        eqBtn.onclick = () => {
          p.equipped[it.slot] = isEq ? null : it.id;
          this.repo.save();
          this.newFight(false);
          this.renderActiveTab();
        };
        btnCol.appendChild(eqBtn);

        if (it.isCustom) {
          const delBtn = el("button", "tf-btn danger", "✕");
          delBtn.type = "button";
          delBtn.onclick = () => {
            p.customItems = (p.customItems || []).filter(x => x.id !== it.id);
            if (p.equipped?.[it.slot] === it.id) p.equipped[it.slot] = null;
            this.repo.save();
            this.newFight(false);
            this.renderActiveTab();
          };
          btnCol.appendChild(delBtn);
        }

        card.append(img, info, btnCol);
        container.appendChild(card);
      }
    }

    buildNewItemForm() {
      const p = this.repo.profile;
      const card = el("div", "panel-card");
      card.appendChild(el("div", "panel-card-head").appendChild(el("h3", null, "Create Custom Item")).parentElement);

      const grid = el("div", "form-grid");
      const mkNum = (label, def = 0, step = 1) => {
        const w = el("label", "field-col", label);
        const inp = el("input", "tf-input");
        inp.type = "number"; inp.step = String(step); inp.value = String(def);
        w.appendChild(inp);
        return [w, inp];
      };

      const nameIn = el("input", "tf-input");
      nameIn.type = "text"; nameIn.value = "Forgewarden Relic"; nameIn.maxLength = 40;
      const nameWrap = el("label", "field-col", "Item Name");
      nameWrap.appendChild(nameIn);

      const slotSel = el("select", "tf-select");
      for (const [val, lbl] of [["weapon", "Weapon"], ["armor", "Armor"], ["ring", "Ring"], ["trinket", "Trinket"]]) {
        const o = el("option", null, lbl);
        o.value = val;
        slotSel.appendChild(o);
      }
      const slotWrap = el("label", "field-col", "Slot");
      slotWrap.appendChild(slotSel);

      const [strW, strIn] = mkNum("+STR (→ +2 ATK, +5 HP)", 5);
      const [agiW, agiIn] = mkNum("+AGI (→ +1 ATK, +0.5% Crit/Haste)", 0);
      const [intW, intIn] = mkNum("+INT (→ +2 SP, +0.2 Regen)", 0);
      const [hpW, hpIn] = mkNum("+Max HP", 50);
      const [spdW, spdIn] = mkNum("+Attack Speed / Haste %", 5);
      const [critW, critIn] = mkNum("+Crit %", 3);
      const [dmgW, dmgIn] = mkNum("+Flat Damage", 10);
      const [armW, armIn] = mkNum("+Armor", 10);

      grid.append(nameWrap, slotWrap, strW, agiW, intW, hpW, spdW, critW, dmgW, armW);

      const footer = el("div", "preset-row");
      const createBtn = el("button", "tf-btn primary", "Create & Equip Item");
      createBtn.type = "button";
      createBtn.onclick = () => {
        const slot = slotSel.value;
        const stats = {};
        const add = (k, v) => { if (v) stats[k] = v; };
        add("str", Number(strIn.value) || 0);
        add("agi", Number(agiIn.value) || 0);
        add("int", Number(intIn.value) || 0);
        add("maxHp", Number(hpIn.value) || 0);
        add("attackSpeed", (Number(spdIn.value) || 0) / 100);
        add("critChance", (Number(critIn.value) || 0) / 100);
        add("flatDamage", Number(dmgIn.value) || 0);
        add("armor", Number(armIn.value) || 0);

        const item = {
          id: `CS-EQP-${Date.now().toString(36)}`,
          isCustom: true,
          name: nameIn.value.trim() || "Custom Item",
          slot,
          tier: 4,
          icon: GEAR_ICONS[slot] || GEAR_ICONS.weapon,
          hooks: [],
          stats,
        };
        p.customItems = p.customItems || [];
        p.customItems.unshift(item);
        p.equipped[slot] = item.id;
        this.showNewItemForm = false;
        this.repo.save();
        this.newFight(false);
        this.renderActiveTab();
      };
      footer.appendChild(createBtn);
      card.append(grid, footer);
      return card;
    }

    // ── FEATURE 3: Live Stat Editor with "Reset Stats" Button ──
    renderStatsTab(body) {
      const p = this.repo.profile;
      const base = this.combat.computeBaseStats();
      const cur = this.combat.playerStats;
      const ov = p.statOverrides || {};

      const card = el("div", "panel-card");
      const head = el("div", "panel-card-head");
      head.appendChild(el("h3", null, "Live Stat Editor"));
      const resetBtn = el("button", "tf-btn primary", "Reset Stats");
      resetBtn.type = "button";
      resetBtn.onclick = () => {
        p.statOverrides = null;
        this.mcResult = null;
        this.repo.save();
        this.combat.playerStats = this.combat.computeStats();
        this.combat.state.playerHp = this.combat.playerStats.maxHp;
        this.renderActiveTab();
      };
      head.appendChild(resetBtn);
      card.append(head, el("div", "d", "Edit any stat directly to test breakpoints. Reset Stats restores the exact sum of Base Character + Equipped Items + Equipped Spells."));

      const statDefs = [
        { key: "maxHp", label: "Max HP", step: 25, pct: false, min: 1 },
        { key: "attackDamage", label: "Attack Damage", step: 2, pct: false, min: 0 },
        { key: "spellPower", label: "Spell Power", step: 2, pct: false, min: 0 },
        { key: "haste", label: "Attack Speed / Haste %", step: 1, pct: true, min: 0, max: 85 },
        { key: "critChance", label: "Crit Chance %", step: 1, pct: true, min: 0, max: 100 },
        { key: "armor", label: "Armor", step: 5, pct: false, min: 0, extra: v => ` (${Math.round((v / (v + 100)) * 100)}% DR)` },
        { key: "resourceRegen", label: "Resource Regen (/s)", step: 1, pct: false, min: 0 },
      ];

      const grid = el("div", "stat-editor-grid");
      for (const sd of statDefs) {
        const isOv = ov[sd.key] != null;
        const row = el("div", "stat-row-card" + (isOv ? " overridden" : ""));
        const displayVal = sd.pct ? Math.round(cur[sd.key] * 1000) / 10 : Math.round(cur[sd.key] * 10) / 10;
        const baseDisplay = sd.pct ? `${Math.round(base[sd.key] * 1000) / 10}%` : `${Math.round(base[sd.key] * 10) / 10}`;

        const top = el("div", "stat-row-top");
        const extraTxt = sd.extra ? sd.extra(cur[sd.key]) : "";
        top.append(
          el("b", null, sd.label + extraTxt),
          el("span", null, isOv ? `Base: ${baseDisplay} · Edited` : `Base: ${baseDisplay}`)
        );

        const stepper = el("div", "stat-stepper");
        const minus = el("button", "tf-btn", "−");
        minus.type = "button";
        const inp = el("input", "tf-input");
        inp.type = "number";
        inp.step = sd.pct ? "0.5" : "1";
        inp.value = String(displayVal);
        const plus = el("button", "tf-btn", "+");
        plus.type = "button";

        const applyNewVal = (nextDisplay) => {
          let clamped = Math.max(sd.min ?? 0, Number(nextDisplay) || 0);
          if (sd.max != null) clamped = Math.min(sd.max, clamped);
          p.statOverrides = p.statOverrides || {};
          p.statOverrides[sd.key] = sd.pct ? clamped / 100 : clamped;
          this.mcResult = null;
          this.repo.save();
          this.combat.playerStats = this.combat.computeStats();
          if (sd.key === "maxHp") {
            if (this.combat.currentTick === 0) this.combat.state.playerHp = this.combat.playerStats.maxHp;
            else this.combat.state.playerHp = Math.min(this.combat.state.playerHp, this.combat.playerStats.maxHp);
          }
          this.renderActiveTab();
        };

        minus.onclick = () => applyNewVal(displayVal - sd.step);
        plus.onclick = () => applyNewVal(displayVal + sd.step);
        inp.onchange = () => applyNewVal(inp.value);

        stepper.append(minus, inp, plus);
        row.append(top, stepper);
        grid.appendChild(row);
      }

      card.appendChild(grid);
      body.appendChild(card);
    }

    // ── PHASE 3: Theorycraft Tab (Monte Carlo Analyzer + Build Snapshot A/B Comparison) ──
    renderTheorycraftTab(body) {
      const p = this.repo.profile;
      const hasEnemies = (p.sandboxEncounter || []).some(Boolean);

      // Card 1: Monte Carlo Multi-Run Analyzer
      const mcCard = el("div", "panel-card");
      const mcHead = el("div", "panel-card-head");
      mcHead.appendChild(el("h3", null, "Monte Carlo Sim Analyzer"));

      const btnRow = el("div", "preset-row");
      for (const n of [10, 50, 100]) {
        const b = el("button", "tf-btn" + (this.mcResult?.runs === n ? " primary" : ""), `Run ${n} Sims`);
        b.type = "button";
        b.disabled = !hasEnemies;
        b.onclick = () => {
          this.mcResult = runMonteCarlo(D, p, n, p.seed ?? 20261122);
          this.renderActiveTab();
        };
        btnRow.appendChild(b);
      }
      mcHead.appendChild(btnRow);
      mcCard.append(mcHead, el("div", "d", "Runs N deterministic simulations with stepped RNG seeds to measure crit/proc variance, win consistency, and TTK spread."));

      if (!hasEnemies) {
        mcCard.appendChild(el("div", "GS-UI-FEED-line", "Place at least 1 enemy in Encounter to run Monte Carlo simulations."));
      } else {
        if (!this.mcResult) {
          this.mcResult = runMonteCarlo(D, p, 25, p.seed ?? 20261122);
        }
        const r = this.mcResult;
        const kpiGrid = el("div", "mc-grid");
        const addKpi = (label, val, sub) => {
          const box = el("div", "mc-kpi");
          box.append(el("span", null, label), el("b", null, val), el("small", null, sub));
          kpiGrid.appendChild(box);
        };
        addKpi("Win Rate", `${r.winRatePct}%`, `${r.wins}W / ${r.defeats}L / ${r.timeouts}T · ${r.avgHpRemainingPct ?? 0}% HP Left`);
        addKpi("Median DPS (p50)", `${fmt(r.p50Dps ?? r.avgDps)}/s`, `p10–p90: ${fmt(r.p10Dps ?? r.minDps)} – ${fmt(r.p90Dps ?? r.maxDps)}`);
        addKpi("Median TTK (p50)", `${r.p50TtkSec ?? r.avgTtkSec}s`, `p90 ${r.p90TtkSec ?? r.maxTtkSec}s · Max ${r.maxTtkSec}s`);
        addKpi("Crit & Combos", `${r.avgCritPct}%`, `${r.avgCombos} combos · ${fmt(r.avgDamageTaken)} taken`);
        addKpi("Damage Mix", `${r.sourceMix.directPct}% Dir`, `DoT ${r.sourceMix.dotPct}% · Proc ${r.sourceMix.procPct}%`);
        mcCard.appendChild(kpiGrid);

        // DPS Distribution Histogram SVG
        mcCard.appendChild(this.buildHistogramSvg(r.dpsList));
      }
      body.appendChild(mcCard);

      // Card 2: Build Snapshot A vs. Current Build (B) Comparison
      const cmpCard = el("div", "panel-card");
      const cmpHead = el("div", "panel-card-head");
      cmpHead.appendChild(el("h3", null, "Build Snapshot Comparison (A vs. B)"));

      const cmpActions = el("div", "preset-row");
      const pinBtn = el("button", "tf-btn primary", p.buildSnapshot ? "Overwrite Snapshot A" : "Pin Current as Snapshot A");
      pinBtn.type = "button";
      pinBtn.disabled = !hasEnemies;
      pinBtn.onclick = () => {
        const mc = runMonteCarlo(D, p, 25, p.seed ?? 20261122);
        const cls = D.classes.find(c => c.id === (p.classId || "templar")) || D.classes[0];
        const st = this.combat.playerStats;
        p.buildSnapshot = {
          label: `${cls.name} (${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })})`,
          mc,
          stats: {
            attackDamage: Math.round(st.attackDamage * 10) / 10,
            spellPower: Math.round(st.spellPower * 10) / 10,
            critPct: Math.round(st.critChance * 1000) / 10,
            hastePct: Math.round(st.haste * 1000) / 10,
            armor: Math.round(st.armor),
            maxHp: Math.round(st.maxHp),
          },
        };
        this.repo.save();
        this.renderActiveTab();
      };
      cmpActions.appendChild(pinBtn);

      if (p.buildSnapshot) {
        const clrBtn = el("button", "tf-btn danger", "Clear Pin");
        clrBtn.type = "button";
        clrBtn.onclick = () => {
          p.buildSnapshot = null;
          this.repo.save();
          this.renderActiveTab();
        };
        cmpActions.appendChild(clrBtn);
      }
      cmpHead.appendChild(cmpActions);
      cmpCard.appendChild(cmpHead);

      if (!p.buildSnapshot) {
        cmpCard.appendChild(el("div", "d", "Click 'Pin Current as Snapshot A' to lock a baseline build, then swap gear, spells, or stats to compare exact DPS and TTK deltas."));
      } else if (!hasEnemies) {
        cmpCard.appendChild(el("div", "d", "Add at least 1 enemy to compare current build B against Snapshot A."));
      } else {
        const snapA = p.buildSnapshot;
        const mcB = runMonteCarlo(D, p, 25, p.seed ?? 20261122);
        const stB = this.combat.playerStats;
        const curB = {
          label: `${(D.classes.find(c => c.id === p.classId) || D.classes[0]).name} (Current)`,
          mc: mcB,
          stats: {
            attackDamage: Math.round(stB.attackDamage * 10) / 10,
            spellPower: Math.round(stB.spellPower * 10) / 10,
            critPct: Math.round(stB.critChance * 1000) / 10,
            hastePct: Math.round(stB.haste * 1000) / 10,
            armor: Math.round(stB.armor),
            maxHp: Math.round(stB.maxHp),
          },
        };

        const table = el("table", "compare-table");
        const thead = el("thead");
        const hr = el("tr");
        hr.append(
          el("th", null, "Metric"),
          el("th", null, `A: ${snapA.label}`),
          el("th", null, "B: Current"),
          el("th", null, "Delta (B − A)")
        );
        thead.appendChild(hr);
        table.appendChild(thead);

        const tbody = el("tbody");
        const addRow = (metric, valA, valB, fmtFn, higherIsBetter = true) => {
          const tr = el("tr");
          const diff = valB - valA;
          const pct = valA !== 0 ? Math.round((diff / Math.abs(valA)) * 1000) / 10 : 0;
          const sign = diff > 0 ? "+" : "";
          const cls = Math.abs(diff) < 0.05 ? "delta-flat" : (diff > 0) === higherIsBetter ? "delta-pos" : "delta-neg";
          const deltaStr = Math.abs(diff) < 0.05 ? "—" : `${sign}${fmtFn(diff)}${valA !== 0 ? ` (${sign}${pct}%)` : ""}`;
          tr.append(
            el("td", null, metric),
            el("td", null, fmtFn(valA)),
            el("td", null, fmtFn(valB)),
            el("td", cls, deltaStr)
          );
          tbody.appendChild(tr);
        };

        addRow("Avg DPS", snapA.mc.avgDps, curB.mc.avgDps, v => `${Math.round(v)}`, true);
        addRow("Avg TTK (s)", snapA.mc.avgTtkSec, curB.mc.avgTtkSec, v => `${v.toFixed(2)}s`, false);
        addRow("Win Rate %", snapA.mc.winRatePct, curB.mc.winRatePct, v => `${v.toFixed(1)}%`, true);
        addRow("Avg Combos", snapA.mc.avgCombos || 0, curB.mc.avgCombos || 0, v => `${v.toFixed(1)}`, true);
        addRow("Max HP", snapA.stats.maxHp, curB.stats.maxHp, v => `${Math.round(v)}`, true);
        addRow("Attack Damage", snapA.stats.attackDamage, curB.stats.attackDamage, v => `${v.toFixed(1)}`, true);
        addRow("Spell Power", snapA.stats.spellPower, curB.stats.spellPower, v => `${v.toFixed(1)}`, true);
        addRow("Crit Chance %", snapA.stats.critPct, curB.stats.critPct, v => `${v.toFixed(1)}%`, true);
        addRow("Haste %", snapA.stats.hastePct, curB.stats.hastePct, v => `${v.toFixed(1)}%`, true);
        addRow("Armor", snapA.stats.armor, curB.stats.armor, v => `${Math.round(v)}`, true);

        table.appendChild(tbody);
        cmpCard.appendChild(table);
      }
      body.appendChild(cmpCard);
    }

    buildHistogramSvg(values) {
      const wrap = el("div", "mc-hist-wrap");
      wrap.appendChild(el("div", "sub-label", "DPS Distribution Across Runs"));
      const svg = svgEl("svg", { class: "mc-hist-svg", viewBox: "0 0 320 64", preserveAspectRatio: "none" });
      if (!values || !values.length) {
        wrap.appendChild(svg);
        return wrap;
      }
      const min = Math.min(...values), max = Math.max(...values);
      const bins = 8;
      const counts = new Array(bins).fill(0);
      const span = Math.max(1, max - min);
      for (const v of values) {
        const idx = max === min ? Math.floor(bins / 2) : Math.min(bins - 1, Math.floor(((v - min) / span) * bins));
        counts[idx]++;
      }
      const maxC = Math.max(1, ...counts);
      const bw = 320 / bins;
      for (let i = 0; i < bins; i++) {
        const bh = Math.max(2, (counts[i] / maxC) * 44);
        const x = i * bw + 3;
        const y = 50 - bh;
        svg.appendChild(svgEl("rect", {
          x: x.toFixed(1), y: y.toFixed(1), width: (bw - 6).toFixed(1), height: bh.toFixed(1),
          rx: 2, fill: counts[i] ? "#d9a94e" : "#1d2230", opacity: counts[i] ? "0.85" : "0.4",
        }));
        if (counts[i] > 0) {
          const t = svgEl("text", { x: (x + (bw - 6) / 2).toFixed(1), y: 61, "text-anchor": "middle", fill: "#9ca3b8", "font-size": 8 });
          t.textContent = String(counts[i]);
          svg.appendChild(t);
        }
      }
      wrap.appendChild(svg);
      return wrap;
    }

    // ── IDLE CAMPAIGN MODE VIEWS ──
    formatCampaignItemDetails(it) {
      const parts = [];
      const upMult = 1 + (it.upgradeLevel || 0) * 0.12;
      const pushStat = (k, raw, boostPct = 0) => {
        const v = (Number(raw) || 0) * upMult * (1 + boostPct / 100);
        if (!v) return;
        if (["critChance", "haste", "attackSpeed", "block", "fireRes", "lightningRes", "poisonRes", "critMulti", "increasedDamage"].includes(k) || k.endsWith("DmgPct")) {
          parts.push(`+${Math.round(v * 1000) / 10}% ${k}`);
        } else {
          parts.push(`+${Math.round(v)} ${k}`);
        }
      };
      for (const [k, v] of Object.entries(it.stats || {})) pushStat(k, v, 0);
      for (const a of it.affixes || []) {
        const b = it.catalystBoosts?.[a.tag] || 0;
        pushStat(a.stat, a.value, b);
      }
      if ((it.socketedRunes || []).length) {
        parts.push(`Runes: ${it.socketedRunes.map(r => r.name).join(", ")}`);
      }
      return parts.join(" · ") || "Base Weapon";
    }

    renderCampaignOnboarding(body) {
      const card = el("div", "panel-card");
      const head = el("div", "panel-card-head");
      head.appendChild(el("h3", null, "Start Idle Campaign Character"));
      card.append(head, el("div", "d", "Pick your Class and Starter Weapon (7 archetypes). Clicking Start immediately launches auto-combat in Zone 1: Gallowsfen — Wave 1 on Tick 1."));

      card.appendChild(el("div", "sub-label", "1. Choose Class"));
      const clsGrid = el("div", "onboard-grid");
      for (const cls of D.classes) {
        const b = el("button", "choice-card" + (this.onboardClassId === cls.id ? " active" : ""));
        b.type = "button";
        const startSkills = cls.loadout.slice(0, 2).map(id => D.abilities.find(a => a.id === id)?.name).filter(Boolean).join(" + ");
        b.append(
          el("strong", null, `${cls.name} (${cls.hero})`),
          el("span", null, `Resource: ${cls.resource.label}`),
          el("small", null, `Opening skills: ${startSkills}`)
        );
        b.onclick = () => {
          this.onboardClassId = cls.id;
          this.renderActiveTab();
        };
        clsGrid.appendChild(b);
      }
      card.appendChild(clsGrid);

      card.appendChild(el("div", "sub-label", "2. Choose Starter Weapon Archetype"));
      const wepGrid = el("div", "onboard-grid");
      for (const w of STARTER_WEAPONS) {
        const b = el("button", "choice-card" + (this.onboardWeaponId === w.id ? " active" : ""));
        b.type = "button";
        b.append(
          el("strong", null, `${w.name}`),
          el("span", null, `${w.archetype} · ${(w.swingTicks / 10).toFixed(1)}s Swing · ${w.tags.join(", ")}`),
          el("small", null, w.description)
        );
        b.onclick = () => {
          this.onboardWeaponId = w.id;
          this.renderActiveTab();
        };
        wepGrid.appendChild(b);
      }
      card.appendChild(wepGrid);

      const startRow = el("div", "preset-row");
      const startBtn = el("button", "tf-btn primary", "Start Campaign (Zone 1: Gallowsfen — Wave 1)");
      startBtn.type = "button";
      startBtn.onclick = () => {
        const c = this.repo.profile.campaign;
        startCampaignCharacter(c, D, this.onboardClassId, this.onboardWeaponId);
        this.campaignBossActive = false;
        this.campfireRemainingMs = 0;
        this.activeTab = "campaign_home";
        this.repo.save();
        this.syncModeUI();
        this.rebuildNavTabs();
        this.refreshHeaderAndHotbar();
        this.combatLogEntries = [];
        this.lootEntries = [];
        this.renderCombatFeed();
        if (this.lootFeedEl) this.lootFeedEl.replaceChildren();
        const cntLbl = $("#lootCountLabel");
        if (cntLbl) cntLbl.textContent = "0 ITEMS";
        this.newFight(false);
        if (this.combat && !this.combat.state.result) {
          this.combat.tick();
          this.engine?.resume();
        }
        this.syncPlaybackButtons();
        this.updateSummary(true);
        this.renderActiveTab();
        this.feed(`Entered Zone 1: Gallowsfen — Wave 1 with ${c.equipped.weapon.name}! Auto-attacks & hotbar active on Tick 1.`, "loot");
      };
      startRow.appendChild(startBtn);
      card.appendChild(startRow);
      body.appendChild(card);
    }

    renderCampaignHomeTab(body) {
      const c = this.repo.profile.campaign;
      const cls = D.classes.find(x => x.id === c.classId) || D.classes[0];
      const spells = this.allSpells();

      // Card 1: Zone Progression & Next-Zone Stat Wall
      const zoneCard = el("div", "panel-card");
      const zHead = el("div", "panel-card-head");
      zHead.appendChild(el("h3", null, "Zone Progression & Stat Wall"));
      const newCharBtn = el("button", "tf-btn danger", "New Campaign Character");
      newCharBtn.type = "button";
      newCharBtn.onclick = () => {
        this.repo.resetCampaign();
        this.campaignBossActive = false;
        this.campfireRemainingMs = 0;
        this.syncModeUI();
        this.refreshHeaderAndHotbar();
        this.newFight(false);
        this.renderActiveTab();
      };
      zHead.appendChild(newCharBtn);
      zoneCard.appendChild(zHead);

      const curZ = getCampaignZone(c.zoneIndex);
      const nextZ = getCampaignZone(c.zoneIndex + 1);
      const wallBox = el("div", "formula-preview");
      wallBox.append(
        el("span", null, `Current (${curZ.shortName}): `),
        el("b", null, `${curZ.hpMult}× HP · ${curZ.dmgMult}× DMG · ${Math.round(curZ.armorDr * 100)}% DR · ${Math.round(curZ.resPct * 100)}% Res`),
        el("span", null, `Next (${nextZ.shortName}): `),
        el("b", null, `${nextZ.hpMult}× HP · ${nextZ.dmgMult}× DMG · ${Math.round(nextZ.armorDr * 100)}% DR · ${Math.round(nextZ.resPct * 100)}% Res`)
      );
      zoneCard.appendChild(wallBox);

      const zList = el("div", "preset-row");
      const maxShown = Math.max(2, (c.unlockedZone || 0) + 1);
      for (let zi = 0; zi <= maxShown; zi++) {
        const zn = getCampaignZone(zi);
        const unlocked = zi <= (c.unlockedZone || 0);
        const b = el("button", "tf-btn" + (c.zoneIndex === zi ? " active" : ""), unlocked ? zn.shortName : `${zn.shortName} (Locked)`);
        b.type = "button";
        b.disabled = !unlocked;
        b.onclick = () => {
          c.zoneIndex = zi;
          c.wave = Math.max(1, c.maxWaveByZone?.[zi] || 1);
          c.bossReadyPct = 0;
          this.campaignBossActive = false;
          this.repo.save();
          this.newFight(false);
          this.renderActiveTab();
        };
        zList.appendChild(b);
      }
      zoneCard.append(zList, el("div", "d", "Defeating a Zone Boss manually unlocks the next Zone (~3.2× enemy HP, ~2.1× enemy DMG). Drop back anytime to farm safe waves or Rested XP."));
      body.appendChild(zoneCard);

      // Card 2: 5-Slot Hotbar Priority & Unlocked Skills
      const hotCard = el("div", "panel-card");
      const hotHead = el("div", "panel-card-head");
      hotHead.appendChild(el("h3", null, `Campaign Hotbar (Editing Slot ${this.selectedHotbarSlot + 1})`));
      const clrBtn = el("button", "tf-btn danger", `Clear Slot ${this.selectedHotbarSlot + 1}`);
      clrBtn.type = "button";
      clrBtn.disabled = !c.loadout[this.selectedHotbarSlot];
      clrBtn.onclick = () => {
        c.loadout[this.selectedHotbarSlot] = null;
        this.repo.save();
        this.refreshHeaderAndHotbar();
        this.newFight(false);
        this.renderActiveTab();
      };
      hotHead.appendChild(clrBtn);
      hotCard.appendChild(hotHead);

      const strip = el("div", "slot-strip");
      for (let i = 0; i < 5; i++) {
        const ab = c.loadout[i] ? spells.find(a => a.id === c.loadout[i]) : null;
        const pill = el("button", "slot-pill" + (i === this.selectedHotbarSlot ? " active" : ""));
        pill.type = "button";
        if (ab) {
          const img = el("img");
          img.src = fxPath(ab.school, ab.fx);
          img.alt = ab.name;
          pill.append(el("span", null, `Key ${i + 1}`), img, el("span", "slot-name", ab.name));
        } else {
          pill.append(el("span", null, `Key ${i + 1}`), el("b", null, "—"), el("span", "slot-name", "Empty"));
        }
        pill.onclick = () => {
          this.selectedHotbarSlot = i;
          this.refreshHeaderAndHotbar();
          this.renderActiveTab();
        };
        strip.appendChild(pill);
      }
      const shiftRow = el("div", "slot-move-row");
      shiftRow.appendChild(el("div", "d", "Auto-casts left-to-right (Slots 1 → 5). Class skills unlock at Lv 2, 3, 4."));
      const moveBtns = el("div", "slot-move-btns");
      const mvLeft = el("button", "tf-btn", "◄ Shift Left");
      mvLeft.type = "button";
      mvLeft.disabled = this.selectedHotbarSlot <= 0 || !c.loadout[this.selectedHotbarSlot];
      mvLeft.onclick = () => {
        const idx = this.selectedHotbarSlot;
        if (idx <= 0) return;
        const tmp = c.loadout[idx - 1];
        c.loadout[idx - 1] = c.loadout[idx];
        c.loadout[idx] = tmp;
        this.selectedHotbarSlot = idx - 1;
        this.repo.save();
        this.refreshHeaderAndHotbar();
        this.newFight(false);
        this.renderActiveTab();
      };
      const mvRight = el("button", "tf-btn", "Shift Right ►");
      mvRight.type = "button";
      mvRight.disabled = this.selectedHotbarSlot >= 4 || !c.loadout[this.selectedHotbarSlot];
      mvRight.onclick = () => {
        const idx = this.selectedHotbarSlot;
        if (idx >= 4) return;
        const tmp = c.loadout[idx + 1];
        c.loadout[idx + 1] = c.loadout[idx];
        c.loadout[idx] = tmp;
        this.selectedHotbarSlot = idx + 1;
        this.repo.save();
        this.refreshHeaderAndHotbar();
        this.newFight(false);
        this.renderActiveTab();
      };
      moveBtns.append(mvLeft, mvRight);
      shiftRow.appendChild(moveBtns);
      hotCard.append(strip, shiftRow);

      const unlockedIds = c.unlockedAbilities?.length ? c.unlockedAbilities : cls.loadout.slice(0, 2);
      const skillList = el("div", "catalog-list");
      skillList.style.maxHeight = "260px";
      for (const abId of cls.loadout) {
        const ab = spells.find(a => a.id === abId);
        if (!ab) continue;
        const isUnlocked = unlockedIds.includes(abId);
        const card = el("div", "GS-UI-CARD");
        const img = el("img");
        img.src = fxPath(ab.school, ab.fx);
        img.alt = ab.name;
        const info = el("div", "card-info");
        info.append(
          el("div", "t", ab.name + (isUnlocked ? "" : " (Locked)")),
          el("div", "tier", `CD ${((ab.cooldownMs || 0) / 1000).toFixed(1)}s · ${ab.targetType || "single"}`),
          el("div", "d", ab.description || "")
        );
        const b = el("button", "tf-btn" + (c.loadout[this.selectedHotbarSlot] === abId ? " active" : ""),
          !isUnlocked ? "Level Up" : c.loadout[this.selectedHotbarSlot] === abId ? `In Slot ${this.selectedHotbarSlot + 1}` : `Assign Slot ${this.selectedHotbarSlot + 1}`);
        b.type = "button";
        b.disabled = !isUnlocked;
        b.onclick = () => {
          c.loadout[this.selectedHotbarSlot] = abId;
          this.repo.save();
          this.refreshHeaderAndHotbar();
          this.newFight(false);
          this.renderActiveTab();
        };
        card.append(img, info, b);
        skillList.appendChild(card);
      }
      hotCard.appendChild(skillList);
      body.appendChild(hotCard);
    }

    renderCampaignGearTab(body) {
      const c = this.repo.profile.campaign;

      // 1. Equipped Gear (7 Slots)
      const eqCard = el("div", "panel-card");
      const eqHead = el("div", "panel-card-head");
      eqHead.appendChild(el("h3", null, "Equipped Campaign Gear"));
      eqCard.appendChild(eqHead);

      const eqList = el("div", "catalog-list");
      eqList.style.maxHeight = "250px";
      for (const slot of ["weapon", "armor", "shield", "tome", "ring", "rune", "trinket"]) {
        const it = c.equipped?.[slot] || null;
        const card = el("div", "camp-item-card" + (it && it.id === this.selectedForgeItemId ? " selected-forge" : ""));
        if (it) card.style.borderColor = RARITY_COLOR[it.rarity] || "var(--tf-gold-frame)";
        const img = el("img");
        img.src = it?.icon || GEAR_ICONS[slot];
        img.alt = slot;
        const info = el("div", "card-info");
        if (it) {
          const title = el("div", "t", `${it.name}${it.upgradeLevel ? ` +${it.upgradeLevel}` : ""}`);
          title.style.color = RARITY_COLOR[it.rarity] || "var(--tf-text)";
          info.append(
            title,
            el("div", "meta-line", `${slot.toUpperCase()} · ${it.rarity} · iLvl ${it.ilvl} · PWR ${computeItemPowerScore(it)} · Sockets ${it.socketedRunes?.length || 0}/${it.sockets || 0}`),
            el("div", "d", this.formatCampaignItemDetails(it))
          );
          if ((it.ruleMutators || []).length) {
            info.appendChild(el("div", "mutator-line", `Mutator: ${it.ruleMutators.map(m => `${m.name} — ${m.description}`).join(" | ")}`));
          }
        } else {
          info.append(
            el("div", "meta-line", slot.toUpperCase()),
            el("div", "t", "Empty Slot"),
            el("div", "d", "Equip a dropped item from your Inventory Bag below.")
          );
        }
        const acts = el("div", "camp-item-actions");
        if (it) {
          const forgeBtn = el("button", "tf-btn primary", it.id === this.selectedForgeItemId ? "Forging" : "Forge");
          forgeBtn.type = "button";
          forgeBtn.onclick = () => {
            this.selectedForgeItemId = it.id;
            this.forgeMessage = null;
            this.renderActiveTab();
          };
          acts.appendChild(forgeBtn);
          if (!it.isStarter && slot !== "weapon") {
            const uneqBtn = el("button", "tf-btn", "Unequip");
            uneqBtn.type = "button";
            uneqBtn.onclick = () => {
              c.inventory.unshift(it);
              c.equipped[slot] = null;
              this.repo.save();
              this.newFight(false);
              this.renderActiveTab();
            };
            acts.appendChild(uneqBtn);
          }
        }
        card.append(img, info, acts);
        eqList.appendChild(card);
      }
      eqCard.appendChild(eqList);
      body.appendChild(eqCard);

      // 2. Two-Tier Crafting Forge Workbench
      const forgeCard = el("div", "panel-card");
      const fHead = el("div", "panel-card-head");
      fHead.appendChild(el("h3", null, "Two-Tier Crafting Forge"));
      forgeCard.appendChild(fHead);

      // Tier 1 + Tier 2 Material Counts
      const t1Strip = el("div", "mat-strip");
      for (const mId of ["forged_scrap", "arcane_dust", "essence_shards"]) {
        const m = MATERIALS_META[mId];
        const box = el("div", "mat-box");
        box.title = m.desc;
        box.append(el("span", null, m.name), el("b", null, fmt(c.materials[mId] || 0)));
        t1Strip.appendChild(box);
      }
      forgeCard.append(el("div", "sub-label", "Tier 1 Salvage Materials"), t1Strip);

      const rareIds = Object.keys(MATERIALS_META).filter(k => MATERIALS_META[k].tier === 2);
      const t2Owned = rareIds.filter(k => (c.materials[k] || 0) > 0);
      const t2Strip = el("div", "mat-strip");
      for (const mId of (t2Owned.length ? t2Owned : rareIds.slice(0, 4))) {
        const m = MATERIALS_META[mId];
        const box = el("div", "mat-box");
        box.title = `${m.desc} (Drop: ${m.dropPct}%)`;
        box.append(el("span", null, m.name), el("b", null, fmt(c.materials[mId] || 0)));
        t2Strip.appendChild(box);
      }
      forgeCard.append(el("div", "sub-label", `Tier 2 Ultra-Rare Catalysts (${t2Owned.length} types in stash)`), t2Strip);

      if (this.forgeMessage) {
        forgeCard.appendChild(el("div", "GS-UI-FEED-line loot", this.forgeMessage));
      }

      const targetItem = Object.values(c.equipped || {}).find(x => x && x.id === this.selectedForgeItemId)
        || (c.inventory || []).find(x => x && x.id === this.selectedForgeItemId)
        || c.equipped.weapon;

      if (targetItem) {
        this.selectedForgeItemId = targetItem.id;
        const tInfo = el("div", "formula-preview");
        tInfo.append(
          el("span", null, "Selected Item: "),
          el("b", null, `${targetItem.name}${targetItem.upgradeLevel ? ` +${targetItem.upgradeLevel}` : ""} (${targetItem.rarity})`),
          el("span", null, `Rank ${targetItem.upgradeLevel || 0}/10 · Sockets ${targetItem.socketedRunes?.length || 0}/${targetItem.sockets || 0}`)
        );
        forgeCard.appendChild(tInfo);

        const rank = targetItem.upgradeLevel || 0;
        const socks = targetItem.sockets || 0;
        const t1Row = el("div", "preset-row");

        const upBtn = el("button", "tf-btn primary", rank >= 10 ? "Max +10" : `Upgrade +${rank + 1} (${4 + rank * 3} Scrap, ${2 + rank * 2} Dust)`);
        upBtn.type = "button";
        upBtn.disabled = rank >= 10;
        upBtn.onclick = () => {
          const res = upgradeItemRank(c, targetItem.id);
          this.forgeMessage = res.ok ? res.message : res.error;
          this.repo.save();
          if (res.ok) this.newFight(false);
          this.renderActiveTab();
        };

        const sockBtn = el("button", "tf-btn", socks >= 3 ? "Max 3 Sockets" : `Add Socket (${10 + socks * 10} Scrap, ${2 + socks * 2} Shards)`);
        sockBtn.type = "button";
        sockBtn.disabled = socks >= 3 || !["weapon", "armor", "shield", "tome"].includes(targetItem.slot);
        sockBtn.onclick = () => {
          const res = addRuneSocket(c, targetItem.id);
          this.forgeMessage = res.ok ? res.message : res.error;
          this.repo.save();
          this.renderActiveTab();
        };

        const rerollBtn = el("button", "tf-btn", "Reroll Affixes (6 Dust, 1 Shard)");
        rerollBtn.type = "button";
        rerollBtn.onclick = () => {
          const res = rerollItemAffixes(c, targetItem.id);
          this.forgeMessage = res.ok ? res.message : res.error;
          this.repo.save();
          if (res.ok) this.newFight(false);
          this.renderActiveTab();
        };
        t1Row.append(upBtn, sockBtn, rerollBtn);

        // Socket a Rune from Inventory if space available
        const bagRunes = (c.inventory || []).filter(x => x.slot === "rune");
        if ((targetItem.socketedRunes?.length || 0) < (targetItem.sockets || 0) && bagRunes.length) {
          const rSel = el("select", "tf-select");
          for (const r of bagRunes) {
            const opt = el("option", null, `${r.name} (PWR ${computeItemPowerScore(r)})`);
            opt.value = r.id;
            rSel.appendChild(opt);
          }
          const putRuneBtn = el("button", "tf-btn accent", "Socket Rune");
          putRuneBtn.type = "button";
          putRuneBtn.onclick = () => {
            const res = socketRuneIntoItem(c, targetItem.id, rSel.value);
            this.forgeMessage = res.ok ? res.message : res.error;
            this.repo.save();
            if (res.ok) this.newFight(false);
            this.renderActiveTab();
          };
          t1Row.append(rSel, putRuneBtn);
        }
        forgeCard.appendChild(t1Row);

        // Tier 2 Catalyst Actions (show any owned Tier 2 catalysts)
        if (t2Owned.length) {
          const t2Row = el("div", "preset-row");
          for (const mId of t2Owned) {
            const meta = MATERIALS_META[mId];
            const b = el("button", "tf-btn accent", `Apply ${meta.name} (${c.materials[mId]})`);
            b.type = "button";
            b.title = meta.desc;
            b.onclick = () => {
              const res = applyCatalystToItem(c, targetItem.id, mId);
              this.forgeMessage = res.ok ? res.message : res.error;
              this.repo.save();
              if (res.ok) this.newFight(false);
              this.renderActiveTab();
            };
            t2Row.appendChild(b);
          }
          forgeCard.appendChild(t2Row);
        }
      }
      body.appendChild(forgeCard);

      // 3. Inventory Bag with Equip Comparison & Salvage
      const bagCard = el("div", "panel-card");
      const bagHead = el("div", "panel-card-head");
      bagHead.appendChild(el("h3", null, `Inventory Bag (${(c.inventory || []).length}/80)`));
      const salvAllBtn = el("button", "tf-btn danger", "Salvage Common & Uncommon");
      salvAllBtn.type = "button";
      salvAllBtn.disabled = !(c.inventory || []).some(x => x.rarity === "Common" || x.rarity === "Uncommon");
      salvAllBtn.onclick = () => {
        const keep = [];
        let count = 0;
        for (const it of c.inventory || []) {
          if (it.rarity === "Common" || it.rarity === "Uncommon") {
            const m = salvageItemToMaterials(it);
            c.materials.forged_scrap += m.forged_scrap;
            c.materials.arcane_dust += m.arcane_dust;
            c.materials.essence_shards += m.essence_shards;
            c.statsSummary.itemsSalvaged = (c.statsSummary.itemsSalvaged || 0) + 1;
            count++;
          } else {
            keep.push(it);
          }
        }
        c.inventory = keep;
        this.forgeMessage = `Salvaged ${count} Common/Uncommon items.`;
        this.repo.save();
        this.renderActiveTab();
      };
      bagHead.appendChild(salvAllBtn);
      bagCard.appendChild(bagHead);

      const fRow = el("div", "preset-row");
      for (const [fk, fl] of [["all", "All"], ["weapon", "Weapon"], ["armor", "Armor"], ["shield", "Shield"], ["tome", "Tome"], ["ring", "Ring"], ["rune", "Rune"], ["trinket", "Trinket"]]) {
        const fb = el("button", "tf-btn" + (this.campaignBagFilter === fk ? " active" : ""), fl);
        fb.type = "button";
        fb.onclick = () => { this.campaignBagFilter = fk; this.renderActiveTab(); };
        fRow.appendChild(fb);
      }
      bagCard.appendChild(fRow);

      const bagList = el("div", "catalog-list");
      const filteredBag = (c.inventory || []).filter(x => this.campaignBagFilter === "all" || x.slot === this.campaignBagFilter);
      if (!filteredBag.length) {
        bagList.appendChild(el("div", "GS-UI-FEED-line", "No items in bag matching this filter. Waves & Bosses drop gear automatically."));
      } else {
        for (const it of filteredBag) {
          const curEq = c.equipped?.[it.slot];
          const pwrNew = computeItemPowerScore(it);
          const pwrCur = curEq ? computeItemPowerScore(curEq) : 0;
          const delta = pwrNew - pwrCur;
          const deltaTxt = delta > 0 ? `+${delta} PWR` : delta < 0 ? `${delta} PWR` : "Same PWR";

          const card = el("div", "camp-item-card" + (it.id === this.selectedForgeItemId ? " selected-forge" : ""));
          card.style.borderColor = RARITY_COLOR[it.rarity] || "var(--tf-gold-frame)";
          const img = el("img");
          img.src = it.icon || GEAR_ICONS[it.slot] || GEAR_ICONS.weapon;
          img.alt = it.name;

          const info = el("div", "card-info");
          const title = el("div", "t", `${it.name}${it.upgradeLevel ? ` +${it.upgradeLevel}` : ""}`);
          title.style.color = RARITY_COLOR[it.rarity] || "var(--tf-text)";
          const cmpSpan = el("span", delta > 0 ? "delta-pos" : delta < 0 ? "delta-neg" : "delta-flat", ` (${deltaTxt} vs equipped)`);
          const metaLine = el("div", "meta-line", `${it.slot.toUpperCase()} · ${it.rarity} · iLvl ${it.ilvl} · PWR ${pwrNew} · Sockets ${it.sockets || 0}`);
          metaLine.appendChild(cmpSpan);
          info.append(title, metaLine, el("div", "d", this.formatCampaignItemDetails(it)));
          if ((it.ruleMutators || []).length) {
            info.appendChild(el("div", "mutator-line", `Mutator: ${it.ruleMutators.map(m => `${m.name} — ${m.description}`).join(" | ")}`));
          }

          const acts = el("div", "camp-item-actions");
          const eqBtn = el("button", "tf-btn primary", "Equip");
          eqBtn.type = "button";
          eqBtn.onclick = () => {
            it.isNew = false;
            const idx = c.inventory.findIndex(x => x.id === it.id);
            if (idx >= 0) c.inventory.splice(idx, 1);
            if (curEq) c.inventory.unshift(curEq);
            c.equipped[it.slot] = it;
            this.selectedForgeItemId = it.id;
            this.repo.save();
            this.newFight(false);
            this.renderActiveTab();
          };
          const fBtn = el("button", "tf-btn", "Forge");
          fBtn.type = "button";
          fBtn.onclick = () => {
            this.selectedForgeItemId = it.id;
            this.renderActiveTab();
          };
          const salvBtn = el("button", "tf-btn danger", "Salvage");
          salvBtn.type = "button";
          salvBtn.onclick = () => {
            const idx = c.inventory.findIndex(x => x.id === it.id);
            if (idx >= 0) c.inventory.splice(idx, 1);
            const m = salvageItemToMaterials(it);
            c.materials.forged_scrap += m.forged_scrap;
            c.materials.arcane_dust += m.arcane_dust;
            c.materials.essence_shards += m.essence_shards;
            c.statsSummary.itemsSalvaged = (c.statsSummary.itemsSalvaged || 0) + 1;
            this.forgeMessage = `Salvaged ${it.name} → +${m.forged_scrap} Scrap, +${m.arcane_dust} Dust, +${m.essence_shards} Shards.`;
            this.repo.save();
            this.renderActiveTab();
          };
          acts.append(eqBtn, fBtn, salvBtn);
          card.append(img, info, acts);
          bagList.appendChild(card);
        }
      }
      bagCard.appendChild(bagList);
      body.appendChild(bagCard);
    }

    renderCampaignFilterTab(body) {
      const c = this.repo.profile.campaign;
      const lf = c.lootFilter;

      const card = el("div", "panel-card");
      const head = el("div", "panel-card-head");
      head.appendChild(el("h3", null, "Smart Loot Filter & Auto-Salvage Engine"));
      const applyBagBtn = el("button", "tf-btn danger", "Salvage Non-Matching Bag Items");
      applyBagBtn.type = "button";
      applyBagBtn.onclick = () => {
        const keep = [];
        let salvCount = 0;
        for (const it of c.inventory || []) {
          const ev = evaluateLootFilter(it, lf);
          if (ev.keep) keep.push(it);
          else {
            const m = salvageItemToMaterials(it);
            c.materials.forged_scrap += m.forged_scrap;
            c.materials.arcane_dust += m.arcane_dust;
            c.materials.essence_shards += m.essence_shards;
            c.statsSummary.itemsSalvaged = (c.statsSummary.itemsSalvaged || 0) + 1;
            salvCount++;
          }
        }
        c.inventory = keep;
        this.filterPreviewResult = `Swept bag: auto-salvaged ${salvCount} non-matching items into crafting materials.`;
        this.repo.save();
        this.renderActiveTab();
      };
      head.appendChild(applyBagBtn);
      card.append(head, el("div", "d", "Items failing your filter auto-salvage immediately on drop into Forged Scrap, Arcane Dust, and Essence Shards."));

      // Minimum Rarity
      const rarWrap = el("label", "field-col", "Minimum Rarity");
      const rarSel = el("select", "tf-select");
      for (const [val, lbl] of [
        ["Common", "Keep All (Common+)"],
        ["Uncommon", "Uncommon+"],
        ["Rare", "Rare+"],
        ["Epic", "Epic+"],
        ["Legendary", "Legendary+"],
      ]) {
        const o = el("option", null, lbl);
        o.value = val;
        if ((lf.minRarity || "Common") === val) o.selected = true;
        rarSel.appendChild(o);
      }
      rarSel.onchange = () => { lf.minRarity = rarSel.value; this.repo.save(); };
      rarWrap.appendChild(rarSel);
      card.appendChild(rarWrap);

      // Match Threshold
      const matchRow = el("div", "preset-row");
      matchRow.appendChild(el("span", "sub-label", "Tag Match Rule:"));
      for (const n of [1, 2]) {
        const b = el("button", "tf-btn" + ((lf.minTagMatches || 1) === n ? " active" : ""), `Require ${n} Tag${n > 1 ? "s" : ""}`);
        b.type = "button";
        b.onclick = () => { lf.minTagMatches = n; this.repo.save(); this.renderActiveTab(); };
        matchRow.appendChild(b);
      }
      card.appendChild(matchRow);

      // 10 Tag Checkboxes
      card.appendChild(el("div", "sub-label", "Tag / Stat Whitelist (leave empty to match any tags)"));
      const tagGrid = el("div", "filter-tag-grid");
      for (const tag of FILTER_TAGS) {
        const lbl = el("label", "filter-tag-check");
        const chk = el("input");
        chk.type = "checkbox";
        chk.checked = (lf.tags || []).includes(tag);
        chk.onchange = () => {
          if (chk.checked) {
            if (!lf.tags.includes(tag)) lf.tags.push(tag);
          } else {
            lf.tags = lf.tags.filter(t => t !== tag);
          }
          this.repo.save();
        };
        lbl.append(chk, el("span", null, tag));
        tagGrid.appendChild(lbl);
      }
      card.appendChild(tagGrid);

      // Always Keep Overrides
      card.appendChild(el("div", "sub-label", "Always Keep Overrides"));
      const ovList = el("div", "form-subsection");
      const mkOv = (key, label) => {
        const l = el("label", "check-label");
        const chk = el("input");
        chk.type = "checkbox";
        chk.checked = !!lf[key];
        chk.onchange = () => { lf[key] = chk.checked; this.repo.save(); };
        l.append(chk, el("span", null, label));
        ovList.appendChild(l);
      };
      mkOv("keepMutators", "Always keep Build-Revamping Mutators");
      mkOv("keepTwoSockets", "Always keep 2+ Rune Sockets");
      mkOv("keepRunesTrinkets", "Always keep Runes / Trinkets");
      card.appendChild(ovList);

      // Test Drop Preview
      const testRow = el("div", "preset-row");
      const testBtn = el("button", "tf-btn primary", "Test Filter vs Sample Drop");
      testBtn.type = "button";
      testBtn.onclick = () => {
        const sample = rollCampaignDrop(c.zoneIndex, c.wave, false, false, Math.random);
        const ev = evaluateLootFilter(sample, lf);
        this.filterPreviewResult = `Sample [${sample.rarity} ${sample.name} | Tags: ${sample.tags.join(", ") || "none"} | Sockets: ${sample.sockets}] → ${ev.keep ? "KEPT" : "AUTO-SALVAGED"} (${ev.reason})`;
        this.renderActiveTab();
      };
      testRow.appendChild(testBtn);
      card.appendChild(testRow);
      if (this.filterPreviewResult) {
        card.appendChild(el("div", "GS-UI-FEED-line loot", this.filterPreviewResult));
      }
      body.appendChild(card);
    }

    renderCampaignStatsTab(body) {
      const c = this.repo.profile.campaign;
      const st = this.combat?.playerStats || { maxHp: 420, attackDamage: 18, spellPower: 18, critChance: 0.08, critMulti: 0.35, haste: 0, armor: 0, block: 0, fireRes: 0, lightningRes: 0, poisonRes: 0, resourceRegen: 0 };

      const card = el("div", "panel-card");
      card.appendChild(el("div", "panel-card-head").appendChild(el("h3", null, "Campaign Character Stats")).parentElement);

      const kpiGrid = el("div", "mc-grid");
      const addKpi = (lbl, val, sub) => {
        const box = el("div", "mc-kpi");
        box.append(el("span", null, lbl), el("b", null, val), el("small", null, sub));
        kpiGrid.appendChild(box);
      };
      const dr = Math.round((st.armor / (st.armor + 100)) * 100);
      addKpi("Max HP", fmt(Math.round(st.maxHp)), `Armor ${Math.round(st.armor)} (${dr}% DR)`);
      addKpi("Attack / Spell", `${Math.round(st.attackDamage)} / ${Math.round(st.spellPower)}`, `Crit ${(st.critChance * 100).toFixed(1)}% · ${(150 + (st.critMulti || 0.35) * 100).toFixed(0)}% Mult`);
      addKpi("Haste & Block", `${(st.haste * 100).toFixed(1)}%`, `Block ${(Math.min(0.65, st.block || 0) * 100).toFixed(0)}% · Regen ${(st.resourceRegen || 0).toFixed(1)}/s`);
      addKpi("Resistances", `F ${Math.round((st.fireRes || 0) * 100)}%`, `L ${Math.round((st.lightningRes || 0) * 100)}% · P ${Math.round((st.poisonRes || 0) * 100)}%`);
      addKpi("Campaign Record", `${c.wavesCleared} Waves`, `${c.bossesKilled || 0} Bosses · ${c.deaths} Total Deaths`);
      addKpi("Loot Stats", `${c.statsSummary?.itemsKept || 0} Kept`, `${c.statsSummary?.itemsSalvaged || 0} Salvaged · ${c.statsSummary?.rareMaterials || 0} Rare Mats`);
      card.appendChild(kpiGrid);
      body.appendChild(card);

      // Active Build-Revamping Mutators
      const mutCard = el("div", "panel-card");
      mutCard.appendChild(el("div", "panel-card-head").appendChild(el("h3", null, "Active Build-Revamping Mutators")).parentElement);
      const activeHooks = this.combat?.itemMods?.activeDescriptions || [];
      if (!activeHooks.length) {
        mutCard.appendChild(el("div", "d", "No Build-Revamping Mutators equipped yet. Rare, Epic, Legendary, and Corrupted drops roll gameplay-changing mutators."));
      } else {
        const list = el("div", "active-hooks-list");
        for (const h of activeHooks) {
          const row = el("div", "active-hook-row");
          row.append(el("b", null, `${h.item} (${h.kind}): `), document.createTextNode(h.description));
          list.appendChild(row);
        }
        mutCard.appendChild(list);
      }
      body.appendChild(mutCard);
    }

    renderCampaignMonteCarloTab(body) {
      const c = this.repo.profile.campaign;
      const curZ = getCampaignZone(c.zoneIndex);
      const nextZ = getCampaignZone((c.zoneIndex || 0) + 1);

      // Card 1: Campaign Encounter & Boss Readiness Predictor
      const mcCard = el("div", "panel-card");
      const mcHead = el("div", "panel-card-head");
      mcHead.appendChild(el("h3", null, "Campaign Monte Carlo Predictor"));

      const runRow = el("div", "preset-row");
      for (const n of [10, 25, 50, 100]) {
        const b = el("button", "tf-btn" + (this.campMcResult?.runs === n ? " primary" : ""), `Run ${n} Sims`);
        b.type = "button";
        b.onclick = () => {
          this.campMcResult = runCampaignMonteCarlo(D, c, { target: this.campMcTarget, runs: n });
          this.campMcCompare = null;
          this.renderActiveTab();
        };
        runRow.appendChild(b);
      }
      mcHead.appendChild(runRow);
      mcCard.appendChild(mcHead);

      // Target Selector: Current Wave / Zone Boss / Next Zone Wave 1
      const targetRow = el("div", "preset-row");
      const targets = [
        ["wave", `Wave ${c.wave} (${curZ.shortName})`],
        ["boss", `Zone Boss (${curZ.bossName})`],
        ["next_zone", `Next Zone (${nextZ.shortName} W1)`],
      ];
      for (const [tk, label] of targets) {
        const b = el("button", "tf-btn" + (this.campMcTarget === tk ? " active" : ""), label);
        b.type = "button";
        b.onclick = () => {
          this.campMcTarget = tk;
          this.campMcResult = runCampaignMonteCarlo(D, c, { target: tk, runs: this.campMcResult?.runs || 50 });
          this.campMcCompare = null;
          this.renderActiveTab();
        };
        targetRow.appendChild(b);
      }
      mcCard.appendChild(targetRow);

      if (!this.campMcResult) {
        this.campMcResult = runCampaignMonteCarlo(D, c, { target: this.campMcTarget, runs: 50 });
      }
      const r = this.campMcResult;

      // Readiness Verdict Banner
      const banner = el("div", `verdict-banner ${r.verdictCode}`);
      const bHead = el("div", "verdict-banner-head");
      bHead.append(
        el("strong", null, `Readiness: ${r.targetLabel}`),
        el("span", "verdict-badge", r.verdict)
      );
      banner.append(
        bHead,
        el("div", "verdict-sub", r.advice),
        el("div", "verdict-meta", `${r.runs} deterministic sims · p10–p90 DPS: ${fmt(r.p10Dps)} – ${fmt(r.p90Dps)}/s · p50–p90 TTK: ${r.p50TtkSec}s – ${r.p90TtkSec}s`)
      );
      mcCard.appendChild(banner);

      const kpiGrid = el("div", "mc-grid");
      const addKpi = (label, val, sub) => {
        const box = el("div", "mc-kpi");
        box.append(el("span", null, label), el("b", null, val), el("small", null, sub));
        kpiGrid.appendChild(box);
      };
      addKpi("Win Rate", `${r.winRatePct}%`, `${r.wins}W / ${r.defeats}L / ${r.timeouts}T`);
      addKpi("Median DPS (p50)", `${fmt(r.p50Dps)}/s`, `Avg ${fmt(r.avgDps)} · p10 ${fmt(r.p10Dps)}`);
      addKpi("Median TTK (p50)", `${r.p50TtkSec}s`, `p90 ${r.p90TtkSec}s · Max ${r.maxTtkSec}s`);
      addKpi("Enrage & HP Left", `${r.enrageRatePct}% Enrage`, `${r.avgHpRemainingPct}% avg HP left on win`);
      addKpi("Projected Income", `${fmt(r.xpPerHour)} XP/h`, `${fmt(r.goldPerHour)} Gold/hr (2s death adj)`);
      addKpi("Crit & Source Mix", `${r.avgCritPct}% Crit`, `Dir ${r.sourceMix.directPct}% · DoT ${r.sourceMix.dotPct}% · Proc ${r.sourceMix.procPct}%`);
      mcCard.appendChild(kpiGrid);
      mcCard.appendChild(this.buildHistogramSvg(r.dpsList));
      body.appendChild(mcCard);

      // Card 2: Paired What-If Bag Item Comparison (Equipped A vs Bag Candidate B)
      const cmpCard = el("div", "panel-card");
      const cmpHead = el("div", "panel-card-head");
      cmpHead.appendChild(el("h3", null, "What-If Gear Monte Carlo (Bag vs Equipped)"));
      cmpCard.append(cmpHead, el("div", "d", "Tests any equippable item from your Inventory Bag using paired RNG seeds without mutating your character."));

      const candidates = (c.inventory || [])
        .filter(x => x && ["weapon", "armor", "shield", "tome", "ring", "rune", "trinket"].includes(x.slot))
        .sort((a, b) => computeItemPowerScore(b) - computeItemPowerScore(a));

      if (!candidates.length) {
        cmpCard.appendChild(el("div", "GS-UI-FEED-line", "No equippable items in your Inventory Bag yet. Clear waves or lower your Loot Filter to gather candidates."));
        body.appendChild(cmpCard);
        return;
      }

      if (!this.selectedCompareItemId || !candidates.some(x => x.id === this.selectedCompareItemId)) {
        this.selectedCompareItemId = candidates[0].id;
      }
      const chosen = candidates.find(x => x.id === this.selectedCompareItemId) || candidates[0];

      const ctrlRow = el("div", "preset-row");
      const sel = el("select", "tf-select");
      for (const it of candidates) {
        const o = el("option", null, `[${it.slot.toUpperCase()}] ${it.name}${it.upgradeLevel ? ` +${it.upgradeLevel}` : ""} (${it.rarity}, PWR ${computeItemPowerScore(it)})`);
        o.value = it.id;
        if (it.id === chosen.id) o.selected = true;
        sel.appendChild(o);
      }
      sel.onchange = () => {
        this.selectedCompareItemId = sel.value;
        this.campMcCompare = null;
        this.renderActiveTab();
      };

      const runCmpBtn = el("button", "tf-btn primary", "Compare (50 Paired Sims)");
      runCmpBtn.type = "button";
      runCmpBtn.onclick = () => {
        this.campMcCompare = compareCampaignCandidate(D, c, chosen, { target: this.campMcTarget, runs: 50 });
        this.renderActiveTab();
      };
      ctrlRow.append(sel, runCmpBtn);
      cmpCard.appendChild(ctrlRow);

      if (!this.campMcCompare || this.campMcCompare.candidateItem?.id !== chosen.id || this.campMcCompare.baseline?.target !== this.campMcTarget) {
        this.campMcCompare = compareCampaignCandidate(D, c, chosen, { target: this.campMcTarget, runs: 25 });
      }
      const cmp = this.campMcCompare;
      const base = cmp.baseline;
      const cand = cmp.candidate;

      const table = el("table", "compare-table");
      const thead = el("thead");
      const hr = el("tr");
      hr.append(
        el("th", null, "Metric"),
        el("th", null, `A: ${cmp.equippedItem ? cmp.equippedItem.name : `Empty (${chosen.slot})`}`),
        el("th", null, `B: ${chosen.name}`),
        el("th", null, "Delta (B − A)")
      );
      thead.appendChild(hr);
      table.appendChild(thead);

      const tbody = el("tbody");
      const addRow = (metric, valA, valB, fmtFn, higherIsBetter = true) => {
        const tr = el("tr");
        const diff = valB - valA;
        const pct = valA !== 0 ? Math.round((diff / Math.abs(valA)) * 1000) / 10 : 0;
        const sign = diff > 0 ? "+" : "";
        const cls = Math.abs(diff) < 0.05 ? "delta-flat" : (diff > 0) === higherIsBetter ? "delta-pos" : "delta-neg";
        const deltaStr = Math.abs(diff) < 0.05 ? "—" : `${sign}${fmtFn(diff)}${valA !== 0 ? ` (${sign}${pct}%)` : ""}`;
        tr.append(el("td", null, metric), el("td", null, fmtFn(valA)), el("td", null, fmtFn(valB)), el("td", cls, deltaStr));
        tbody.appendChild(tr);
      };

      addRow("Win Rate %", base.winRatePct, cand.winRatePct, v => `${v.toFixed(1)}%`, true);
      addRow("Median DPS (p50)", base.p50Dps, cand.p50Dps, v => `${Math.round(v)}/s`, true);
      addRow("Avg DPS", base.avgDps, cand.avgDps, v => `${Math.round(v)}/s`, true);
      addRow("Avg TTK (s)", base.avgTtkSec, cand.avgTtkSec, v => `${v.toFixed(2)}s`, false);
      addRow("Avg HP Left %", base.avgHpRemainingPct, cand.avgHpRemainingPct, v => `${v.toFixed(1)}%`, true);
      addRow("Projected XP/hr", base.xpPerHour, cand.xpPerHour, v => `${fmt(Math.round(v))}`, true);
      table.appendChild(tbody);
      cmpCard.appendChild(table);

      const actRow = el("div", "preset-row");
      const eqNowBtn = el("button", "tf-btn primary", `Equip ${chosen.name} Now`);
      eqNowBtn.type = "button";
      eqNowBtn.onclick = () => {
        const curEq = c.equipped?.[chosen.slot] || null;
        const idx = c.inventory.findIndex(x => x.id === chosen.id);
        if (idx >= 0) c.inventory.splice(idx, 1);
        if (curEq) c.inventory.unshift(curEq);
        chosen.isNew = false;
        c.equipped[chosen.slot] = chosen;
        this.selectedForgeItemId = chosen.id;
        this.campMcCompare = null;
        this.campMcResult = null;
        this.repo.save();
        this.newFight(false);
        this.renderActiveTab();
        this.feed(`Equipped ${chosen.name} from Monte Carlo comparison.`, "loot");
      };
      actRow.appendChild(eqNowBtn);
      cmpCard.appendChild(actRow);
      body.appendChild(cmpCard);
    }

    // ── FEATURE 4: Export / Import Build JSON & Settings Modals ──
    openJsonModal() {
      const p = this.repo.profile;
      const exportPayload = {
        version: 2,
        gameMode: p.gameMode || "sandbox",
        classId: p.classId,
        loadout: p.loadout,
        equipped: p.equipped,
        customSpells: p.customSpells || [],
        customItems: p.customItems || [],
        statOverrides: p.statOverrides || null,
        sandboxEncounter: p.sandboxEncounter,
        botMode: p.botMode || "optimal",
        campaign: p.campaign,
      };

      const box = $("#modalContent");
      box.replaceChildren();
      box.appendChild(el("h2", null, "Export / Import Save JSON"));
      box.appendChild(el("p", null, "Includes both your Sandbox Build and your Idle Campaign progression, inventory, materials, and loot filter."));

      const ta = el("textarea");
      ta.value = JSON.stringify(exportPayload, null, 2);
      box.appendChild(ta);

      const statusMsg = el("div", "GS-UI-FEED-line", "");
      box.appendChild(statusMsg);

      const actions = el("div", "tf-modal-actions");
      const copyBtn = el("button", "tf-btn", "Copy JSON");
      copyBtn.type = "button";
      copyBtn.onclick = async () => {
        try {
          await navigator.clipboard.writeText(ta.value);
          statusMsg.textContent = "Copied to clipboard!";
        } catch {
          ta.select();
          statusMsg.textContent = "Selected text — press Ctrl/Cmd+C to copy.";
        }
      };

      const importBtn = el("button", "tf-btn primary", "Import Save");
      importBtn.type = "button";
      importBtn.onclick = () => {
        try {
          const parsed = JSON.parse(ta.value);
          if (!parsed || typeof parsed !== "object") throw new Error("Invalid object");
          if (["sandbox", "campaign"].includes(parsed.gameMode)) p.gameMode = parsed.gameMode;
          if (parsed.classId && D.classes.some(c => c.id === parsed.classId)) p.classId = parsed.classId;
          if (Array.isArray(parsed.loadout)) p.loadout = [0, 1, 2, 3, 4].map(i => parsed.loadout[i] || null);
          if (parsed.equipped && typeof parsed.equipped === "object") p.equipped = Object.assign({}, p.equipped, parsed.equipped);
          if (Array.isArray(parsed.customSpells)) p.customSpells = parsed.customSpells;
          if (Array.isArray(parsed.customItems)) p.customItems = parsed.customItems;
          if (parsed.statOverrides === null || typeof parsed.statOverrides === "object") p.statOverrides = parsed.statOverrides;
          if (Array.isArray(parsed.sandboxEncounter) && parsed.sandboxEncounter.length === 5) p.sandboxEncounter = parsed.sandboxEncounter;
          if (["optimal", "casual", "sloppy"].includes(parsed.botMode)) p.botMode = parsed.botMode;
          if (parsed.campaign && typeof parsed.campaign === "object" && window.Tickforge.mergeCampaignState) {
            p.campaign = window.Tickforge.mergeCampaignState(parsed.campaign);
          }

          this.activeTab = p.gameMode === "campaign" ? "campaign_home" : "encounter";
          this.campaignBossActive = false;
          this.campfireRemainingMs = 0;
          this.repo.save();
          this.closeModal();
          this.buildShell();
          this.newFight(false);
          this.renderActiveTab();
        } catch (err) {
          statusMsg.textContent = `Import failed: ${err.message}`;
        }
      };

      const closeBtn = el("button", "tf-btn", "Close");
      closeBtn.type = "button";
      closeBtn.onclick = () => this.closeModal();

      actions.append(copyBtn, importBtn, closeBtn);
      box.appendChild(actions);
      $("#modalBackdrop").hidden = false;
    }

    openSettingsModal() {
      const p = this.repo.profile;
      const box = $("#modalContent");
      box.replaceChildren();
      box.appendChild(el("h2", null, "Settings"));

      const mkToggle = (label, key) => {
        const row = el("div", "GS-UI-CARD");
        row.appendChild(el("div", "t", label));
        const btn = el("button", "tf-btn" + (p.settings[key] ? " active" : ""), p.settings[key] ? "On" : "Off");
        btn.type = "button";
        btn.onclick = () => {
          p.settings[key] = !p.settings[key];
          this.repo.save();
          this.openSettingsModal();
        };
        row.appendChild(btn);
        return row;
      };

      box.append(mkToggle("Visual Effects (FCT & FX)", "fx"), mkToggle("Combat Log Feed", "feed"));

      const actions = el("div", "tf-modal-actions");
      const resetCamp = el("button", "tf-btn", "Reset Campaign Only");
      resetCamp.type = "button";
      resetCamp.onclick = () => {
        this.repo.resetCampaign();
        this.campaignBossActive = false;
        this.campfireRemainingMs = 0;
        this.closeModal();
        this.buildShell();
        this.newFight(false);
        this.renderActiveTab();
      };
      const resetAll = el("button", "tf-btn danger", "Reset All Data");
      resetAll.type = "button";
      resetAll.onclick = () => {
        this.repo.reset();
        this.campaignBossActive = false;
        this.campfireRemainingMs = 0;
        this.closeModal();
        this.buildShell();
        this.newFight(false);
        this.renderActiveTab();
      };
      const closeBtn = el("button", "tf-btn", "Close");
      closeBtn.type = "button";
      closeBtn.onclick = () => this.closeModal();
      actions.append(resetCamp, resetAll, closeBtn);
      box.appendChild(actions);
      $("#modalBackdrop").hidden = false;
    }

    closeModal() {
      $("#modalBackdrop").hidden = true;
    }
  }

  window.addEventListener("DOMContentLoaded", () => {
    window.Tickforge.ui = new UI();
  });
})();
